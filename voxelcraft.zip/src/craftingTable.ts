// 3x3 Crafting Table Modal UI and starter inventory hooks
import { BLOCK_ID, BLOCK_DEFS, RESOURCE_DEFS, CRAFTING_RECIPES } from './constants';

export function setupCraftingTable(app: any) {
    const inv = app.inventory;
    const overlay = document.getElementById('mc-craft-overlay');
    const closeBtn = document.getElementById('mc-craft-close');
    const recipeBtn = document.getElementById('mc-recipe-btn');
    const recipeBook = document.getElementById('mc-recipe-book');

    if (!overlay) return;

    closeBtn?.addEventListener('click', () => {
        overlay.classList.remove('open');
        app.player.controls.lock();
    });

    recipeBtn?.addEventListener('click', () => {
        recipeBook?.classList.toggle('open');
    });

    // Intercept 'C' key to open 3x3 table
    document.addEventListener('keydown', (e) => {
        if (e.code === 'KeyC') {
            overlay.classList.toggle('open');
            if (overlay.classList.contains('open')) {
                app.player.controls.unlock();
            } else {
                app.player.controls.lock();
            }
        }
    });

    // Grant starter items on first world boot
    setTimeout(() => {
        if (inv) {
            inv.addBlock(BLOCK_ID.LOG, 16);
            inv.addBlock(BLOCK_ID.COBBLESTONE, 32);
            inv.addResource('iron_pickaxe', 1);
            inv.addResource('iron_sword', 1);
            inv.addResource('apple', 8);
            inv.render();
        }
    }, 200);
}
