import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { CONFIG, BLOCK_ID, BLOCK_DEFS, RESOURCE_DEFS, RESOURCE_ITEM, PLAYER_SKINS, getSkinDefById, normalizeSkinPayload, getCustomSkinState, getBlockHardness, getPreferredToolType, getBlockDrop } from './constants';
import { MathKernel, VoxelWorld } from './world';
import { InventorySystem, SurvivalSystem, DroppedItemManager, OnlineSessionManager } from './systems';
import { FriendlyMobManager, HostileMobManager } from './mobs';
import { AudioProcessor, ParticleKernel } from './environment';

export class PlayerController {
    camera: THREE.PerspectiveCamera;
    world: VoxelWorld;
    scene: THREE.Scene;
    inventory: InventorySystem;
    survival: SurvivalSystem;
    droppedItemManager: DroppedItemManager;
    audio: AudioProcessor | null;
    particleKernel: ParticleKernel | null = null;
    onlineSession: OnlineSessionManager | null = null;
    friendlyMobManager: FriendlyMobManager | null = null;
    hostileMobManager: HostileMobManager | null = null;
    windChargeManager: any = null;
    controls: PointerLockControls;

    velocity = new THREE.Vector3();
    moveState = { f: false, b: false, l: false, r: false, run: false, crouch: false, jump: false };
    onGround = false;
    activeSlot = 1;
    ray = new THREE.Raycaster();
    headBobTime = 0;
    headBobIntensity = 0.03;
    lastBobOffset = 0;
    meleeCooldown = 0;
    isLeftMouseDown = false;
    creativeBreakTimer = 0.2;
    breakGraceTimer = 0;
    breakState = {
        active: false,
        key: '',
        x: 0,
        y: 0,
        z: 0,
        blockId: BLOCK_ID.AIR,
        progress: 0,
        totalTime: 0.2,
        stage: -1
    };
    fallStartY: number;
    stepTimer = 0;
    breakHitTimer = 0;
    viewSwing = 0;
    viewSelectedKey = '';
    viewModel: any;
    viewModelSkinId = PLAYER_SKINS[0].id;
    toolDurability: any = null;

    // Third-person mode support
    cameraMode = 0; // 0 = 1st person, 1 = 3rd person back, 2 = 3rd person front
    thirdPersonDist = 3.5;
    _tpOffsetApplied = false;
    _tpEyePos = new THREE.Vector3();
    _tpEyeQuat = new THREE.Quaternion();
    _thirdPersonBody: any = null;

    tempForward = new THREE.Vector3();
    tempSide = new THREE.Vector3();
    tempMove = new THREE.Vector3();
    isMoving = false;
    isSprinting = false;
    isFlying = false;
    lastSpacePress = 0;

    constructor(
        camera: THREE.PerspectiveCamera,
        world: VoxelWorld,
        scene: THREE.Scene,
        inventory: InventorySystem,
        survival: SurvivalSystem,
        droppedItemManager: DroppedItemManager,
        audioProcessor: AudioProcessor | null = null,
        particleKernel: ParticleKernel | null = null
    ) {
        this.camera = camera;
        this.world = world;
        this.scene = scene;
        this.inventory = inventory;
        this.survival = survival;
        this.droppedItemManager = droppedItemManager;
        this.audio = audioProcessor;
        this.particleKernel = particleKernel;
        this.controls = new PointerLockControls(camera, document.body);
        this.fallStartY = camera.position.y;

        this.viewModel = this.createFirstPersonViewModel();
        this._thirdPersonBody = this.createThirdPersonBody();
        this.setViewModelSkin(this.viewModelSkinId);

        this.bindEvents();
    }

    setParticleKernel(kernel: ParticleKernel) {
        this.particleKernel = kernel;
    }

    setMobManagers(friendly: FriendlyMobManager, hostile: HostileMobManager) {
        this.friendlyMobManager = friendly;
        this.hostileMobManager = hostile;
    }

    setWindChargeManager(manager: any) {
        this.windChargeManager = manager;
    }

    setOnlineSession(session: OnlineSessionManager) {
        this.onlineSession = session;
    }

    setToolDurability(td: any) {
        this.toolDurability = td;
    }

    toggleCameraMode() {
        this.cameraMode = (this.cameraMode + 1) % 3;
        const tip = this.cameraMode === 0 ? 'Camera: 1st Person' : (this.cameraMode === 1 ? 'Camera: 3rd Person (Back)' : 'Camera: 3rd Person (Front)');
        (window as any).app?.showHelpTipFor?.(tip, 2000);
    }

    createFirstPersonViewModel() {
        const root = new THREE.Group();
        root.position.set(0.56, -0.42, -0.72);
        root.rotation.set(-0.18, 0.26, 0.05);

        const handMat = new THREE.MeshBasicMaterial({ color: 0xd7a67b });
        const forearm = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.35, 0.22), handMat);
        forearm.position.set(0.04, -0.1, 0.04);
        root.add(forearm);

        // 3D Animated Wind Charge in player's first-person hand
        const windChargeModel = new THREE.Group();
        windChargeModel.position.set(0.04, 0.1, -0.15);

        const orbMat = new THREE.MeshBasicMaterial({ color: 0xe8ffff, transparent: true, opacity: 0.95 });
        const orb = new THREE.Mesh(new THREE.SphereGeometry(0.068, 12, 12), orbMat);
        windChargeModel.add(orb);

        const ringMat = new THREE.MeshBasicMaterial({ color: 0x9bf4ff, transparent: true, opacity: 0.75, wireframe: true });
        const ring1 = new THREE.Mesh(new THREE.TorusGeometry(0.092, 0.012, 8, 16), ringMat);
        ring1.rotation.x = Math.PI / 4;
        windChargeModel.add(ring1);

        const ring2 = new THREE.Mesh(new THREE.TorusGeometry(0.108, 0.012, 8, 16), ringMat);
        ring2.rotation.y = Math.PI / 3;
        windChargeModel.add(ring2);

        windChargeModel.visible = false;
        root.add(windChargeModel);

        this.camera.add(root);
        return { root, forearm, windChargeModel, ring1, ring2 };
    }

    createThirdPersonBody() {
        const group = new THREE.Group();
        const S = 1 / 16;
        const skinMat = new THREE.MeshLambertMaterial({ color: 0xd7a67b });
        const shirtMat = new THREE.MeshLambertMaterial({ color: 0x4c76c9 });
        const pantsMat = new THREE.MeshLambertMaterial({ color: 0x2f3f70 });

        const head = new THREE.Mesh(new THREE.BoxGeometry(8 * S, 8 * S, 8 * S), skinMat);
        head.position.set(0, 28 * S, 0);

        const torso = new THREE.Mesh(new THREE.BoxGeometry(8 * S, 12 * S, 4 * S), shirtMat);
        torso.position.set(0, 18 * S, 0);

        const armL = new THREE.Mesh(new THREE.BoxGeometry(4 * S, 12 * S, 4 * S), shirtMat);
        armL.position.set(-6 * S, 18 * S, 0);

        const armR = new THREE.Mesh(new THREE.BoxGeometry(4 * S, 12 * S, 4 * S), shirtMat);
        armR.position.set(6 * S, 18 * S, 0);

        const legL = new THREE.Mesh(new THREE.BoxGeometry(4 * S, 12 * S, 4 * S), pantsMat);
        legL.position.set(-2 * S, 6 * S, 0);

        const legR = new THREE.Mesh(new THREE.BoxGeometry(4 * S, 12 * S, 4 * S), pantsMat);
        legR.position.set(2 * S, 6 * S, 0);

        // 3D Visual Armor Overlays attached to character limbs
        const defaultArmorMat = () => new THREE.MeshLambertMaterial({ color: 0x55ffea });

        const helmetMesh = new THREE.Mesh(new THREE.BoxGeometry(8.9 * S, 8.9 * S, 8.9 * S), defaultArmorMat());
        helmetMesh.visible = false;
        head.add(helmetMesh);

        const chestplateMesh = new THREE.Mesh(new THREE.BoxGeometry(8.9 * S, 12.5 * S, 4.9 * S), defaultArmorMat());
        chestplateMesh.visible = false;
        torso.add(chestplateMesh);

        const shoulderLMesh = new THREE.Mesh(new THREE.BoxGeometry(4.7 * S, 6 * S, 4.7 * S), defaultArmorMat());
        shoulderLMesh.position.set(0, 3 * S, 0);
        shoulderLMesh.visible = false;
        armL.add(shoulderLMesh);

        const shoulderRMesh = new THREE.Mesh(new THREE.BoxGeometry(4.7 * S, 6 * S, 4.7 * S), defaultArmorMat());
        shoulderRMesh.position.set(0, 3 * S, 0);
        shoulderRMesh.visible = false;
        armR.add(shoulderRMesh);

        const leggingLMesh = new THREE.Mesh(new THREE.BoxGeometry(4.5 * S, 8 * S, 4.5 * S), defaultArmorMat());
        leggingLMesh.position.set(0, 2 * S, 0);
        leggingLMesh.visible = false;
        legL.add(leggingLMesh);

        const leggingRMesh = new THREE.Mesh(new THREE.BoxGeometry(4.5 * S, 8 * S, 4.5 * S), defaultArmorMat());
        leggingRMesh.position.set(0, 2 * S, 0);
        leggingRMesh.visible = false;
        legR.add(leggingRMesh);

        const bootLMesh = new THREE.Mesh(new THREE.BoxGeometry(4.8 * S, 4.5 * S, 4.8 * S), defaultArmorMat());
        bootLMesh.position.set(0, -3.8 * S, 0);
        bootLMesh.visible = false;
        legL.add(bootLMesh);

        const bootRMesh = new THREE.Mesh(new THREE.BoxGeometry(4.8 * S, 4.5 * S, 4.8 * S), defaultArmorMat());
        bootRMesh.position.set(0, -3.8 * S, 0);
        bootRMesh.visible = false;
        legR.add(bootRMesh);

        group.add(head, torso, armL, armR, legL, legR);
        group.visible = false;
        this.scene.add(group);

        return {
            group, head, torso, armL, armR, legL, legR,
            helmetMesh, chestplateMesh, shoulderLMesh, shoulderRMesh,
            leggingLMesh, leggingRMesh, bootLMesh, bootRMesh,
            walkTime: 0
        };
    }

    getArmorColor(pieceId: string): number {
        if (pieceId.includes('diamond')) return 0x55ffea;
        if (pieceId.includes('ruby')) return 0xff3366;
        if (pieceId.includes('gold')) return 0xf7c43b;
        if (pieceId.includes('iron')) return 0xd6e0e5;
        if (pieceId.includes('leather')) return 0x8a5229;
        return 0xaaaaaa;
    }

    updateArmorVisuals(armor: { helmet: string | null; chestplate: string | null; leggings: string | null; boots: string | null }) {
        if (!this._thirdPersonBody) return;
        const b = this._thirdPersonBody;

        if (armor.helmet) {
            b.helmetMesh.visible = true;
            (b.helmetMesh.material as THREE.MeshLambertMaterial).color.setHex(this.getArmorColor(armor.helmet));
        } else {
            b.helmetMesh.visible = false;
        }

        if (armor.chestplate) {
            const c = this.getArmorColor(armor.chestplate);
            b.chestplateMesh.visible = true;
            (b.chestplateMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
            b.shoulderLMesh.visible = true;
            (b.shoulderLMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
            b.shoulderRMesh.visible = true;
            (b.shoulderRMesh.material as THREE.MeshLambertMaterial).color.setHex(c);

            if (this.viewModel?.forearm) {
                (this.viewModel.forearm.material as THREE.MeshLambertMaterial).color.setHex(c);
            }
        } else {
            b.chestplateMesh.visible = false;
            b.shoulderLMesh.visible = false;
            b.shoulderRMesh.visible = false;
            if (this.viewModel?.forearm) {
                const skin = getSkinDefById(this.viewModelSkinId);
                (this.viewModel.forearm.material as THREE.MeshLambertMaterial).color.setHex(skin.head);
            }
        }

        if (armor.leggings) {
            const c = this.getArmorColor(armor.leggings);
            b.leggingLMesh.visible = true;
            (b.leggingLMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
            b.leggingRMesh.visible = true;
            (b.leggingRMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
        } else {
            b.leggingLMesh.visible = false;
            b.leggingRMesh.visible = false;
        }

        if (armor.boots) {
            const c = this.getArmorColor(armor.boots);
            b.bootLMesh.visible = true;
            (b.bootLMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
            b.bootRMesh.visible = true;
            (b.bootRMesh.material as THREE.MeshLambertMaterial).color.setHex(c);
        } else {
            b.bootLMesh.visible = false;
            b.bootRMesh.visible = false;
        }
    }

    setViewModelSkin(skinId: string, customSkin: any = null) {
        const skin = skinId === 'custom' ? normalizeSkinPayload(customSkin || getCustomSkinState()) : getSkinDefById(skinId);
        this.viewModelSkinId = skin.id;
        if (this._thirdPersonBody) {
            this._thirdPersonBody.head.material.color.setHex(skin.head);
            this._thirdPersonBody.torso.material.color.setHex(skin.body);
            this._thirdPersonBody.armL.material.color.setHex(skin.body);
            this._thirdPersonBody.armR.material.color.setHex(skin.body);
            this._thirdPersonBody.legL.material.color.setHex(skin.legs);
            this._thirdPersonBody.legR.material.color.setHex(skin.legs);
        }
    }

    _updateThirdPersonBody(dt: number) {
        if (!this._thirdPersonBody) return;
        if (this.cameraMode === 0) {
            this._thirdPersonBody.group.visible = false;
            return;
        }

        this._thirdPersonBody.group.visible = true;
        this._thirdPersonBody.group.position.set(
            this.camera.position.x,
            this.camera.position.y - 1.62,
            this.camera.position.z
        );

        const dir = new THREE.Vector3();
        this.camera.getWorldDirection(dir);
        this._thirdPersonBody.group.rotation.y = Math.atan2(dir.x, dir.z);

        if (this.viewSwing > 0) {
            this._thirdPersonBody.armR.rotation.x = -0.8 + Math.sin(this.viewSwing * Math.PI * 2) * 0.6;
        } else if (this.isMoving && this.onGround) {
            this._thirdPersonBody.walkTime += dt * 10;
            const swing = Math.sin(this._thirdPersonBody.walkTime) * 0.6;
            this._thirdPersonBody.legL.rotation.x = swing;
            this._thirdPersonBody.legR.rotation.x = -swing;
            this._thirdPersonBody.armL.rotation.x = -swing * 0.7;
            this._thirdPersonBody.armR.rotation.x = swing * 0.7;
        } else {
            this._thirdPersonBody.legL.rotation.x = 0;
            this._thirdPersonBody.legR.rotation.x = 0;
            this._thirdPersonBody.armL.rotation.x = 0;
            this._thirdPersonBody.armR.rotation.x = 0;
        }
    }

    updateFirstPersonView(dt: number) {
        if (!this.viewModel) return;
        this.viewModel.root.visible = this.controls.isLocked && (this.cameraMode === 0);
        if (!this.viewModel.root.visible) return;

        if (this.viewSwing > 0) {
            const swingPhase = (this.viewSwing % 1);
            const curve = Math.sin(swingPhase * Math.PI);
            this.viewModel.root.rotation.x = -0.18 - curve * 0.6;
            this.viewModel.root.rotation.y = 0.26 - curve * 0.35;
            this.viewModel.root.rotation.z = 0.05 + curve * 0.25;
            this.viewModel.root.position.x = 0.56 - curve * 0.08;
            this.viewModel.root.position.y = -0.42 + curve * 0.1;
            this.viewModel.root.position.z = -0.72 + curve * 0.15;
        } else {
            this.viewModel.root.rotation.set(-0.18, 0.26, 0.05);
            this.viewModel.root.position.set(0.56, -0.42, -0.72);
        }

        // Held Wind Charge animation in first-person view
        if (this.viewModel.windChargeModel) {
            const active = this.inventory.getSelectedEntry();
            const isHoldingWindCharge = (active?.kind === 'resource' && active?.id === RESOURCE_ITEM.WIND_CHARGE);
            this.viewModel.windChargeModel.visible = isHoldingWindCharge;

            if (isHoldingWindCharge) {
                this.viewModel.windChargeModel.rotation.y += dt * 3.5;
                if (this.viewModel.ring1) this.viewModel.ring1.rotation.z += dt * 4.2;
                if (this.viewModel.ring2) this.viewModel.ring2.rotation.x += dt * 5.0;
            }
        }
    }

    calculateMiningTime(blockId: number): number {
        if (this.survival.isCreative()) return 0.0;
        const hardness = getBlockHardness(blockId);
        if (hardness <= 0) return 0.05;

        const preferredTool = getPreferredToolType(blockId);
        const selected = this.inventory.getSelectedEntry();
        let currentToolType: string | null = null;
        let toolSpeed = 1.0;

        if (selected && selected.kind === 'resource') {
            const resDef = (RESOURCE_DEFS as any)[selected.id];
            if (resDef && resDef.tool) {
                currentToolType = resDef.toolType || null;
                toolSpeed = resDef.miningSpeed || 1.0;
            }
        }

        const hasCorrectTool = preferredTool && currentToolType === preferredTool;

        if (hasCorrectTool) {
            let speedMultiplier = 2.0;
            if (toolSpeed <= 1.8) speedMultiplier = 2.0;      // Wood
            else if (toolSpeed <= 2.2) speedMultiplier = 3.5; // Stone / Gold
            else if (toolSpeed <= 2.6) speedMultiplier = 5.0; // Iron
            else if (toolSpeed <= 2.9) speedMultiplier = 7.0; // Diamond
            else speedMultiplier = 9.0;                       // Ruby
            return Math.max(0.08, (hardness * 1.5) / speedMultiplier);
        } else {
            if (preferredTool === 'pickaxe') {
                return Math.max(0.5, hardness * 5.0); // Stone: 7.5s, Ores: 15s by hand
            } else {
                return Math.max(0.1, hardness * 1.5); // Dirt: 0.75s, Wood: 3s by hand
            }
        }
    }

    bindEvents() {
        document.addEventListener('keydown', (e) => {
            const target = e.target as HTMLElement;
            if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
            this.audio?.touch?.();

            if (e.code === 'KeyW') this.moveState.f = true;
            if (e.code === 'KeyS') this.moveState.b = true;
            if (e.code === 'KeyA') this.moveState.l = true;
            if (e.code === 'KeyD') this.moveState.r = true;
            if (e.code === 'ControlLeft') this.moveState.run = true;
            if (e.code === 'ShiftLeft') this.moveState.crouch = true;
            if (e.code === 'KeyE') {
                e.preventDefault();
                if (this.inventory.isExpandedVisible()) {
                    this.inventory.hideExpanded();
                    this.controls.lock();
                } else {
                    this.controls.unlock();
                    this.inventory.showExpanded();
                }
                return;
            }
            if (e.code === 'Space') {
                this.moveState.jump = true;
                if (this.survival.isCreative()) {
                    const now = performance.now();
                    if (now - this.lastSpacePress < 350) {
                        this.isFlying = !this.isFlying;
                        this.velocity.y = 0;
                        (window as any).app?.showHelpTipFor(
                            this.isFlying ? 'Flying enabled! (Space: Ascend, Shift: Descend)' : 'Flying disabled',
                            2200
                        );
                    }
                    this.lastSpacePress = now;
                }
                if (this.onGround && !this.isFlying) {
                    this.velocity.y = CONFIG.JUMP_FORCE;
                    this.survival.onJumpAction();
                    this.audio?.playJump();
                }
            }
            if (e.code === 'KeyQ') {
                if (!this.inventory.isInventoryOpen()) {
                    const selected = this.inventory.getSelected();
                    if (selected) {
                        const forward = new THREE.Vector3();
                        this.camera.getWorldDirection(forward);
                        const dropPos = this.camera.position.clone().addScaledVector(forward, 0.85);
                        const dropVel = forward.clone().multiplyScalar(3.8);
                        dropVel.y += 1.6;

                        if (selected.kind === 'block') {
                            const count = this.inventory.getBlockCount(selected.id);
                            if (count > 0) {
                                if (!this.survival.isCreative()) {
                                    this.inventory.setCount('block', selected.id, count - 1);
                                    this.inventory.triggerChange();
                                }
                                this.droppedItemManager.spawn({ kind: 'block', id: selected.id, count: 1 }, dropPos, dropVel, 1.0);
                                this.audio?.playPop?.();
                            }
                        } else {
                            const count = this.inventory.getResourceCount(selected.id);
                            if (count > 0) {
                                if (!this.survival.isCreative()) {
                                    this.inventory.setCount('resource', selected.id, count - 1);
                                    this.inventory.triggerChange();
                                }
                                this.droppedItemManager.spawn({ kind: 'resource', id: selected.id, count: 1 }, dropPos, dropVel, 1.0);
                                this.audio?.playPop?.();
                            }
                        }
                    }
                }
                return;
            }
            if (e.code === 'KeyF') {
                if (!this.survival.isCreative()) {
                    if (this.survival.hunger < this.survival.maxHunger) {
                        this.survival.eat(4);
                        (window as any).app?.showHelpTipFor('Ate food: Hunger restored, hearts healing!', 2200);
                    } else {
                        (window as any).app?.showHelpTipFor('Hunger is already full! Hearts will regenerate automatically.', 2200);
                    }
                }
            }
            if (e.code === 'KeyV') {
                this.friendlyMobManager?.tryOpenTrade(this.camera.position);
            }
            if (e.code === 'F5') {
                e.preventDefault();
                this.toggleCameraMode();
            }
            if (e.key >= '1' && e.key <= '9') {
                this.setSlot(parseInt(e.key));
            }
        });

        document.addEventListener('keyup', (e) => {
            if (e.code === 'KeyW') this.moveState.f = false;
            if (e.code === 'KeyS') this.moveState.b = false;
            if (e.code === 'KeyA') this.moveState.l = false;
            if (e.code === 'KeyD') this.moveState.r = false;
            if (e.code === 'ControlLeft') this.moveState.run = false;
            if (e.code === 'ShiftLeft') this.moveState.crouch = false;
            if (e.code === 'Space') this.moveState.jump = false;
        });

        document.addEventListener('mousedown', (e) => {
            this.audio?.touch?.();
            if (e.button === 0) {
                this.isLeftMouseDown = true;
                this.creativeBreakTimer = 0.2;
            }
            this.handleAction(e);
        });

        document.addEventListener('mouseup', (e) => {
            if (e.button === 0) {
                this.isLeftMouseDown = false;
                if (this.breakState.active) {
                    this.breakState.active = false;
                    this.breakState.key = '';
                    this.breakState.progress = 0;
                    this.world.hideBreakOverlay();
                }
            }
        });

        document.getElementById('btn-resume')?.addEventListener('click', () => this.controls.lock());
    }

    setSlot(idx: number) {
        this.activeSlot = idx;
        this.inventory.selectSlot(idx - 1);
    }

    getTargetBlock(): { x: number; y: number; z: number; id: number; hit: THREE.Intersection } | null {
        this.ray.setFromCamera(new THREE.Vector2(0, 0), this.camera);
        this.ray.far = CONFIG.REACH_DISTANCE;
        const hits = this.ray.intersectObjects(this.world.raycastTargets, false);
        const hit = hits.find((h) => h.face);
        if (!hit || !hit.face) return null;

        let bx = 0;
        let by = 0;
        let bz = 0;

        if (hit.object instanceof THREE.InstancedMesh && typeof hit.instanceId === 'number') {
            const mat = new THREE.Matrix4();
            hit.object.getMatrixAt(hit.instanceId, mat);
            const center = new THREE.Vector3().setFromMatrixPosition(mat);
            const blockIdOnMesh = (hit.object.userData?.blockId) as number | undefined;
            const isPlant = (blockIdOnMesh === BLOCK_ID.TALL_GRASS || blockIdOnMesh === BLOCK_ID.FLOWER_RED || blockIdOnMesh === BLOCK_ID.FLOWER_YELLOW);
            bx = Math.round(center.x - 0.5);
            by = isPlant ? Math.round(center.y) : Math.round(center.y - 0.5);
            bz = Math.round(center.z - 0.5);
        } else {
            const normal = hit.face.normal.clone();
            normal.transformDirection(hit.object.matrixWorld);
            const p = hit.point.clone().sub(normal.clone().multiplyScalar(0.04));
            bx = Math.floor(p.x);
            by = Math.floor(p.y);
            bz = Math.floor(p.z);
        }

        let blockId = this.world.getVoxel(bx, by, bz);
        // Fallback: if center coordinate resolved to air (e.g. edge boundary), fallback to surface penetration
        if (blockId === BLOCK_ID.AIR) {
            const normal = hit.face.normal.clone();
            normal.transformDirection(hit.object.matrixWorld);
            const p = hit.point.clone().sub(normal.clone().multiplyScalar(0.05));
            const altBx = Math.floor(p.x);
            const altBy = Math.floor(p.y);
            const altBz = Math.floor(p.z);
            const altId = this.world.getVoxel(altBx, altBy, altBz);
            if (altId !== BLOCK_ID.AIR && altId !== BLOCK_ID.WATER && altId !== BLOCK_ID.LAVA) {
                bx = altBx;
                by = altBy;
                bz = altBz;
                blockId = altId;
            }
        }

        if (blockId === BLOCK_ID.AIR || blockId === BLOCK_ID.WATER || blockId === BLOCK_ID.LAVA) {
            return null;
        }

        return { x: bx, y: by, z: bz, id: blockId, hit };
    }

    raycastMobs(): { mobId: string; kind: 'friendly' | 'hostile'; hit: THREE.Intersection } | null {
        const mobGroups: THREE.Object3D[] = [];
        if (this.friendlyMobManager) {
            this.friendlyMobManager.entities.forEach(e => {
                if (e.group && e.group.visible) mobGroups.push(e.group);
            });
        }
        if (this.hostileMobManager) {
            this.hostileMobManager.entities.forEach(e => {
                if (e.group && e.group.visible) mobGroups.push(e.group);
            });
        }
        if (mobGroups.length === 0) return null;

        const active = this.inventory.getSelectedEntry();
        const isLongReach = active && active.kind === 'resource' && (active.id.includes('spear') || active.id.includes('trident'));
        this.ray.setFromCamera(new THREE.Vector2(0, 0), this.camera);
        this.ray.far = isLongReach ? (CONFIG.REACH_DISTANCE + 2.8) : (CONFIG.REACH_DISTANCE + 0.5);

        const intersects = this.ray.intersectObjects(mobGroups, true);
        if (intersects.length === 0) return null;

        const firstHit = intersects[0];
        let obj: THREE.Object3D | null = firstHit.object;
        let mobId: string | null = null;
        let mobKind: 'friendly' | 'hostile' = 'friendly';

        while (obj && !mobId) {
            if (obj.userData?.mobId) {
                mobId = obj.userData.mobId;
                mobKind = obj.userData.mobKind || 'friendly';
                break;
            }
            obj = obj.parent;
        }

        if (mobId) {
            return { mobId, kind: mobKind, hit: firstHit };
        }
        return null;
    }

    attackMob(mobHit: { mobId: string; kind: 'friendly' | 'hostile'; hit: THREE.Intersection }) {
        if (this.meleeCooldown > 0) return;
        this.meleeCooldown = 0.35;

        const activeItem = this.inventory.getSelectedEntry();
        let damage = 1.0;
        let isMaceSmash = false;

        if (activeItem && activeItem.kind === 'resource') {
            const id = activeItem.id as string;
            const def = (RESOURCE_DEFS as any)[id];
            if (def && typeof def.attackDamage === 'number') {
                damage = def.attackDamage;
            } else if (id.includes('mace')) {
                damage = 7.0;
            } else if (id.includes('spear') || id.includes('trident')) {
                damage = 6.5;
            } else if (id.includes('sword')) {
                damage = 6.0;
            } else if (id.includes('axe')) {
                damage = 5.0;
            } else if (id.includes('pickaxe')) {
                damage = 3.0;
            } else if (id.includes('shovel')) {
                damage = 2.0;
            }

            // Minecraft 1.21 Heavy Mace Smash mechanic:
            // Falling from height deals massive bonus damage, resets fall damage, and launches player upward
            if (id.includes('mace') && !this.onGround && this.velocity.y < -0.04) {
                const fallDistance = Math.max(1, (this.fallStartY - this.camera.position.y));
                const maceBonus = Math.round(fallDistance * 4.5);
                damage += maceBonus;
                isMaceSmash = true;
                // Negate fall damage & upward bounce recoil
                this.fallStartY = this.camera.position.y;
                this.velocity.y = 0.16;
                // Audio & visual impact
                this.audio?.playTone?.(140, 60, 0.25);
                (window as any).app?.particleKernel?.spawnDebris?.(mobHit.hit.point.x, mobHit.hit.point.y, mobHit.hit.point.z, 0xaaaaaa);
            }
        }

        const isCrit = !this.onGround && this.velocity.y < 0 && !isMaceSmash;
        if (isCrit) {
            damage = Math.round(damage * 1.5);
            this.audio?.playTone?.(380, 240, 0.12);
        } else if (!isMaceSmash) {
            this.audio?.playTone?.(220, 140, 0.08);
        }

        let damaged = false;
        if (mobHit.kind === 'friendly' && this.friendlyMobManager) {
            damaged = this.friendlyMobManager.applyDamageFromHit(mobHit.hit, damage, this.camera.position);
        } else if (mobHit.kind === 'hostile' && this.hostileMobManager) {
            damaged = this.hostileMobManager.applyDamageFromHit(mobHit.hit, damage, this.camera.position);
        }

        if (damaged) {
            this.viewSwing = 0.5;
            let note = `⚔️ Dealt ${damage} damage`;
            if (isMaceSmash) note = `🔨 HEAVY MACE SMASH! Dealt ${damage} damage (Fall Negated!)`;
            else if (isCrit) note += ' 💥 CRITICAL!';
            (window as any).app?.showHelpTipFor?.(note, 1800);
        }
    }

    launchWindCharge() {
        if (!this.windChargeManager) return;
        const dir = new THREE.Vector3();
        this.camera.getWorldDirection(dir);

        // Spawn wind charge projectile from camera viewpoint
        const origin = this.camera.position.clone().addScaledVector(dir, 0.65);
        this.windChargeManager.launch(origin, dir, 25.0, true);

        this.audio?.playWindChargeLaunch?.();
        this.viewSwing = 0.5;

        // Consume 1 charge in survival/hardcore
        if (!this.survival.isCreative()) {
            this.inventory.consumeSelectedEntry();
        }

        (window as any).app?.showHelpTipFor?.('💨 Wind Charge Launched! Detonate near your feet to Wind Jump!', 2400);
    }

    handleAction(e: MouseEvent) {
        if (!this.controls.isLocked) return;

        if (e.button === 0) {
            this.audio?.playSwing();
            this.viewSwing = 0.01;

            // 1. Attack mob priority
            const mobHit = this.raycastMobs();
            const blockTarget = this.getTargetBlock();

            if (mobHit && (!blockTarget || mobHit.hit.distance <= blockTarget.hit.distance + 0.3)) {
                this.attackMob(mobHit);
                return;
            }

            // 2. Start / do mining
            if (blockTarget) {
                const bx = blockTarget.x;
                const by = blockTarget.y;
                const bz = blockTarget.z;
                const blockId = blockTarget.id;

                if (this.survival.isCreative()) {
                    this.world.setVoxel(bx, by, bz, BLOCK_ID.AIR, true);
                    this.particleKernel?.spawnBlockBreak(bx, by, bz, blockId);
                    this.audio?.playBlockBreak(blockId);
                    this.world.hideBreakOverlay();
                } else {
                    const hardness = getBlockHardness(blockId);
                    if (hardness >= 0 && hardness <= 0.05) {
                        // Instant-break block (flowers, tall grass, tnt)
                        this.world.setVoxel(bx, by, bz, BLOCK_ID.AIR);
                        this.particleKernel?.spawnBlockBreak(bx, by, bz, blockId);
                        const drop = getBlockDrop(blockId);
                        if (drop && drop.count > 0) {
                            const spawnPos = new THREE.Vector3(bx + 0.5, by + 0.35, bz + 0.5);
                            this.droppedItemManager.spawn(drop, spawnPos);
                        }
                        this.audio?.playBlockBreak(blockId);
                        this.world.hideBreakOverlay();
                    } else if (blockId !== BLOCK_ID.BEDROCK && hardness >= 0) {
                        const key = `${bx},${by},${bz}`;
                        this.breakState.active = true;
                        this.breakState.key = key;
                        this.breakState.x = bx;
                        this.breakState.y = by;
                        this.breakState.z = bz;
                        this.breakState.blockId = blockId;
                        this.breakState.progress = 0;
                        this.breakState.totalTime = this.calculateMiningTime(blockId);
                        this.breakHitTimer = 0;
                        this.breakGraceTimer = 0;
                    }
                }
            }
        } else if (e.button === 2) {
            const active = this.inventory.getSelectedEntry();

            // 1. Wind Charge Launch!
            if (active && active.kind === 'resource' && active.id === RESOURCE_ITEM.WIND_CHARGE) {
                this.launchWindCharge();
                return;
            }

            // 2. Check if holding armor to equip directly from hand
            if (active && active.kind === 'resource') {
                const armorType = this.inventory.getArmorType(active.id);
                if (armorType) {
                    if (this.inventory.equipArmorFromHand(active.id)) {
                        this.updateArmorVisuals(this.inventory.armor);
                        return;
                    }
                }
            }

            // 2. Check if player is right-clicking a villager to trade
            if (this.friendlyMobManager?.tryOpenTrade(this.camera.position)) {
                return;
            }

            // 3. Spear / Trident extended thrust attack
            if (active && active.kind === 'resource' && (active.id.includes('spear') || active.id.includes('trident'))) {
                const mobHit = this.raycastMobs();
                if (mobHit) {
                    this.audio?.playSwing();
                    this.viewSwing = 0.6;
                    this.attackMob(mobHit);
                    return;
                }
            }

            // 4. Block interaction or placement
            const targetBlock = this.getTargetBlock();
            if (targetBlock) {
                const tbx = targetBlock.x;
                const tby = targetBlock.y;
                const tbz = targetBlock.z;
                const clickedId = targetBlock.id;

                if (clickedId === BLOCK_ID.CHEST) {
                    const loot = this.world.consumeChestLoot(tbx, tby, tbz);
                    if (loot && loot.length > 0) {
                        this.audio?.playChestOpen();
                        const names: string[] = [];
                        for (const item of loot) {
                            if (item.kind === 'block') {
                                this.inventory.addBlock(item.id, item.count);
                                const name = Object.entries(BLOCK_ID).find(([_, v]) => v === item.id)?.[0] || 'Block';
                                names.push(`${item.count}x ${name.replace('_', ' ')}`);
                            } else {
                                this.inventory.addResource(item.id, item.count);
                                const def = (RESOURCE_DEFS as any)[item.id];
                                names.push(`${item.count}x ${def ? def.label : item.id}`);
                            }
                        }
                        (window as any).app?.showHelpTipFor(`Looted Chest: ${names.join(', ')}`, 4500);
                        return;
                    } else {
                        (window as any).app?.showHelpTipFor('Chest is empty', 1800);
                        return;
                    }
                }

                const face = targetBlock.hit.face;
                if (face) {
                    const placeX = tbx + Math.round(face.normal.x);
                    const placeY = tby + Math.round(face.normal.y);
                    const placeZ = tbz + Math.round(face.normal.z);

                    const playerBlockX = Math.floor(this.camera.position.x);
                    const playerBlockY = Math.floor(this.camera.position.y);
                    const playerFeetY = Math.floor(this.camera.position.y - 1.2);
                    const playerBlockZ = Math.floor(this.camera.position.z);
                    const isInsidePlayer = (placeX === playerBlockX && placeZ === playerBlockZ && (placeY === playerBlockY || placeY === playerFeetY));

                    if (!isInsidePlayer) {
                        const blockId = this.inventory.getSelectedBlockId();
                        if (blockId !== null) {
                            this.world.setVoxel(placeX, placeY, placeZ, blockId);
                            this.inventory.consumeSelectedBlock();
                            this.audio?.playPlace(blockId);
                        }
                    }
                }
            }
        }
    }

    detectCollision(pos: THREE.Vector3): boolean {
        const r = 0.3;
        const h_min = -1.6;
        const h_max = 0.2;
        for (let x = Math.floor(pos.x - r); x <= Math.floor(pos.x + r); x++) {
            for (let y = Math.floor(pos.y + h_min); y <= Math.floor(pos.y + h_max); y++) {
                for (let z = Math.floor(pos.z - r); z <= Math.floor(pos.z + r); z++) {
                    const block = this.world.getVoxel(x, y, z);
                    if (BLOCK_DEFS[block] && BLOCK_DEFS[block].solid) return true;
                }
            }
        }
        return false;
    }

    update(dt: number) {
        // Restore eye position before physics if 3rd person was applied last frame
        if (this._tpOffsetApplied) {
            this.camera.position.copy(this._tpEyePos);
            this.camera.quaternion.copy(this._tpEyeQuat);
            this._tpOffsetApplied = false;
        }

        if (this.meleeCooldown > 0) {
            this.meleeCooldown = Math.max(0, this.meleeCooldown - dt);
        }

        if (!this.controls.isLocked) {
            this.world.hideHighlight();
            this.world.hideBreakOverlay();
            this._updateThirdPersonBody(dt);
            this.updateFirstPersonView(dt);
            return;
        }

        // Crosshair raycast: block outline highlighting using unified getTargetBlock
        const targetBlock = this.getTargetBlock();

        if (targetBlock) {
            this.world.setHighlightBlock(targetBlock.x, targetBlock.y, targetBlock.z);
        } else {
            this.world.hideHighlight();
        }

        // Mining logic (Survival time-based with breaking animation & Creative continuous)
        if (this.isLeftMouseDown) {
            if (targetBlock) {
                this.breakGraceTimer = 0;
                const isFluid = targetBlock.id === BLOCK_ID.WATER || targetBlock.id === BLOCK_ID.LAVA;
                if (!isFluid) {
                    if (this.survival.isCreative()) {
                        this.creativeBreakTimer += dt;
                        if (this.creativeBreakTimer >= 0.18) {
                            this.creativeBreakTimer = 0;
                            this.world.setVoxel(targetBlock.x, targetBlock.y, targetBlock.z, BLOCK_ID.AIR, true);
                            this.particleKernel?.spawnBlockBreak(targetBlock.x, targetBlock.y, targetBlock.z, targetBlock.id);
                            this.audio?.playBlockBreak(targetBlock.id);
                            this.world.hideBreakOverlay();
                        }
                        this.viewSwing += dt * 7;
                    } else {
                        const hardness = getBlockHardness(targetBlock.id);
                        if (targetBlock.id === BLOCK_ID.BEDROCK || hardness < 0) {
                            this.breakState.active = false;
                            this.breakState.key = '';
                            this.breakState.progress = 0;
                            this.world.hideBreakOverlay();
                        } else {
                            const key = `${targetBlock.x},${targetBlock.y},${targetBlock.z}`;
                            if (this.breakState.key !== key) {
                                this.breakState.active = true;
                                this.breakState.key = key;
                                this.breakState.x = targetBlock.x;
                                this.breakState.y = targetBlock.y;
                                this.breakState.z = targetBlock.z;
                                this.breakState.blockId = targetBlock.id;
                                this.breakState.progress = 0;
                                this.breakState.totalTime = this.calculateMiningTime(targetBlock.id);
                                this.breakHitTimer = 0;
                            }

                            this.breakState.progress += dt / Math.max(0.05, this.breakState.totalTime);
                            this.viewSwing += dt * 8;

                            this.breakHitTimer += dt;
                            if (this.breakHitTimer >= 0.22) {
                                this.breakHitTimer = 0;
                                this.audio?.playMineTick(targetBlock.id, this.breakState.progress);
                                this.particleKernel?.spawnBlockHit(targetBlock.x, targetBlock.y, targetBlock.z, targetBlock.id);
                            }

                            const stage = Math.min(9, Math.max(0, Math.floor(this.breakState.progress * 10)));
                            this.world.setBreakStage(targetBlock.x, targetBlock.y, targetBlock.z, stage);

                            if (this.breakState.progress >= 1.0) {
                                const bx = targetBlock.x;
                                const by = targetBlock.y;
                                const bz = targetBlock.z;
                                const blockId = targetBlock.id;

                                this.world.setVoxel(bx, by, bz, BLOCK_ID.AIR);
                                this.particleKernel?.spawnBlockBreak(bx, by, bz, blockId);
                                // Authentic Minecraft block drops: item entities drop in world to collect
                                const drop = getBlockDrop(blockId);
                                if (drop && drop.count > 0) {
                                    const spawnPos = new THREE.Vector3(bx + 0.5, by + 0.35, bz + 0.5);
                                    this.droppedItemManager.spawn(drop, spawnPos);
                                }
                                this.audio?.playBlockBreak(blockId);
                                this.survival.onMineAction();

                                // Deplete tool durability for tools (pickaxes, axes, shovels)
                                if (this.toolDurability) {
                                    this.toolDurability.onBlockMined(blockId);
                                } else if ((window as any).app?.toolDurability) {
                                    (window as any).app.toolDurability.onBlockMined(blockId);
                                }

                                this.world.hideBreakOverlay();
                                this.breakState.active = false;
                                this.breakState.key = '';
                                this.breakState.progress = 0;
                            }
                        }
                    }
                }
            } else {
                // If player is holding left click but briefly aimed away or jittered off edge:
                if (this.breakState.active) {
                    this.breakGraceTimer += dt;
                    if (this.breakGraceTimer >= 0.22) {
                        this.breakState.active = false;
                        this.breakState.key = '';
                        this.breakState.progress = 0;
                        this.world.hideBreakOverlay();
                    }
                }
            }
        } else {
            if (this.breakState.active) {
                this.breakState.active = false;
                this.breakState.key = '';
                this.breakState.progress = 0;
                this.world.hideBreakOverlay();
            }
            this.creativeBreakTimer = 0.2;
            this.breakGraceTimer = 0;
            if (this.viewSwing > 0) {
                this.viewSwing = Math.max(0, this.viewSwing - dt * 6);
            }
        }

        const eyeX = Math.floor(this.camera.position.x);
        const eyeY = Math.floor(this.camera.position.y);
        const eyeZ = Math.floor(this.camera.position.z);
        const feetY = Math.floor(this.camera.position.y - 1.2);
        const inWater = (this.world.getVoxel(eyeX, eyeY, eyeZ) === BLOCK_ID.WATER || this.world.getVoxel(eyeX, feetY, eyeZ) === BLOCK_ID.WATER);

        if (this.isFlying && this.survival.isCreative()) {
            this.velocity.y = 0;
            this.fallStartY = this.camera.position.y;
            let vert = 0;
            if (this.moveState.jump) vert += 10 * dt;
            if (this.moveState.crouch) vert -= 10 * dt;
            this.camera.position.y += vert;
            if (this.detectCollision(this.camera.position)) {
                this.camera.position.y -= vert;
            }
            this.onGround = false;
        } else {
            if (inWater) {
                this.fallStartY = this.camera.position.y;
                if (this.moveState.jump) {
                    this.velocity.y = 0.08;
                } else {
                    this.velocity.y = Math.max(this.velocity.y - 0.006, -0.05);
                }
            } else {
                this.velocity.y += CONFIG.WORLD_GRAVITY;
                this.velocity.y = Math.max(this.velocity.y, CONFIG.TERMINAL_VELOCITY);
            }

            this.camera.position.y += this.velocity.y;
            if (this.detectCollision(this.camera.position)) {
                if (this.velocity.y < 0) {
                    this.onGround = true;
                    const fallDistance = Math.max(0, this.fallStartY - this.camera.position.y);

                    // Landing particles & impact audio for jumps and falls
                    if (fallDistance > 0.75) {
                        const px = this.camera.position.x;
                        const pz = this.camera.position.z;
                        const feetY = this.camera.position.y - 1.62;
                        const bx = Math.floor(px);
                        const by = Math.floor(feetY - 0.1);
                        const bz = Math.floor(pz);
                        let groundBlock = this.world.getVoxel(bx, by, bz);
                        if (groundBlock === BLOCK_ID.AIR) groundBlock = this.world.getVoxel(bx, by - 1, bz);

                        if (groundBlock !== BLOCK_ID.AIR && groundBlock !== BLOCK_ID.WATER && groundBlock !== BLOCK_ID.LAVA) {
                            this.particleKernel?.spawnLandingDust(px, feetY, pz, groundBlock, fallDistance);
                            if (fallDistance > 1.8) {
                                this.audio?.playLand(fallDistance);
                            }
                        }
                    }

                    // Minecraft authentic fall damage:
                    // Fall damage = Math.floor(fallDistance - 3.0)
                    if (!this.survival.isCreative() && !inWater) {
                        if (fallDistance > 3.0) {
                            const damage = Math.floor(fallDistance - 3.0);
                            if (damage > 0) {
                                this.survival.damage(damage);
                                this.audio?.playDamage(damage);
                            }
                        }
                    }
                    this.fallStartY = this.camera.position.y;
                }
                this.camera.position.y -= this.velocity.y;
                this.velocity.y = 0;
            } else {
                this.onGround = false;
                if (this.camera.position.y > this.fallStartY) {
                    this.fallStartY = this.camera.position.y;
                }
            }
        }

        let speed = this.moveState.run ? CONFIG.RUN_SPEED : CONFIG.WALK_SPEED;
        if (this.isFlying && this.survival.isCreative()) speed *= 1.6;
        else if (inWater) speed *= 0.65;
        const fwd = this.tempForward;
        this.camera.getWorldDirection(fwd);
        fwd.y = 0;
        fwd.normalize();
        const side = this.tempSide.crossVectors(fwd, this.camera.up).normalize();

        const move = this.tempMove.set(0, 0, 0);
        if (this.moveState.f) move.add(fwd);
        if (this.moveState.b) move.sub(fwd);
        if (this.moveState.l) move.sub(side);
        if (this.moveState.r) move.add(side);
        if (move.length() > 0) move.normalize().multiplyScalar(speed);
        this.isMoving = move.length() > 0;
        this.isSprinting = this.isMoving && this.moveState.run;

        this.camera.position.x += move.x;
        if (this.detectCollision(this.camera.position)) this.camera.position.x -= move.x;
        this.camera.position.z += move.z;
        if (this.detectCollision(this.camera.position)) this.camera.position.z -= move.z;

        // Footstep audio and particle effects across different materials (sand, grass, stone, wood, etc.)
        if (this.isMoving && this.onGround && !this.isFlying) {
            this.stepTimer += dt * (this.isSprinting ? 1.5 : 1.0);
            const stepCadence = 0.40;
            if (this.stepTimer >= stepCadence) {
                this.stepTimer = 0;
                const px = this.camera.position.x;
                const pz = this.camera.position.z;
                const feetY = this.camera.position.y - 1.62;
                const bx = Math.floor(px);
                const by = Math.floor(feetY - 0.1);
                const bz = Math.floor(pz);
                let groundBlock = this.world.getVoxel(bx, by, bz);
                if (groundBlock === BLOCK_ID.AIR) groundBlock = this.world.getVoxel(bx, by - 1, bz);

                if (inWater) {
                    this.particleKernel?.spawnWaterSplash(px, feetY + 0.2, pz, this.isSprinting);
                } else if (groundBlock !== BLOCK_ID.AIR && groundBlock !== BLOCK_ID.LAVA) {
                    this.audio?.playStep(groundBlock, this.isSprinting, this.moveState.crouch);
                    if (!this.moveState.crouch) {
                        const heading = move.clone().normalize();
                        this.particleKernel?.spawnFootstep(px, feetY, pz, groundBlock, this.isSprinting, heading);
                    }
                }
            }
        } else {
            this.stepTimer = 0.32;
        }

        // Apply 3rd-person camera offset for rendering
        this._updateThirdPersonBody(dt);
        if (this.cameraMode !== 0) {
            this._tpEyePos.copy(this.camera.position);
            this._tpEyeQuat.copy(this.camera.quaternion);
            this._tpOffsetApplied = true;
            const dir = new THREE.Vector3();
            this.camera.getWorldDirection(dir);
            const dist = this.thirdPersonDist;
            if (this.cameraMode === 1) {
                this.camera.position.addScaledVector(dir, -dist);
                this.camera.position.y += 0.3;
            } else {
                this.camera.position.addScaledVector(dir, dist);
                this.camera.position.y += 0.3;
                this.camera.rotateY(Math.PI);
            }
        }
        this.updateFirstPersonView(dt);
    }

    getMovementState() {
        return { moving: this.isMoving, sprinting: this.isSprinting };
    }
}
