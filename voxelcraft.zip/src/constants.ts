// ==============================================================
// VOXELCRAFT - CONSTANTS & CONFIGURATION
// ==============================================================

export const CONFIG = {
    CHUNK_SIZE: 16,
    CHUNK_HEIGHT: 96,
    WORLD_MIN_Y: -85,
    BEDROCK_Y: -85,
    RENDER_DISTANCE: 3,
    WORLD_GRAVITY: -0.018,
    WALK_SPEED: 0.09,
    RUN_SPEED: 0.17,
    CROUCH_SPEED: 0.045,
    JUMP_FORCE: 0.21,
    TERMINAL_VELOCITY: -0.9,
    WATER_LEVEL: 30,
    TICK_RATE: 60,
    SEED: Math.random() * 999999,
    FOVY: 70,
    NEAR: 0.1,
    FAR: 900,
    REACH_DISTANCE: 5.5,
    MESH_UPDATES_PER_FRAME: 2,
    CHUNK_UNLOAD_MARGIN: 1,
    MAX_PIXEL_RATIO: 2,
    WATER_SURFACE_HEIGHT: 0.86,
    LAVA_SURFACE_HEIGHT: 0.84,
    LAVA_LEVEL: 10,
    NETHER_OFFSET_X: 96000,
    PORTAL_TRAVEL_TIME: 2.2,
    PORTAL_COOLDOWN_TIME: 3.2,
    VILLAGE_CHANCE: 0.978,
    RUIN_CHANCE: 0.90,
    OVERWORLD_STRUCTURE_CHANCE: 0.955,
    NETHER_STRUCTURE_CHANCE: 0.948,
    HOSTILE_SPAWN_MIN_LIGHT: 0.42
};

export const BLOCK_ID = {
    AIR: 0,
    GRASS: 1,
    DIRT: 2,
    STONE: 3,
    SAND: 4,
    WOOD: 5,
    LEAVES: 6,
    GLASS: 7,
    WATER: 8,
    BEDROCK: 9,
    COBBLESTONE: 10,
    LOG: 11,
    PLANKS: 12,
    COAL_ORE: 13,
    IRON_ORE: 14,
    LAPIS_ORE: 15,
    REDSTONE_ORE: 16,
    GOLD_ORE: 17,
    DIAMOND_ORE: 18,
    EMERALD_ORE: 19,
    CACTUS: 20,
    TALL_GRASS: 21,
    FLOWER_RED: 22,
    FLOWER_YELLOW: 23,
    RUBY_ORE: 24,
    LAVA: 25,
    OBSIDIAN: 26,
    GRAVEL: 27,
    CLAY: 28,
    SNOW: 29,
    BRICKS: 30,
    MOSSY_COBBLESTONE: 31,
    NETHER_PORTAL: 32,
    NETHERRACK: 33,
    SOUL_SAND: 34,
    GLOWSTONE: 35,
    NETHER_QUARTZ_ORE: 36,
    CHERRY_LEAVES: 37,
    MUSHROOM_CAP: 38,
    BAMBOO: 39,
    CHEST: 40,
    RED_LEAVES: 41,
    CRAFTING_TABLE: 42,
    FURNACE: 43,
    TNT: 44,
    PUMPKIN: 45,
    JACK_O_LANTERN: 46,
    BOOKSHELF: 47,
    HAY_BALE: 48,
    STONE_BRICKS: 49
};

export const BLOCK_DEFS: Record<number, { solid: boolean; transparent: boolean; color: number; opacity: number }> = {
    [BLOCK_ID.AIR]:        { solid: false, transparent: true,  color: 0x000000, opacity: 0 },
    [BLOCK_ID.GRASS]:      { solid: true,  transparent: false, color: 0x7cbd34, opacity: 1 },
    [BLOCK_ID.DIRT]:       { solid: true,  transparent: false, color: 0x966c4a, opacity: 1 },
    [BLOCK_ID.STONE]:      { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.SAND]:       { solid: true,  transparent: false, color: 0xf7e9a3, opacity: 1 },
    [BLOCK_ID.WOOD]:       { solid: true,  transparent: false, color: 0x8f7748, opacity: 1 },
    [BLOCK_ID.LEAVES]:     { solid: true,  transparent: false, color: 0x4b8f34, opacity: 1 },
    [BLOCK_ID.GLASS]:      { solid: true,  transparent: true,  color: 0xd0f5ff, opacity: 0.4 },
    [BLOCK_ID.WATER]:      { solid: false, transparent: true,  color: 0x3f76e4, opacity: 0.7 },
    [BLOCK_ID.BEDROCK]:    { solid: true,  transparent: false, color: 0x1c1c1c, opacity: 1 },
    [BLOCK_ID.COBBLESTONE]:{ solid: true,  transparent: false, color: 0x828282, opacity: 1 },
    [BLOCK_ID.LOG]:        { solid: true,  transparent: false, color: 0x7f623a, opacity: 1 },
    [BLOCK_ID.PLANKS]:     { solid: true,  transparent: false, color: 0xb8915b, opacity: 1 },
    [BLOCK_ID.COAL_ORE]:   { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.IRON_ORE]:   { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.LAPIS_ORE]:  { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.REDSTONE_ORE]: { solid: true, transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.GOLD_ORE]:   { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.DIAMOND_ORE]:{ solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.EMERALD_ORE]:{ solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.CACTUS]:     { solid: true,  transparent: false, color: 0x3f9b3f, opacity: 1 },
    [BLOCK_ID.TALL_GRASS]: { solid: false, transparent: true,  color: 0x6bb83b, opacity: 1 },
    [BLOCK_ID.FLOWER_RED]: { solid: false, transparent: true,  color: 0xca3f3f, opacity: 1 },
    [BLOCK_ID.FLOWER_YELLOW]: { solid: false, transparent: true, color: 0xe1c64f, opacity: 1 },
    [BLOCK_ID.RUBY_ORE]:   { solid: true,  transparent: false, color: 0x7d7d7d, opacity: 1 },
    [BLOCK_ID.LAVA]:       { solid: false, transparent: true,  color: 0xff6a00, opacity: 0.92 },
    [BLOCK_ID.OBSIDIAN]:   { solid: true,  transparent: false, color: 0x2d2048, opacity: 1 },
    [BLOCK_ID.GRAVEL]:     { solid: true,  transparent: false, color: 0x8a8a8a, opacity: 1 },
    [BLOCK_ID.CLAY]:       { solid: true,  transparent: false, color: 0xa1a8b1, opacity: 1 },
    [BLOCK_ID.SNOW]:       { solid: true,  transparent: false, color: 0xf2f7ff, opacity: 1 },
    [BLOCK_ID.BRICKS]:     { solid: true,  transparent: false, color: 0xa65245, opacity: 1 },
    [BLOCK_ID.MOSSY_COBBLESTONE]: { solid: true, transparent: false, color: 0x718067, opacity: 1 },
    [BLOCK_ID.NETHER_PORTAL]: { solid: false, transparent: true, color: 0x8f3fe9, opacity: 0.72 },
    [BLOCK_ID.NETHERRACK]: { solid: true, transparent: false, color: 0x7d3a33, opacity: 1 },
    [BLOCK_ID.SOUL_SAND]: { solid: true, transparent: false, color: 0x5f4b39, opacity: 1 },
    [BLOCK_ID.GLOWSTONE]: { solid: true, transparent: false, color: 0xd3aa54, opacity: 1 },
    [BLOCK_ID.NETHER_QUARTZ_ORE]: { solid: true, transparent: false, color: 0x8f4c42, opacity: 1 },
    [BLOCK_ID.CHERRY_LEAVES]: { solid: true, transparent: false, color: 0xe8a7be, opacity: 1 },
    [BLOCK_ID.RED_LEAVES]: { solid: true, transparent: false, color: 0xba2d22, opacity: 1 },
    [BLOCK_ID.MUSHROOM_CAP]: { solid: true, transparent: false, color: 0xbf5049, opacity: 1 },
    [BLOCK_ID.BAMBOO]: { solid: true, transparent: false, color: 0x8dc561, opacity: 1 },
    [BLOCK_ID.CHEST]: { solid: true, transparent: false, color: 0xb97f3f, opacity: 1 },
    [BLOCK_ID.CRAFTING_TABLE]: { solid: true, transparent: false, color: 0xb58245, opacity: 1 },
    [BLOCK_ID.FURNACE]:        { solid: true, transparent: false, color: 0x7a7a7a, opacity: 1 },
    [BLOCK_ID.TNT]:            { solid: true, transparent: false, color: 0xdb3223, opacity: 1 },
    [BLOCK_ID.PUMPKIN]:        { solid: true, transparent: false, color: 0xe07916, opacity: 1 },
    [BLOCK_ID.JACK_O_LANTERN]: { solid: true, transparent: false, color: 0xe68a19, opacity: 1 },
    [BLOCK_ID.BOOKSHELF]:      { solid: true, transparent: false, color: 0x936b3e, opacity: 1 },
    [BLOCK_ID.HAY_BALE]:       { solid: true, transparent: false, color: 0xcca825, opacity: 1 },
    [BLOCK_ID.STONE_BRICKS]:   { solid: true, transparent: false, color: 0x828282, opacity: 1 }
};

export const ORE_BLOCKS = new Set([
    BLOCK_ID.COAL_ORE,
    BLOCK_ID.IRON_ORE,
    BLOCK_ID.LAPIS_ORE,
    BLOCK_ID.REDSTONE_ORE,
    BLOCK_ID.GOLD_ORE,
    BLOCK_ID.DIAMOND_ORE,
    BLOCK_ID.EMERALD_ORE,
    BLOCK_ID.RUBY_ORE
]);

export const OVERWORLD_STRUCTURE_BIOMES = new Set([
    'PLAINS', 'MEADOW', 'FOREST', 'SAVANNA', 'TAIGA', 'DESERT', 'BADLANDS', 'MOUNTAINS', 'WINDSWEPT_HILLS'
]);
export const RUIN_BIOMES = new Set([
    'PLAINS', 'MEADOW', 'FOREST', 'SAVANNA', 'TAIGA', 'DESERT', 'BADLANDS', 'MOUNTAINS', 'WINDSWEPT_HILLS'
]);
export const VILLAGE_BIOMES = new Set([
    'PLAINS', 'MEADOW', 'FOREST', 'DESERT', 'SAVANNA', 'TAIGA', 'SNOWY_TAIGA'
]);

export const HOTBAR_PLACEABLE_BLOCKS = [
    BLOCK_ID.GRASS,
    BLOCK_ID.DIRT,
    BLOCK_ID.STONE,
    BLOCK_ID.PLANKS,
    BLOCK_ID.COBBLESTONE,
    BLOCK_ID.CRAFTING_TABLE,
    BLOCK_ID.FURNACE,
    BLOCK_ID.TNT,
    BLOCK_ID.JACK_O_LANTERN
];

export const CREATIVE_BLOCK_INVENTORY = Object.values(BLOCK_ID).filter((id) => {
    if (!Number.isInteger(id)) return false;
    if (id === BLOCK_ID.AIR) return false;
    if (id === BLOCK_ID.WATER || id === BLOCK_ID.LAVA) return false;
    if (id === BLOCK_ID.BEDROCK || id === BLOCK_ID.NETHER_PORTAL) return false;
    return true;
});

export function getBlockHardness(blockId: number): number {
    switch (blockId) {
        case BLOCK_ID.AIR:
        case BLOCK_ID.WATER:
        case BLOCK_ID.LAVA:
            return -1; // Unminable in all modes
        case BLOCK_ID.BEDROCK:
            return -1; // Unbreakable in survival
        case BLOCK_ID.TNT:
            return 0.0; // Instant punch/prime
        case BLOCK_ID.TALL_GRASS:
        case BLOCK_ID.FLOWER_RED:
        case BLOCK_ID.FLOWER_YELLOW:
            return 0.05; // Instant break
        case BLOCK_ID.LEAVES:
        case BLOCK_ID.CHERRY_LEAVES:
        case BLOCK_ID.RED_LEAVES:
            return 0.2;
        case BLOCK_ID.GLASS:
        case BLOCK_ID.GLOWSTONE:
            return 0.3;
        case BLOCK_ID.CACTUS:
        case BLOCK_ID.BAMBOO:
        case BLOCK_ID.NETHERRACK:
            return 0.4;
        case BLOCK_ID.DIRT:
        case BLOCK_ID.SAND:
        case BLOCK_ID.GRAVEL:
        case BLOCK_ID.SOUL_SAND:
        case BLOCK_ID.SNOW:
        case BLOCK_ID.HAY_BALE:
            return 0.5;
        case BLOCK_ID.GRASS:
        case BLOCK_ID.CLAY:
            return 0.6;
        case BLOCK_ID.PUMPKIN:
        case BLOCK_ID.JACK_O_LANTERN:
            return 1.0;
        case BLOCK_ID.STONE:
        case BLOCK_ID.BRICKS:
        case BLOCK_ID.STONE_BRICKS:
        case BLOCK_ID.BOOKSHELF:
            return 1.5;
        case BLOCK_ID.COBBLESTONE:
        case BLOCK_ID.MOSSY_COBBLESTONE:
        case BLOCK_ID.LOG:
        case BLOCK_ID.WOOD:
        case BLOCK_ID.PLANKS:
        case BLOCK_ID.CHEST:
        case BLOCK_ID.CRAFTING_TABLE:
            return 2.0;
        case BLOCK_ID.COAL_ORE:
        case BLOCK_ID.IRON_ORE:
        case BLOCK_ID.LAPIS_ORE:
        case BLOCK_ID.REDSTONE_ORE:
        case BLOCK_ID.GOLD_ORE:
        case BLOCK_ID.DIAMOND_ORE:
        case BLOCK_ID.EMERALD_ORE:
        case BLOCK_ID.RUBY_ORE:
            return 3.0;
        case BLOCK_ID.FURNACE:
            return 3.5;
        case BLOCK_ID.OBSIDIAN:
            return 50.0;
        default:
            return 1.0;
    }
}

export function getPreferredToolType(blockId: number): 'pickaxe' | 'axe' | 'shovel' | 'sword' | null {
    switch (blockId) {
        case BLOCK_ID.STONE:
        case BLOCK_ID.COBBLESTONE:
        case BLOCK_ID.MOSSY_COBBLESTONE:
        case BLOCK_ID.BRICKS:
        case BLOCK_ID.STONE_BRICKS:
        case BLOCK_ID.FURNACE:
        case BLOCK_ID.COAL_ORE:
        case BLOCK_ID.IRON_ORE:
        case BLOCK_ID.LAPIS_ORE:
        case BLOCK_ID.REDSTONE_ORE:
        case BLOCK_ID.GOLD_ORE:
        case BLOCK_ID.DIAMOND_ORE:
        case BLOCK_ID.EMERALD_ORE:
        case BLOCK_ID.RUBY_ORE:
        case BLOCK_ID.NETHERRACK:
        case BLOCK_ID.GLOWSTONE:
        case BLOCK_ID.OBSIDIAN:
            return 'pickaxe';
        case BLOCK_ID.LOG:
        case BLOCK_ID.WOOD:
        case BLOCK_ID.PLANKS:
        case BLOCK_ID.CHEST:
        case BLOCK_ID.CRAFTING_TABLE:
        case BLOCK_ID.BOOKSHELF:
        case BLOCK_ID.PUMPKIN:
        case BLOCK_ID.JACK_O_LANTERN:
            return 'axe';
        case BLOCK_ID.DIRT:
        case BLOCK_ID.GRASS:
        case BLOCK_ID.SAND:
        case BLOCK_ID.GRAVEL:
        case BLOCK_ID.CLAY:
        case BLOCK_ID.SOUL_SAND:
        case BLOCK_ID.SNOW:
            return 'shovel';
        case BLOCK_ID.LEAVES:
        case BLOCK_ID.CHERRY_LEAVES:
        case BLOCK_ID.BAMBOO:
        case BLOCK_ID.TALL_GRASS:
        case BLOCK_ID.FLOWER_RED:
        case BLOCK_ID.FLOWER_YELLOW:
            return 'sword';
        default:
            return null;
    }
}

export function getBlockDrop(blockId: number): { kind: 'block' | 'resource'; id: any; count: number } | null {
    switch (blockId) {
        case BLOCK_ID.AIR:
        case BLOCK_ID.WATER:
        case BLOCK_ID.LAVA:
        case BLOCK_ID.NETHER_PORTAL:
        case BLOCK_ID.BEDROCK:
            return null;
        case BLOCK_ID.STONE:
            return { kind: 'block', id: BLOCK_ID.COBBLESTONE, count: 1 };
        case BLOCK_ID.GRASS:
            return { kind: 'block', id: BLOCK_ID.DIRT, count: 1 };
        case BLOCK_ID.COAL_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 };
        case BLOCK_ID.IRON_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 1 };
        case BLOCK_ID.GOLD_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 1 };
        case BLOCK_ID.DIAMOND_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 1 };
        case BLOCK_ID.EMERALD_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.EMERALD, count: 1 };
        case BLOCK_ID.RUBY_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.RUBY, count: 1 };
        case BLOCK_ID.LAPIS_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.LAPIS, count: 2 + Math.floor(Math.random() * 3) };
        case BLOCK_ID.REDSTONE_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.REDSTONE, count: 3 + Math.floor(Math.random() * 3) };
        case BLOCK_ID.NETHER_QUARTZ_ORE:
            return { kind: 'resource', id: RESOURCE_ITEM.QUARTZ, count: 1 };
        case BLOCK_ID.GLASS:
            return null; // Glass breaks without drop
        case BLOCK_ID.TALL_GRASS:
            return Math.random() < 0.25 ? { kind: 'resource', id: RESOURCE_ITEM.WHEAT, count: 1 } : null;
        case BLOCK_ID.LEAVES:
        case BLOCK_ID.CHERRY_LEAVES:
        case BLOCK_ID.RED_LEAVES:
            if (Math.random() < 0.08) return { kind: 'resource', id: RESOURCE_ITEM.APPLE, count: 1 };
            if (Math.random() < 0.14) return { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 1 };
            return null;
        case BLOCK_ID.GRAVEL:
            return Math.random() < 0.12 ? { kind: 'resource', id: RESOURCE_ITEM.FLINT, count: 1 } : { kind: 'block', id: BLOCK_ID.GRAVEL, count: 1 };
        default:
            return { kind: 'block', id: blockId, count: 1 };
    }
}

export const BLOCK_KEY_TO_ID: Record<string, number> = {};
for (const [key, value] of Object.entries(BLOCK_ID)) {
    if (Number.isInteger(value)) BLOCK_KEY_TO_ID[key.toLowerCase()] = value;
}

export const RESOURCE_TO_BLOCK_ALIASES: Record<string, number> = {
    grass_block: BLOCK_ID.GRASS,
    dirt_path: BLOCK_ID.DIRT,
    rooted_dirt: BLOCK_ID.DIRT,
    coarse_dirt: BLOCK_ID.DIRT,
    podzol: BLOCK_ID.DIRT,
    mud: BLOCK_ID.DIRT,
    packed_mud: BLOCK_ID.DIRT,
    stone_bricks: BLOCK_ID.BRICKS,
    mossy_stone_bricks: BLOCK_ID.BRICKS,
    cracked_stone_bricks: BLOCK_ID.BRICKS,
    chiseled_stone_bricks: BLOCK_ID.BRICKS,
    mud_bricks: BLOCK_ID.BRICKS,
    clay: BLOCK_ID.CLAY,
    raw_iron_block: BLOCK_ID.IRON_ORE,
    raw_gold_block: BLOCK_ID.GOLD_ORE,
    raw_copper_block: BLOCK_ID.IRON_ORE,
    bamboo_block: BLOCK_ID.BAMBOO,
    bamboo_mosaic: BLOCK_ID.PLANKS,
    soul_sand: BLOCK_ID.SOUL_SAND,
    soul_soil: BLOCK_ID.SOUL_SAND,
    netherrack: BLOCK_ID.NETHERRACK,
    nether_bricks: BLOCK_ID.BRICKS,
    glowstone: BLOCK_ID.GLOWSTONE,
    magma_block: BLOCK_ID.LAVA,
    sea_lantern: BLOCK_ID.GLOWSTONE,
    obsidian: BLOCK_ID.OBSIDIAN,
    mossy_cobblestone: BLOCK_ID.MOSSY_COBBLESTONE,
    cobbled_deepslate: BLOCK_ID.COBBLESTONE
};

export function getBlockIdForResourceId(resourceId: string | number): number | null {
    const key = String(resourceId || '').trim().toLowerCase();
    if (!key) return null;
    if (key.endsWith('_bucket') || key.endsWith('_spawn_egg')) return null;
    if (/(sword|pickaxe|axe|shovel|hoe|helmet|chestplate|leggings|boots|ingot|nugget|dust|powder|potion|arrow|map|book|paper|rod|bow|crossbow|trident|shield|disc|music_disc|apple|bread|carrot|potato|beetroot|stew|cookie|pie|cake|berries|beef|porkchop|chicken|mutton|rabbit|fish|compass|clock|totem|elytra|name_tag|saddle|pearl|eye|star|shard|seeds|wart|bone|string|feather|gunpowder|slime_ball|honey_bottle)$/.test(key)) return null;

    if (Object.prototype.hasOwnProperty.call(BLOCK_KEY_TO_ID, key)) {
        return BLOCK_KEY_TO_ID[key];
    }
    if (Object.prototype.hasOwnProperty.call(RESOURCE_TO_BLOCK_ALIASES, key)) {
        return RESOURCE_TO_BLOCK_ALIASES[key];
    }

    if (key.endsWith('_log') || key.endsWith('_wood') || key.endsWith('_stem') || key.endsWith('_hyphae')) return BLOCK_ID.LOG;
    if (key.endsWith('_planks')) return BLOCK_ID.PLANKS;
    if (key.endsWith('_leaves')) return key.includes('cherry') ? BLOCK_ID.CHERRY_LEAVES : BLOCK_ID.LEAVES;
    if (key.endsWith('_sand')) return BLOCK_ID.SAND;
    if (key.includes('cobbl')) return BLOCK_ID.COBBLESTONE;
    if (key.includes('mossy_cobbl')) return BLOCK_ID.MOSSY_COBBLESTONE;
    if (key.includes('brick')) return BLOCK_ID.BRICKS;
    if (key.includes('bamboo')) return BLOCK_ID.BAMBOO;
    if (key.includes('cactus')) return BLOCK_ID.CACTUS;
    if (key === 'glass' || key.endsWith('_glass') || key.endsWith('glass_pane')) return BLOCK_ID.GLASS;
    if (key === 'water') return BLOCK_ID.WATER;
    if (key === 'lava') return BLOCK_ID.LAVA;
    if (key.includes('coal_ore')) return BLOCK_ID.COAL_ORE;
    if (key.includes('iron_ore')) return BLOCK_ID.IRON_ORE;
    if (key.includes('lapis_ore')) return BLOCK_ID.LAPIS_ORE;
    if (key.includes('redstone_ore')) return BLOCK_ID.REDSTONE_ORE;
    if (key.includes('gold_ore')) return BLOCK_ID.GOLD_ORE;
    if (key.includes('diamond_ore')) return BLOCK_ID.DIAMOND_ORE;
    if (key.includes('emerald_ore')) return BLOCK_ID.EMERALD_ORE;
    if (key.includes('ruby_ore')) return BLOCK_ID.RUBY_ORE;
    if (key.includes('quartz_ore')) return BLOCK_ID.NETHER_QUARTZ_ORE;

    return null;
}

export interface PlayerSkin {
    id: string;
    name: string;
    head: number;
    body: number;
    legs: number;
}

export const PLAYER_SKINS: PlayerSkin[] = [
    { id: 'steve', name: 'Steve', head: 0xd7a67b, body: 0x4c76c9, legs: 0x2f3f70 },
    { id: 'alex', name: 'Alex', head: 0xe2b18b, body: 0x6bb05b, legs: 0x4d6c7e },
    { id: 'knight', name: 'Knight', head: 0xd9c7af, body: 0x6e6e7e, legs: 0x3f404b },
    { id: 'ninja', name: 'Ninja', head: 0xcaa07c, body: 0x1e1f2d, legs: 0x111218 },
    { id: 'ruby', name: 'Ruby', head: 0xe1b38d, body: 0xa63b4a, legs: 0x4c2030 },
    { id: 'forest', name: 'Forest', head: 0xd0ad84, body: 0x3f7a46, legs: 0x345a3b },
    { id: 'custom', name: 'Custom', head: 0xd7a67b, body: 0x4c76c9, legs: 0x2f3f70 }
];

export const DEFAULT_CUSTOM_SKIN: PlayerSkin = {
    id: 'custom',
    name: 'Custom',
    head: 0xd7a67b,
    body: 0x4c76c9,
    legs: 0x2f3f70
};

export let CUSTOM_SKIN_STATE: PlayerSkin = { ...DEFAULT_CUSTOM_SKIN };

export function clampSkinColor(v: any, fallback: number): number {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(0, Math.min(0xFFFFFF, Math.floor(n)));
}

export function normalizeSkinPayload(raw: any): PlayerSkin {
    if (!raw || typeof raw !== 'object') return { ...CUSTOM_SKIN_STATE };
    const name = String(raw.name || CUSTOM_SKIN_STATE.name || 'Custom').slice(0, 18);
    return {
        id: 'custom',
        name: name.length > 0 ? name : 'Custom',
        head: clampSkinColor(raw.head, CUSTOM_SKIN_STATE.head),
        body: clampSkinColor(raw.body, CUSTOM_SKIN_STATE.body),
        legs: clampSkinColor(raw.legs, CUSTOM_SKIN_STATE.legs)
    };
}

export function setCustomSkinState(raw: any) {
    CUSTOM_SKIN_STATE = normalizeSkinPayload(raw);
}

export function getCustomSkinState(): PlayerSkin {
    return { ...CUSTOM_SKIN_STATE };
}

export function getSkinDefById(skinId: string): PlayerSkin {
    if (skinId === 'custom') return getCustomSkinState();
    const found = PLAYER_SKINS.find((s) => s.id === skinId);
    return found || PLAYER_SKINS[0];
}

export const RESOURCE_ITEM = {
    COAL: 'coal',
    RAW_IRON: 'raw_iron',
    LAPIS: 'lapis',
    REDSTONE: 'redstone',
    RAW_GOLD: 'raw_gold',
    DIAMOND: 'diamond',
    EMERALD: 'emerald',
    RUBY: 'ruby',
    STICK: 'stick',
    APPLE: 'apple',
    BREAD: 'bread',
    LEATHER_HELMET: 'leather_helmet',
    LEATHER_CHESTPLATE: 'leather_chestplate',
    LEATHER_LEGGINGS: 'leather_leggings',
    LEATHER_BOOTS: 'leather_boots',
    IRON_HELMET: 'iron_helmet',
    IRON_CHESTPLATE: 'iron_chestplate',
    IRON_LEGGINGS: 'iron_leggings',
    IRON_BOOTS: 'iron_boots',
    GOLD_HELMET: 'gold_helmet',
    GOLD_CHESTPLATE: 'gold_chestplate',
    GOLD_LEGGINGS: 'gold_leggings',
    GOLD_BOOTS: 'gold_boots',
    DIAMOND_HELMET: 'diamond_helmet',
    DIAMOND_CHESTPLATE: 'diamond_chestplate',
    DIAMOND_LEGGINGS: 'diamond_leggings',
    DIAMOND_BOOTS: 'diamond_boots',
    RUBY_HELMET: 'ruby_helmet',
    RUBY_CHESTPLATE: 'ruby_chestplate',
    RUBY_LEGGINGS: 'ruby_leggings',
    RUBY_BOOTS: 'ruby_boots',
    IRON_PICKAXE: 'iron_pickaxe',
    IRON_AXE: 'iron_axe',
    IRON_SHOVEL: 'iron_shovel',
    IRON_SWORD: 'iron_sword',
    GOLD_PICKAXE: 'gold_pickaxe',
    GOLD_AXE: 'gold_axe',
    GOLD_SHOVEL: 'gold_shovel',
    GOLD_SWORD: 'gold_sword',
    DIAMOND_PICKAXE: 'diamond_pickaxe',
    DIAMOND_AXE: 'diamond_axe',
    DIAMOND_SHOVEL: 'diamond_shovel',
    DIAMOND_SWORD: 'diamond_sword',
    RUBY_PICKAXE: 'ruby_pickaxe',
    RUBY_AXE: 'ruby_axe',
    RUBY_SHOVEL: 'ruby_shovel',
    RUBY_SWORD: 'ruby_sword',
    MACE: 'mace',
    DIAMOND_MACE: 'diamond_mace',
    SPEAR: 'spear',
    DIAMOND_SPEAR: 'diamond_spear',
    TRIDENT: 'trident',
    NETHERITE_SWORD: 'netherite_sword',
    HEAVY_CORE: 'heavy_core',
    BREEZE_ROD: 'breeze_rod',
    WIND_CHARGE: 'wind_charge',
    QUARTZ: 'quartz',
    WHEAT: 'wheat',
    FLINT: 'flint'
};

export interface ResourceDef {
    color: string;
    label: string;
    food?: number;
    armor?: number;
    tool?: boolean;
    toolType?: string;
    miningSpeed?: number;
    attackDamage?: number;
}

export const RESOURCE_DEFS: Record<string, ResourceDef> = {
    [RESOURCE_ITEM.COAL]:              { color: '#3c3c3c', label: 'Coal' },
    [RESOURCE_ITEM.RAW_IRON]:          { color: '#d6b496', label: 'Raw Iron' },
    [RESOURCE_ITEM.LAPIS]:             { color: '#3f63d9', label: 'Lapis' },
    [RESOURCE_ITEM.REDSTONE]:          { color: '#b33434', label: 'Redstone' },
    [RESOURCE_ITEM.RAW_GOLD]:          { color: '#cfa858', label: 'Raw Gold' },
    [RESOURCE_ITEM.DIAMOND]:           { color: '#48d8cc', label: 'Diamond' },
    [RESOURCE_ITEM.EMERALD]:           { color: '#36c26b', label: 'Emerald' },
    [RESOURCE_ITEM.RUBY]:              { color: '#c72c6c', label: 'Ruby' },
    [RESOURCE_ITEM.STICK]:             { color: '#927046', label: 'Stick' },
    [RESOURCE_ITEM.APPLE]:             { color: '#d64f45', label: 'Apple', food: 4 },
    [RESOURCE_ITEM.BREAD]:             { color: '#d3a566', label: 'Bread', food: 5 },
    'leather':                         { color: '#8a5229', label: 'Leather' },
    [RESOURCE_ITEM.LEATHER_HELMET]:     { color: '#8a5229', label: 'Leather Cap', armor: 1 },
    [RESOURCE_ITEM.LEATHER_CHESTPLATE]: { color: '#8a5229', label: 'Leather Tunic', armor: 3 },
    [RESOURCE_ITEM.LEATHER_LEGGINGS]:   { color: '#8a5229', label: 'Leather Pants', armor: 2 },
    [RESOURCE_ITEM.LEATHER_BOOTS]:      { color: '#8a5229', label: 'Leather Boots', armor: 1 },
    [RESOURCE_ITEM.IRON_HELMET]:       { color: '#aec0c7', label: 'Iron Helmet', armor: 2 },
    [RESOURCE_ITEM.IRON_CHESTPLATE]:   { color: '#aec0c7', label: 'Iron Chestplate', armor: 6 },
    [RESOURCE_ITEM.IRON_LEGGINGS]:     { color: '#aec0c7', label: 'Iron Leggings', armor: 5 },
    [RESOURCE_ITEM.IRON_BOOTS]:        { color: '#aec0c7', label: 'Iron Boots', armor: 2 },
    [RESOURCE_ITEM.GOLD_HELMET]:       { color: '#f0ca6a', label: 'Gold Helmet', armor: 2 },
    [RESOURCE_ITEM.GOLD_CHESTPLATE]:   { color: '#f0ca6a', label: 'Gold Chestplate', armor: 5 },
    [RESOURCE_ITEM.GOLD_LEGGINGS]:     { color: '#f0ca6a', label: 'Gold Leggings', armor: 3 },
    [RESOURCE_ITEM.GOLD_BOOTS]:        { color: '#f0ca6a', label: 'Gold Boots', armor: 1 },
    [RESOURCE_ITEM.DIAMOND_HELMET]:    { color: '#66f5e8', label: 'Diamond Helmet', armor: 3 },
    [RESOURCE_ITEM.DIAMOND_CHESTPLATE]:{ color: '#66f5e8', label: 'Diamond Chestplate', armor: 8 },
    [RESOURCE_ITEM.DIAMOND_LEGGINGS]:  { color: '#66f5e8', label: 'Diamond Leggings', armor: 6 },
    [RESOURCE_ITEM.DIAMOND_BOOTS]:     { color: '#66f5e8', label: 'Diamond Boots', armor: 3 },
    [RESOURCE_ITEM.RUBY_HELMET]:       { color: '#ea5c9f', label: 'Ruby Helmet', armor: 4 },
    [RESOURCE_ITEM.RUBY_CHESTPLATE]:   { color: '#ea5c9f', label: 'Ruby Chestplate', armor: 10 },
    [RESOURCE_ITEM.RUBY_LEGGINGS]:     { color: '#ea5c9f', label: 'Ruby Leggings', armor: 8 },
    [RESOURCE_ITEM.RUBY_BOOTS]:        { color: '#ea5c9f', label: 'Ruby Boots', armor: 4 },
    [RESOURCE_ITEM.IRON_PICKAXE]:      { color: '#aec0c7', label: 'Iron Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 1.8, attackDamage: 5 },
    [RESOURCE_ITEM.IRON_AXE]:          { color: '#aec0c7', label: 'Iron Axe', tool: true, toolType: 'axe', miningSpeed: 1.45, attackDamage: 6 },
    [RESOURCE_ITEM.IRON_SHOVEL]:       { color: '#aec0c7', label: 'Iron Shovel', tool: true, toolType: 'shovel', miningSpeed: 1.9, attackDamage: 4 },
    [RESOURCE_ITEM.IRON_SWORD]:        { color: '#aec0c7', label: 'Iron Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 7 },
    [RESOURCE_ITEM.GOLD_PICKAXE]:      { color: '#f0ca6a', label: 'Gold Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 2.0, attackDamage: 4 },
    [RESOURCE_ITEM.GOLD_AXE]:          { color: '#f0ca6a', label: 'Gold Axe', tool: true, toolType: 'axe', miningSpeed: 1.6, attackDamage: 5 },
    [RESOURCE_ITEM.GOLD_SHOVEL]:       { color: '#f0ca6a', label: 'Gold Shovel', tool: true, toolType: 'shovel', miningSpeed: 2.1, attackDamage: 4 },
    [RESOURCE_ITEM.GOLD_SWORD]:        { color: '#f0ca6a', label: 'Gold Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 6 },
    [RESOURCE_ITEM.DIAMOND_PICKAXE]:   { color: '#66f5e8', label: 'Diamond Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 2.45, attackDamage: 7 },
    [RESOURCE_ITEM.DIAMOND_AXE]:       { color: '#66f5e8', label: 'Diamond Axe', tool: true, toolType: 'axe', miningSpeed: 2.1, attackDamage: 8 },
    [RESOURCE_ITEM.DIAMOND_SHOVEL]:    { color: '#66f5e8', label: 'Diamond Shovel', tool: true, toolType: 'shovel', miningSpeed: 2.5, attackDamage: 6 },
    [RESOURCE_ITEM.DIAMOND_SWORD]:     { color: '#66f5e8', label: 'Diamond Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 9 },
    [RESOURCE_ITEM.RUBY_PICKAXE]:      { color: '#ea5c9f', label: 'Ruby Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 3.0, attackDamage: 9 },
    [RESOURCE_ITEM.RUBY_AXE]:          { color: '#ea5c9f', label: 'Ruby Axe', tool: true, toolType: 'axe', miningSpeed: 2.6, attackDamage: 10 },
    [RESOURCE_ITEM.RUBY_SHOVEL]:       { color: '#ea5c9f', label: 'Ruby Shovel', tool: true, toolType: 'shovel', miningSpeed: 3.1, attackDamage: 8 },
    [RESOURCE_ITEM.RUBY_SWORD]:        { color: '#ea5c9f', label: 'Ruby Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 11 },
    wheat: { color: '#e1c36a', label: 'Wheat' },
    potato: { color: '#b88f54', label: 'Potato', food: 1 },
    carrot: { color: '#d57d2f', label: 'Carrot', food: 3 },
    raw_beef: { color: '#ba3d3d', label: 'Raw Beef', food: 3 },
    raw_porkchop: { color: '#f28e8e', label: 'Raw Porkchop', food: 3 },
    raw_mutton: { color: '#c95f5f', label: 'Raw Mutton', food: 2 },
    raw_chicken: { color: '#e8bc9e', label: 'Raw Chicken', food: 2 },
    feather: { color: '#f5f5f5', label: 'Feather' },
    iron_ingot: { color: '#d0d4d8', label: 'Iron Ingot' },
    gold_ingot: { color: '#f0ca6a', label: 'Gold Ingot' },
    wooden_pickaxe: { color: '#9a6f45', label: 'Wooden Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 1.6, attackDamage: 3 },
    wooden_axe: { color: '#9a6f45', label: 'Wooden Axe', tool: true, toolType: 'axe', miningSpeed: 1.3, attackDamage: 4 },
    wooden_shovel: { color: '#9a6f45', label: 'Wooden Shovel', tool: true, toolType: 'shovel', miningSpeed: 1.65, attackDamage: 2 },
    wooden_sword: { color: '#9a6f45', label: 'Wooden Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 4 },
    stone_pickaxe: { color: '#8a8a8a', label: 'Stone Pickaxe', tool: true, toolType: 'pickaxe', miningSpeed: 2.6, attackDamage: 4 },
    stone_axe: { color: '#8a8a8a', label: 'Stone Axe', tool: true, toolType: 'axe', miningSpeed: 2.2, attackDamage: 5 },
    stone_shovel: { color: '#8a8a8a', label: 'Stone Shovel', tool: true, toolType: 'shovel', miningSpeed: 2.7, attackDamage: 3 },
    stone_sword: { color: '#8a8a8a', label: 'Stone Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 5 },
    [RESOURCE_ITEM.MACE]: { color: '#7a7d85', label: 'Heavy Mace', tool: true, toolType: 'mace', miningSpeed: 1.0, attackDamage: 12 },
    [RESOURCE_ITEM.DIAMOND_MACE]: { color: '#44d4c8', label: 'Diamond Mace', tool: true, toolType: 'mace', miningSpeed: 1.0, attackDamage: 15 },
    [RESOURCE_ITEM.SPEAR]: { color: '#b5c0c7', label: 'Iron Spear', tool: true, toolType: 'spear', miningSpeed: 1.0, attackDamage: 8 },
    [RESOURCE_ITEM.DIAMOND_SPEAR]: { color: '#56e2d6', label: 'Diamond Spear', tool: true, toolType: 'spear', miningSpeed: 1.0, attackDamage: 11 },
    [RESOURCE_ITEM.TRIDENT]: { color: '#38b2a6', label: 'Trident', tool: true, toolType: 'spear', miningSpeed: 1.0, attackDamage: 12 },
    [RESOURCE_ITEM.NETHERITE_SWORD]: { color: '#312d33', label: 'Netherite Sword', tool: true, toolType: 'sword', miningSpeed: 1.0, attackDamage: 14 },
    [RESOURCE_ITEM.HEAVY_CORE]: { color: '#52545d', label: 'Heavy Core' },
    [RESOURCE_ITEM.BREEZE_ROD]: { color: '#bdc6e8', label: 'Breeze Rod' },
    [RESOURCE_ITEM.WIND_CHARGE]: { color: '#b6f3f8', label: 'Wind Charge' },
    [RESOURCE_ITEM.QUARTZ]: { color: '#eae4dc', label: 'Nether Quartz' },
    [RESOURCE_ITEM.FLINT]: { color: '#3f3f3f', label: 'Flint' }
};

export const BLOCK_DROP_MAP: Record<number, { kind: 'block' | 'resource'; id: any; count: number }> = {
    [BLOCK_ID.COAL_ORE]: { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 },
    [BLOCK_ID.IRON_ORE]: { kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 1 },
    [BLOCK_ID.LAPIS_ORE]: { kind: 'resource', id: RESOURCE_ITEM.LAPIS, count: 2 },
    [BLOCK_ID.REDSTONE_ORE]: { kind: 'resource', id: RESOURCE_ITEM.REDSTONE, count: 2 },
    [BLOCK_ID.GOLD_ORE]: { kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 1 },
    [BLOCK_ID.DIAMOND_ORE]: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 1 },
    [BLOCK_ID.EMERALD_ORE]: { kind: 'resource', id: RESOURCE_ITEM.EMERALD, count: 1 },
    [BLOCK_ID.RUBY_ORE]: { kind: 'resource', id: RESOURCE_ITEM.RUBY, count: 1 }
};

export interface CraftingRecipe {
    id: string;
    label: string;
    output: { kind: 'block' | 'resource'; id: any; count: number };
    in: Array<{ kind: 'block' | 'resource'; id: any; count: number }>;
}

export const CRAFTING_RECIPES: CraftingRecipe[] = [
    { id: 'planks', label: '4x Planks', output: { kind: 'block', id: BLOCK_ID.PLANKS, count: 4 }, in: [{ kind: 'block', id: BLOCK_ID.LOG, count: 1 }] },
    { id: 'sticks', label: '4x Sticks', output: { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 4 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 2 }] },
    { id: 'glass', label: '2x Glass', output: { kind: 'block', id: BLOCK_ID.GLASS, count: 2 }, in: [{ kind: 'block', id: BLOCK_ID.SAND, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 }] },
    { id: 'crafting_table_recipe', label: 'Crafting Table', output: { kind: 'block', id: BLOCK_ID.CRAFTING_TABLE, count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 4 }] },
    { id: 'furnace_recipe', label: 'Furnace', output: { kind: 'block', id: BLOCK_ID.FURNACE, count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.COBBLESTONE, count: 8 }] },
    { id: 'tnt_recipe', label: 'TNT Explosive', output: { kind: 'block', id: BLOCK_ID.TNT, count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.SAND, count: 4 }, { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 }] },
    { id: 'bookshelf_recipe', label: 'Bookshelf', output: { kind: 'block', id: BLOCK_ID.BOOKSHELF, count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 6 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 3 }] },
    { id: 'stone_bricks_recipe', label: '4x Stone Bricks', output: { kind: 'block', id: BLOCK_ID.STONE_BRICKS, count: 4 }, in: [{ kind: 'block', id: BLOCK_ID.STONE, count: 4 }] },
    { id: 'hay_bale_recipe', label: 'Hay Bale', output: { kind: 'block', id: BLOCK_ID.HAY_BALE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.WHEAT, count: 3 }] },
    { id: 'jack_o_lantern_recipe', label: "Jack o' Lantern", output: { kind: 'block', id: BLOCK_ID.JACK_O_LANTERN, count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PUMPKIN, count: 1 }, { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 }] },
    { id: 'bricks_block', label: '2x Bricks', output: { kind: 'block', id: BLOCK_ID.BRICKS, count: 2 }, in: [{ kind: 'block', id: BLOCK_ID.CLAY, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.COAL, count: 1 }] },
    { id: 'mossy_cobble', label: '2x Mossy Cobble', output: { kind: 'block', id: BLOCK_ID.MOSSY_COBBLESTONE, count: 2 }, in: [{ kind: 'block', id: BLOCK_ID.COBBLESTONE, count: 2 }, { kind: 'block', id: BLOCK_ID.LEAVES, count: 1 }] },
    { id: 'iron_helmet', label: 'Iron Helmet', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_HELMET, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 5 }] },
    { id: 'iron_chest', label: 'Iron Chestplate', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_CHESTPLATE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 8 }] },
    { id: 'iron_legs', label: 'Iron Leggings', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_LEGGINGS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 7 }] },
    { id: 'iron_boots', label: 'Iron Boots', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_BOOTS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 4 }] },
    { id: 'diamond_helmet', label: 'Diamond Helmet', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_HELMET, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 5 }] },
    { id: 'diamond_chest', label: 'Diamond Chestplate', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_CHESTPLATE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 8 }] },
    { id: 'diamond_legs', label: 'Diamond Leggings', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_LEGGINGS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 7 }] },
    { id: 'diamond_boots', label: 'Diamond Boots', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_BOOTS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 4 }] },
    { id: 'gold_helmet', label: 'Gold Helmet', output: { kind: 'resource', id: RESOURCE_ITEM.GOLD_HELMET, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 5 }] },
    { id: 'gold_chest', label: 'Gold Chestplate', output: { kind: 'resource', id: RESOURCE_ITEM.GOLD_CHESTPLATE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 8 }] },
    { id: 'gold_legs', label: 'Gold Leggings', output: { kind: 'resource', id: RESOURCE_ITEM.GOLD_LEGGINGS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 7 }] },
    { id: 'gold_boots', label: 'Gold Boots', output: { kind: 'resource', id: RESOURCE_ITEM.GOLD_BOOTS, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_GOLD, count: 4 }] },
    { id: 'leather_helmet', label: 'Leather Cap', output: { kind: 'resource', id: RESOURCE_ITEM.LEATHER_HELMET, count: 1 }, in: [{ kind: 'resource', id: 'leather', count: 5 }] },
    { id: 'leather_chest', label: 'Leather Tunic', output: { kind: 'resource', id: RESOURCE_ITEM.LEATHER_CHESTPLATE, count: 1 }, in: [{ kind: 'resource', id: 'leather', count: 8 }] },
    { id: 'leather_legs', label: 'Leather Pants', output: { kind: 'resource', id: RESOURCE_ITEM.LEATHER_LEGGINGS, count: 1 }, in: [{ kind: 'resource', id: 'leather', count: 7 }] },
    { id: 'leather_boots', label: 'Leather Boots', output: { kind: 'resource', id: RESOURCE_ITEM.LEATHER_BOOTS, count: 1 }, in: [{ kind: 'resource', id: 'leather', count: 4 }] },
    { id: 'iron_pickaxe', label: 'Iron Pickaxe', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_PICKAXE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'iron_axe', label: 'Iron Axe', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_AXE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'iron_shovel', label: 'Iron Shovel', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_SHOVEL, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 1 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'iron_sword', label: 'Iron Sword', output: { kind: 'resource', id: RESOURCE_ITEM.IRON_SWORD, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 1 }] },
    { id: 'diamond_pickaxe', label: 'Diamond Pickaxe', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_PICKAXE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'diamond_sword', label: 'Diamond Sword', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_SWORD, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 1 }] },
    { id: 'wooden_pickaxe_recipe', label: 'Wooden Pickaxe', output: { kind: 'resource', id: 'wooden_pickaxe', count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'wooden_axe_recipe', label: 'Wooden Axe', output: { kind: 'resource', id: 'wooden_axe', count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'wooden_sword_recipe', label: 'Wooden Sword', output: { kind: 'resource', id: 'wooden_sword', count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.PLANKS, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 1 }] },
    { id: 'stone_pickaxe_recipe', label: 'Stone Pickaxe', output: { kind: 'resource', id: 'stone_pickaxe', count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.COBBLESTONE, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'stone_sword_recipe', label: 'Stone Sword', output: { kind: 'resource', id: 'stone_sword', count: 1 }, in: [{ kind: 'block', id: BLOCK_ID.COBBLESTONE, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 1 }] },
    { id: 'iron_spear_recipe', label: 'Iron Spear', output: { kind: 'resource', id: RESOURCE_ITEM.SPEAR, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'diamond_spear_recipe', label: 'Diamond Spear', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_SPEAR, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 2 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'mace_recipe', label: 'Heavy Mace', output: { kind: 'resource', id: RESOURCE_ITEM.MACE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.RAW_IRON, count: 4 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'heavy_mace_authentic', label: 'Heavy Mace (Breeze)', output: { kind: 'resource', id: RESOURCE_ITEM.MACE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.HEAVY_CORE, count: 1 }, { kind: 'resource', id: RESOURCE_ITEM.BREEZE_ROD, count: 1 }] },
    { id: 'diamond_mace_recipe', label: 'Diamond Mace', output: { kind: 'resource', id: RESOURCE_ITEM.DIAMOND_MACE, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 4 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] },
    { id: 'wind_charge_recipe', label: '4x Wind Charge', output: { kind: 'resource', id: RESOURCE_ITEM.WIND_CHARGE, count: 4 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.BREEZE_ROD, count: 1 }] },
    { id: 'trident_recipe', label: 'Trident', output: { kind: 'resource', id: RESOURCE_ITEM.TRIDENT, count: 1 }, in: [{ kind: 'resource', id: RESOURCE_ITEM.DIAMOND, count: 3 }, { kind: 'resource', id: RESOURCE_ITEM.STICK, count: 2 }] }
];

export const EXTRA_CRAFTING_RECIPES: CraftingRecipe[] = [];

// ==============================================================
// TOOL DURABILITY DEFINITIONS (Pickaxes, Axes, Shovels)
// ==============================================================
export const TOOL_MAX_DURABILITY: Record<string, number> = {
    // Pickaxes
    wooden_pickaxe: 59,
    stone_pickaxe: 131,
    iron_pickaxe: 250,
    gold_pickaxe: 32,
    diamond_pickaxe: 1561,
    ruby_pickaxe: 2031,

    // Axes
    wooden_axe: 59,
    stone_axe: 131,
    iron_axe: 250,
    gold_axe: 32,
    diamond_axe: 1561,
    ruby_axe: 2031,

    // Shovels
    wooden_shovel: 59,
    stone_shovel: 131,
    iron_shovel: 250,
    gold_shovel: 32,
    diamond_shovel: 1561,
    ruby_shovel: 2031
};

export function isDurabilityTool(id: string): boolean {
    if (!id || typeof id !== 'string') return false;
    const lower = id.toLowerCase();
    if (lower.includes('pickaxe') || lower.includes('axe') || lower.includes('shovel')) {
        return true;
    }
    const def = (RESOURCE_DEFS as any)[id];
    if (def && (def.toolType === 'pickaxe' || def.toolType === 'axe' || def.toolType === 'shovel')) {
        return true;
    }
    return false;
}

export function getToolMaxDurability(id: string): number {
    if (TOOL_MAX_DURABILITY[id]) return TOOL_MAX_DURABILITY[id];
    const lower = id.toLowerCase();
    if (lower.includes('gold')) return 32;
    if (lower.includes('wood')) return 59;
    if (lower.includes('stone')) return 131;
    if (lower.includes('iron')) return 250;
    if (lower.includes('diamond')) return 1561;
    if (lower.includes('ruby')) return 2031;
    return 100;
}

// Attach to window for backwards compatibility with any non-module plugins
if (typeof window !== 'undefined') {
    (window as any).CONFIG = CONFIG;
    (window as any).BLOCK_ID = BLOCK_ID;
    (window as any).BLOCK_DEFS = BLOCK_DEFS;
    (window as any).RESOURCE_DEFS = RESOURCE_DEFS;
    (window as any).CRAFTING_RECIPES = CRAFTING_RECIPES;
    (window as any).EXTRA_CRAFTING_RECIPES = EXTRA_CRAFTING_RECIPES;
    (window as any).PLAYER_SKINS = PLAYER_SKINS;
}
