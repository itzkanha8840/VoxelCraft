import * as THREE from 'three';
import { CONFIG, BLOCK_ID, BLOCK_DEFS } from './constants';
import { MathKernel, VoxelWorld } from './world';
import { SurvivalSystem } from './systems';
import { findMobPath, hasLineOfSight } from './pathfinding';
import { ArrowManager } from './arrowProjectile';

// Helper to normalize angle in [-PI, PI]
function wrapAngle(angle: number): number {
    while (angle < -Math.PI) angle += Math.PI * 2;
    while (angle > Math.PI) angle -= Math.PI * 2;
    return angle;
}

interface MobPhysicsResult {
    onGround: boolean;
    inWater: boolean;
    blocked: boolean;
    jumped: boolean;
    isClimbing?: boolean;
}

// Authentic Minecraft mob physics engine: voxel step jumping, buoyancy, gravity, terminal velocity & drag
function isVoxelSolid(world: VoxelWorld, x: number, y: number, z: number): boolean {
    if (y < 0 || y >= 256) return false;
    const bId = world.getVoxel(x, y, z);
    if (bId === BLOCK_ID.AIR || bId === BLOCK_ID.WATER || bId === BLOCK_ID.LAVA) return false;
    if (bId === BLOCK_ID.TALL_GRASS || bId === BLOCK_ID.FLOWER_RED || bId === BLOCK_ID.FLOWER_YELLOW) return false;
    const def = BLOCK_DEFS[bId];
    return !!(def && def.solid);
}

function updateMobMinecraftPhysics(
    world: VoxelWorld,
    pos: THREE.Vector3,
    vel: THREE.Vector3,
    desiredVx: number,
    desiredVz: number,
    dt: number,
    mobType: string,
    bodyYaw: number,
    canClimb = false
): MobPhysicsResult {
    // 1. Dimensions matching authentic Minecraft hitboxes
    let halfW = 0.3;
    let height = 1.8;
    if (mobType === 'chicken') {
        halfW = 0.2;
        height = 0.7;
    } else if (mobType === 'cow' || mobType === 'pig' || mobType === 'sheep') {
        halfW = 0.42;
        height = 1.35;
    } else if (mobType === 'spider') {
        halfW = 0.45;
        height = 0.85;
    } else if (mobType === 'enderman') {
        halfW = 0.3;
        height = 2.85;
    } else if (mobType === 'iron_golem') {
        halfW = 0.55;
        height = 2.65;
    }

    const footBlockY = Math.floor(pos.y + 0.05);
    const voxelAtFeet = world.getVoxel(Math.floor(pos.x), footBlockY, Math.floor(pos.z));
    const inWater = (voxelAtFeet === BLOCK_ID.WATER);

    // 2. Smooth horizontal acceleration & ground friction (authentic Minecraft feel)
    const accelRate = inWater ? 6.0 : 12.0;
    vel.x = THREE.MathUtils.lerp(vel.x, desiredVx, Math.min(1.0, dt * accelRate));
    vel.z = THREE.MathUtils.lerp(vel.z, desiredVz, Math.min(1.0, dt * accelRate));

    if (desiredVx === 0 && desiredVz === 0) {
        const friction = inWater ? 0.80 : 0.55;
        vel.x *= Math.pow(friction, dt * 20);
        vel.z *= Math.pow(friction, dt * 20);
    }

    // Spider wall climbing check: scales vertical obstacles and walls
    let isClimbing = false;
    if (canClimb) {
        const cy = Math.floor(pos.y + 0.2);
        const checkOffsets = [
            [halfW + 0.15, 0],
            [-halfW - 0.15, 0],
            [0, halfW + 0.15],
            [0, -halfW - 0.15]
        ];
        for (const [ox, oz] of checkOffsets) {
            const bx = Math.floor(pos.x + ox);
            const bz = Math.floor(pos.z + oz);
            if (isVoxelSolid(world, bx, cy, bz) || isVoxelSolid(world, bx, cy + 1, bz)) {
                isClimbing = true;
                break;
            }
        }
    }

    // 3. Gravity, Buoyancy & Wall Climbing
    if (inWater) {
        vel.y = Math.min(2.2, vel.y + 16.0 * dt);
        vel.x *= Math.pow(0.85, dt * 20);
        vel.z *= Math.pow(0.85, dt * 20);
    } else if (isClimbing) {
        // Spider wall climb scales smoothly upwards against the wall, defying downward gravity
        vel.y = 3.4;
    } else if (mobType === 'chicken' && vel.y < 0) {
        // Chicken slow falling glide
        vel.y = Math.max(-2.0, vel.y - 6.5 * dt);
    } else {
        // Standard Minecraft entity gravity
        vel.y = Math.max(-28.0, vel.y - 24.0 * dt);
    }

    // 4. Horizontal collision with authentic 1-block step jump
    let blocked = false;
    let jumped = false;

    // Movement step for X
    const dx = vel.x * dt;
    if (Math.abs(dx) > 0.001) {
        const nextX = pos.x + dx;
        const testX = nextX + (dx > 0 ? halfW : -halfW);
        const bx = Math.floor(testX);
        const curY = Math.floor(pos.y + 0.1);
        const curZ = Math.floor(pos.z);

        const footSolid = isVoxelSolid(world, bx, curY, curZ);
        const headSolid = isVoxelSolid(world, bx, curY + 1, curZ);

        if (footSolid) {
            if (canClimb) {
                vel.y = 3.8;
            } else if (!headSolid) {
                // 1-block obstacle: authentic Minecraft mob jump!
                vel.y = 5.4;
                jumped = true;
            } else {
                vel.x = 0;
                blocked = true;
            }
        } else {
            pos.x = nextX;
        }
    }

    // Movement step for Z
    const dz = vel.z * dt;
    if (Math.abs(dz) > 0.001) {
        const nextZ = pos.z + dz;
        const testZ = nextZ + (dz > 0 ? halfW : -halfW);
        const bz = Math.floor(testZ);
        const curY = Math.floor(pos.y + 0.1);
        const curX = Math.floor(pos.x);

        const footSolid = isVoxelSolid(world, curX, curY, bz);
        const headSolid = isVoxelSolid(world, curX, curY + 1, bz);

        if (footSolid) {
            if (canClimb) {
                vel.y = 3.8;
            } else if (!headSolid) {
                // 1-block obstacle: authentic Minecraft mob jump!
                vel.y = 5.4;
                jumped = true;
            } else {
                vel.z = 0;
                blocked = true;
            }
        } else {
            pos.z = nextZ;
        }
    }

    // 5. Vertical Integration & Ground Landing (NO TELEPORT SNAPPING!)
    const dy = vel.y * dt;
    const nextY = pos.y + dy;
    let onGround = false;

    if (vel.y <= 0) {
        // Checking for solid ground directly beneath feet
        // Sample points under mob base
        const sampleOffsets = [
            [-halfW * 0.6, -halfW * 0.6],
            [halfW * 0.6, -halfW * 0.6],
            [-halfW * 0.6, halfW * 0.6],
            [halfW * 0.6, halfW * 0.6],
            [0, 0]
        ];

        let highestGroundY = -999;
        for (const [ox, oz] of sampleOffsets) {
            const bx = Math.floor(pos.x + ox);
            const bz = Math.floor(pos.z + oz);
            // Search down from current feet level to feet - 1.2
            for (let checkY = Math.floor(pos.y + 0.3); checkY >= Math.floor(pos.y - 1.3); checkY--) {
                if (isVoxelSolid(world, bx, checkY, bz)) {
                    const topOfBlock = checkY + 1.0;
                    if (topOfBlock > highestGroundY) {
                        highestGroundY = topOfBlock;
                    }
                    break;
                }
            }
        }

        if (highestGroundY > -900 && nextY <= highestGroundY) {
            pos.y = highestGroundY;
            vel.y = 0;
            onGround = true;
        } else {
            pos.y = nextY;
            onGround = false;
        }
    } else {
        // Moving up: check ceiling collision
        const ceilY = Math.floor(pos.y + height + 0.1);
        if (isVoxelSolid(world, Math.floor(pos.x), ceilY, Math.floor(pos.z))) {
            vel.y = 0;
            pos.y = Math.min(nextY, ceilY - height);
        } else {
            pos.y = nextY;
        }
        onGround = false;
    }

    return { onGround, inWater, blocked, jumped, isClimbing };
}

// Procedural pixel-art texture generator helper
function createPixelTexture(width: number, height: number, painter: (ctx: CanvasRenderingContext2D) => void): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    painter(ctx);
    const tex = new THREE.CanvasTexture(canvas);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    return tex;
}

export class FriendlyMobManager {
    scene: THREE.Scene;
    world: VoxelWorld;
    entities = new Map<string, any>();
    materials: Record<string, THREE.Material>;
    spawnTimer = 0;
    maxFriendly = 16;
    nextId = 1;

    constructor(scene: THREE.Scene, world: VoxelWorld) {
        this.scene = scene;
        this.world = world;

        // Authentic mob textures
        const cowFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#634735';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#d4b7a0';
            ctx.fillRect(4, 2, 8, 5); // white forehead patch
            ctx.fillStyle = '#141414';
            ctx.fillRect(2, 6, 2, 3); // left eye
            ctx.fillRect(12, 6, 2, 3); // right eye
            ctx.fillStyle = '#c79c88';
            ctx.fillRect(3, 9, 10, 6); // muzzle/snout
            ctx.fillStyle = '#22110c';
            ctx.fillRect(5, 11, 2, 2); // left nostril
            ctx.fillRect(9, 11, 2, 2); // right nostril
        });

        const pigFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#f0a3a3';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(2, 5, 3, 3); // left eye white
            ctx.fillRect(11, 5, 3, 3); // right eye white
            ctx.fillStyle = '#111111';
            ctx.fillRect(3, 6, 2, 2); // left eye pupil
            ctx.fillRect(11, 6, 2, 2); // right eye pupil
            ctx.fillStyle = '#e47d85';
            ctx.fillRect(4, 8, 8, 5); // snout
            ctx.fillStyle = '#6a2a30';
            ctx.fillRect(5, 10, 2, 2); // left nostril
            ctx.fillRect(9, 10, 2, 2); // right nostril
        });

        const sheepFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#d7c4b7';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#eaeaea';
            ctx.fillRect(0, 0, 16, 4); // wool bangs
            ctx.fillStyle = '#111111';
            ctx.fillRect(2, 6, 2, 2); // left eye
            ctx.fillRect(12, 6, 2, 2); // right eye
            ctx.fillStyle = '#8f6854';
            ctx.fillRect(6, 11, 4, 3); // nose/mouth
        });

        const chickenFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#111111';
            ctx.fillRect(3, 5, 2, 3); // left eye
            ctx.fillRect(11, 5, 2, 3); // right eye
            ctx.fillStyle = '#e69a28';
            ctx.fillRect(5, 8, 6, 4); // yellow beak
            ctx.fillStyle = '#c72c2c';
            ctx.fillRect(6, 12, 4, 4); // red wattle
        });

        // Authentic Villager Face Texture (emerald eyes, unibrow, tan skin)
        const villagerFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#bd8b72'; // Tan face skin
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#4a2f1b'; // Unibrow
            ctx.fillRect(2, 5, 12, 2);
            // Emerald eyes (white sclera, emerald pupil)
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(2, 7, 3, 2);
            ctx.fillRect(11, 7, 3, 2);
            ctx.fillStyle = '#179853'; // Emerald green
            ctx.fillRect(3, 7, 2, 2);
            ctx.fillRect(11, 7, 2, 2);
            ctx.fillStyle = '#9e674b'; // Shadow around mouth
            ctx.fillRect(5, 12, 6, 2);
        });

        // Iron Golem Face Texture
        const ironGolemFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#d4d0cb';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#4d8a39'; // Vine moss patches
            ctx.fillRect(1, 1, 3, 4);
            ctx.fillRect(12, 10, 3, 4);
            ctx.fillStyle = '#8f2020'; // Red eyes
            ctx.fillRect(3, 6, 2, 2);
            ctx.fillRect(11, 6, 2, 2);
            ctx.fillStyle = '#222222';
            ctx.fillRect(4, 7, 1, 1);
            ctx.fillRect(11, 7, 1, 1);
            ctx.fillStyle = '#9a948c'; // Mouth
            ctx.fillRect(5, 11, 6, 2);
        });

        this.materials = {
            cowBody: new THREE.MeshLambertMaterial({ color: 0x5a3f2d }),
            cowFace: new THREE.MeshLambertMaterial({ map: cowFaceTex }),
            cowHorn: new THREE.MeshLambertMaterial({ color: 0xd8d8cc }),
            cowLeg: new THREE.MeshLambertMaterial({ color: 0x422d1f }),
            pigBody: new THREE.MeshLambertMaterial({ color: 0xefa1a1 }),
            pigFace: new THREE.MeshLambertMaterial({ map: pigFaceTex }),
            pigSnout: new THREE.MeshLambertMaterial({ color: 0xe57c85 }),
            pigLeg: new THREE.MeshLambertMaterial({ color: 0xdb8e8e }),
            sheepWool: new THREE.MeshLambertMaterial({ color: 0xefefef }),
            sheepFace: new THREE.MeshLambertMaterial({ map: sheepFaceTex }),
            sheepLeg: new THREE.MeshLambertMaterial({ color: 0xb59e8f }),
            chickenBody: new THREE.MeshLambertMaterial({ color: 0xffffff }),
            chickenFace: new THREE.MeshLambertMaterial({ map: chickenFaceTex }),
            chickenBeak: new THREE.MeshLambertMaterial({ color: 0xe69a28 }),
            chickenWattle: new THREE.MeshLambertMaterial({ color: 0xc72c2c }),
            chickenLeg: new THREE.MeshLambertMaterial({ color: 0xd98c25 }),
            villagerSkin: new THREE.MeshLambertMaterial({ color: 0xbd8b72 }),
            villagerFace: new THREE.MeshLambertMaterial({ map: villagerFaceTex }),
            villagerRobe: new THREE.MeshLambertMaterial({ color: 0x85522e }),
            villagerNose: new THREE.MeshLambertMaterial({ color: 0xaa735b }),
            villagerArms: new THREE.MeshLambertMaterial({ color: 0x734320 }),
            ironGolemBody: new THREE.MeshLambertMaterial({ color: 0xd4d0cb }),
            ironGolemFace: new THREE.MeshLambertMaterial({ map: ironGolemFaceTex }),
            ironGolemNose: new THREE.MeshLambertMaterial({ color: 0xb8b2aa }),
            ironGolemVines: new THREE.MeshLambertMaterial({ color: 0x4d8a39 }),
            hitFlash: new THREE.MeshBasicMaterial({ color: 0xff4444 })
        };
    }

    _box(mat: THREE.Material | THREE.Material[], w: number, h: number, d: number) {
        const geo = new THREE.BoxGeometry(w / 16, h / 16, d / 16);
        return new THREE.Mesh(geo, mat);
    }

    _limb(mat: THREE.Material, w: number, h: number, d: number, pivotOffsetY = h / 2) {
        const pivot = new THREE.Group();
        const mesh = this._box(mat, w, h, d);
        mesh.position.y = -pivotOffsetY / 16;
        pivot.add(mesh);
        return pivot;
    }

    createFriendly(type: 'cow' | 'pig' | 'sheep' | 'chicken' | 'villager' | 'iron_golem', x: number, y: number, z: number) {
        const group = new THREE.Group();
        const S = 1 / 16;
        let legL1: THREE.Group, legR1: THREE.Group, legL2: THREE.Group, legR2: THREE.Group;
        let headMesh: THREE.Mesh;
        let speed = 1.2;
        let health = 10;

        if (type === 'cow') {
            // Authentic Cow Body: 10 wide, 10 high, 16 deep (proper horizontal Minecraft quadruped)
            const body = this._box(this.materials.cowBody, 10, 10, 16);
            body.position.set(0, 15 * S, 0);
            group.add(body);

            // Head: 8x8x8 at front
            const headMaterials = [
                this.materials.cowBody,
                this.materials.cowBody,
                this.materials.cowBody,
                this.materials.cowBody,
                this.materials.cowFace,
                this.materials.cowBody
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 18 * S, 8 * S);
            // Horns
            const hornL = this._box(this.materials.cowHorn, 2, 3, 1);
            hornL.position.set(-5 * S, 4 * S, -1 * S);
            const hornR = this._box(this.materials.cowHorn, 2, 3, 1);
            hornR.position.set(5 * S, 4 * S, -1 * S);
            headMesh.add(hornL, hornR);
            group.add(headMesh);

            // 4 Legs: 4x12x4 pivoted at y = 12 * S
            legL1 = this._limb(this.materials.cowLeg, 4, 12, 4, 6);
            legL1.position.set(-4 * S, 12 * S, 6 * S);
            legR1 = this._limb(this.materials.cowLeg, 4, 12, 4, 6);
            legR1.position.set(4 * S, 12 * S, 6 * S);
            legL2 = this._limb(this.materials.cowLeg, 4, 12, 4, 6);
            legL2.position.set(-4 * S, 12 * S, -6 * S);
            legR2 = this._limb(this.materials.cowLeg, 4, 12, 4, 6);
            legR2.position.set(4 * S, 12 * S, -6 * S);
            group.add(legL1, legR1, legL2, legR2);
        } else if (type === 'pig') {
            // Authentic Pig Body: 10 wide, 8 high, 14 deep
            const body = this._box(this.materials.pigBody, 10, 8, 14);
            body.position.set(0, 10 * S, 0);
            group.add(body);

            const headMaterials = [
                this.materials.pigBody,
                this.materials.pigBody,
                this.materials.pigBody,
                this.materials.pigBody,
                this.materials.pigFace,
                this.materials.pigBody
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 12 * S, 7 * S);
            const snout = this._box(this.materials.pigSnout, 4, 3, 2);
            snout.position.set(0, -2 * S, 4.5 * S);
            headMesh.add(snout);
            group.add(headMesh);

            legL1 = this._limb(this.materials.pigLeg, 4, 6, 4, 3);
            legL1.position.set(-3.5 * S, 6 * S, 5 * S);
            legR1 = this._limb(this.materials.pigLeg, 4, 6, 4, 3);
            legR1.position.set(3.5 * S, 6 * S, 5 * S);
            legL2 = this._limb(this.materials.pigLeg, 4, 6, 4, 3);
            legL2.position.set(-3.5 * S, 6 * S, -5 * S);
            legR2 = this._limb(this.materials.pigLeg, 4, 6, 4, 3);
            legR2.position.set(3.5 * S, 6 * S, -5 * S);
            group.add(legL1, legR1, legL2, legR2);
        } else if (type === 'sheep') {
            // Authentic Sheep Fluffy Wool Body: 12 wide, 10 high, 16 deep
            const body = this._box(this.materials.sheepWool, 12, 10, 16);
            body.position.set(0, 15 * S, 0);
            group.add(body);

            const headMaterials = [
                this.materials.sheepFace,
                this.materials.sheepFace,
                this.materials.sheepWool,
                this.materials.sheepFace,
                this.materials.sheepFace,
                this.materials.sheepWool
            ];
            headMesh = this._box(headMaterials, 6, 6, 8);
            headMesh.position.set(0, 17 * S, 8 * S);
            group.add(headMesh);

            legL1 = this._limb(this.materials.sheepLeg, 4, 12, 4, 6);
            legL1.position.set(-4 * S, 12 * S, 5 * S);
            legR1 = this._limb(this.materials.sheepLeg, 4, 12, 4, 6);
            legR1.position.set(4 * S, 12 * S, 5 * S);
            legL2 = this._limb(this.materials.sheepLeg, 4, 12, 4, 6);
            legL2.position.set(-4 * S, 12 * S, -5 * S);
            legR2 = this._limb(this.materials.sheepLeg, 4, 12, 4, 6);
            legR2.position.set(4 * S, 12 * S, -5 * S);
            group.add(legL1, legR1, legL2, legR2);
        } else if (type === 'chicken') {
            // Chicken
            const body = this._box(this.materials.chickenBody, 6, 6, 8);
            body.position.set(0, 8 * S, 0);
            group.add(body);

            const headMaterials = [
                this.materials.chickenBody,
                this.materials.chickenBody,
                this.materials.chickenBody,
                this.materials.chickenBody,
                this.materials.chickenFace,
                this.materials.chickenBody
            ];
            headMesh = this._box(headMaterials, 4, 6, 4);
            headMesh.position.set(0, 12 * S, 4 * S);
            const beak = this._box(this.materials.chickenBeak, 4, 2, 2);
            beak.position.set(0, -1 * S, 3 * S);
            const wattle = this._box(this.materials.chickenWattle, 2, 3, 2);
            wattle.position.set(0, -3 * S, 2 * S);
            headMesh.add(beak, wattle);
            group.add(headMesh);

            // Authentic Minecraft Chicken Wings
            const wingL = this._limb(this.materials.chickenBody, 1, 4, 6, 2);
            wingL.position.set(-3.5 * S, 9 * S, 0);
            const wingR = this._limb(this.materials.chickenBody, 1, 4, 6, 2);
            wingR.position.set(3.5 * S, 9 * S, 0);
            group.add(wingL, wingR);

            legL1 = this._limb(this.materials.chickenLeg, 2, 5, 2, 2.5);
            legL1.position.set(-1.5 * S, 5 * S, 0);
            legR1 = this._limb(this.materials.chickenLeg, 2, 5, 2, 2.5);
            legR1.position.set(1.5 * S, 5 * S, 0);
            legL2 = legL1;
            legR2 = legR1;
            group.add(legL1, legR1);
            speed = 1.4;
        } else if (type === 'villager') {
            // Authentic Minecraft Villager
            // Head: 8x10x8 with unibrow, emerald eyes
            const headMaterials = [
                this.materials.villagerSkin,
                this.materials.villagerSkin,
                this.materials.villagerSkin,
                this.materials.villagerSkin,
                this.materials.villagerFace, // front face
                this.materials.villagerSkin
            ];
            headMesh = this._box(headMaterials, 8, 10, 8);
            headMesh.position.set(0, 24 * S, 0);

            // 3D Villager Nose protruding forward
            const nose = this._box(this.materials.villagerNose, 2, 4, 2);
            nose.position.set(0, -2 * S, 4.8 * S);
            headMesh.add(nose);
            group.add(headMesh);

            // Robe Torso: 8x12x6
            const torso = this._box(this.materials.villagerRobe, 8, 12, 6);
            torso.position.set(0, 15 * S, 0);
            group.add(torso);

            // Folded Arms across chest (iconic villager posture)
            const arms = this._box(this.materials.villagerArms, 8, 8, 4);
            arms.position.set(0, 13 * S, 3.2 * S);
            group.add(arms);

            // 2 Legs: 4x12x4 pivoted at hip y = 10 * S
            legL1 = this._limb(this.materials.villagerRobe, 4, 10, 4, 5);
            legL1.position.set(-2 * S, 10 * S, 0);
            legR1 = this._limb(this.materials.villagerRobe, 4, 10, 4, 5);
            legR1.position.set(2 * S, 10 * S, 0);
            legL2 = legL1;
            legR2 = legR1;
            group.add(legL1, legR1);
            speed = 1.5;
        } else if (type === 'iron_golem') {
            // Authentic Iron Golem (3 blocks tall)
            const headMaterials = [
                this.materials.ironGolemBody,
                this.materials.ironGolemBody,
                this.materials.ironGolemBody,
                this.materials.ironGolemBody,
                this.materials.ironGolemFace,
                this.materials.ironGolemBody
            ];
            headMesh = this._box(headMaterials, 8, 10, 8);
            headMesh.position.set(0, 36 * S, -2 * S);
            const nose = this._box(this.materials.ironGolemNose, 2, 4, 2);
            nose.position.set(0, -2 * S, 4.8 * S);
            headMesh.add(nose);
            group.add(headMesh);

            // Huge Torso: 18 wide, 12 high, 10 deep
            const torso = this._box(this.materials.ironGolemBody, 18, 12, 10);
            torso.position.set(0, 27 * S, 0);
            group.add(torso);

            // Long arms: 4x30x4
            legL2 = this._limb(this.materials.ironGolemBody, 4, 28, 4, 14);
            legL2.position.set(-11 * S, 28 * S, 0);
            legR2 = this._limb(this.materials.ironGolemBody, 4, 28, 4, 14);
            legR2.position.set(11 * S, 28 * S, 0);
            group.add(legL2, legR2);

            // Sturdy legs: 6x16x6
            legL1 = this._limb(this.materials.ironGolemBody, 6, 16, 6, 8);
            legL1.position.set(-5 * S, 16 * S, 0);
            legR1 = this._limb(this.materials.ironGolemBody, 6, 16, 6, 8);
            legR1.position.set(5 * S, 16 * S, 0);
            group.add(legL1, legR1);
            speed = 1.1;
            health = 100;
        }

        const id = `friendly_${this.nextId++}`;
        group.position.set(x, y + 1, z);
        group.traverse((obj) => {
            if ((obj as any).isMesh) {
                obj.userData.mobId = id;
                obj.userData.mobKind = 'friendly';
            }
        });

        const initialYaw = Math.random() * Math.PI * 2;
        group.rotation.y = initialYaw;

        this.scene.add(group);
        this.entities.set(id, {
            id,
            type,
            group,
            head: headMesh,
            legL1,
            legR1,
            legL2,
            legR2,
            wingL: (type === 'chicken') ? group.children[group.children.length - 3] : null,
            wingR: (type === 'chicken') ? group.children[group.children.length - 2] : null,
            arms: (type === 'villager') ? group.children[2] : null,
            armL: (type === 'iron_golem') ? legL2 : null,
            armR: (type === 'iron_golem') ? legR2 : null,
            health,
            state: 'idle',
            stateTimer: 2 + Math.random() * 3,
            targetX: x,
            targetZ: z,
            // Full Minecraft physics & animation state:
            vel: new THREE.Vector3(0, 0, 0),
            onGround: true,
            inWater: false,
            baseSpeed: speed,
            bodyYaw: initialYaw,
            headYaw: 0,
            headPitch: 0,
            targetHeadYaw: 0,
            targetHeadPitch: 0,
            limbSwing: 0,
            limbSwingAmount: 0,
            wingFlapTime: 0,
            eatTimer: 0,
            idleLookTimer: 1 + Math.random() * 3,
            hurtTilt: 0,
            flashTimer: 0
        });
    }

    createEntity(spawn: any) {
        const type = spawn.type || 'cow';
        this.createFriendly(type, spawn.x, spawn.y, spawn.z);
    }

    spawnInitialVillagers(playerPos: THREE.Vector3) {
        let villagerCount = 0;
        for (const ent of this.entities.values()) {
            if (ent.type === 'villager') villagerCount++;
        }
        if (villagerCount >= 3) return;

        const offsets = [
            { x: 5, z: 4 },
            { x: -5, z: 6 },
            { x: 4, z: -5 },
            { x: -4, z: -4 }
        ];

        for (const off of offsets) {
            const wx = Math.floor(playerPos.x + off.x);
            const wz = Math.floor(playerPos.z + off.z);
            const wy = this.world.findSurfaceY(wx, wz);
            this.createFriendly('villager', wx, wy, wz);
        }

        // Also 1 protective Iron Golem
        const gx = Math.floor(playerPos.x + 8);
        const gz = Math.floor(playerPos.z + 5);
        const gy = this.world.findSurfaceY(gx, gz);
        this.createFriendly('iron_golem', gx, gy, gz);
    }

    spawnFromEgg(eggId: string, x: number, y: number, z: number): boolean {
        const lower = (eggId || '').toLowerCase();
        if (lower.includes('villager')) {
            this.createFriendly('villager', x, y, z);
            return true;
        }
        if (lower.includes('golem')) {
            this.createFriendly('iron_golem', x, y, z);
            return true;
        }
        const types: Array<'cow' | 'pig' | 'sheep' | 'chicken' | 'villager'> = ['cow', 'pig', 'sheep', 'chicken', 'villager'];
        const type = types[Math.floor(Math.random() * types.length)];
        this.createFriendly(type, x, y, z);
        return true;
    }

    update(dt: number, playerPosition: THREE.Vector3, daylight = 1.0) {
        // Natural mob spawning in peaceful Minecraft biomes (only during daylight on grass)
        this.spawnTimer += dt;
        if (daylight > 0.48 && this.spawnTimer > 4.5 && this.entities.size < this.maxFriendly) {
            this.spawnTimer = 0;
            const angle = Math.random() * Math.PI * 2;
            const dist = 18 + Math.random() * 20;
            const spawnX = Math.floor(playerPosition.x + Math.cos(angle) * dist);
            const spawnZ = Math.floor(playerPosition.z + Math.sin(angle) * dist);
            const surfaceY = this.world.findSurfaceY(spawnX, spawnZ);

            if (surfaceY >= CONFIG.WATER_LEVEL) {
                const groundBlock = this.world.getVoxel(spawnX, surfaceY, spawnZ);
                if (groundBlock === BLOCK_ID.GRASS) {
                    const types: Array<'cow' | 'pig' | 'sheep' | 'chicken' | 'villager'> = ['cow', 'pig', 'sheep', 'chicken', 'villager'];
                    const pickedType = types[Math.floor(Math.random() * types.length)];
                    // Spawn pack of 2-3 animals (or 1-2 villagers)
                    const packCount = pickedType === 'villager' ? (1 + Math.floor(Math.random() * 2)) : (2 + Math.floor(Math.random() * 2));
                    for (let i = 0; i < packCount; i++) {
                        const ox = (Math.random() - 0.5) * 4;
                        const oz = (Math.random() - 0.5) * 4;
                        const y = this.world.findSurfaceY(Math.floor(spawnX + ox), Math.floor(spawnZ + oz));
                        this.createFriendly(pickedType, spawnX + ox, y, spawnZ + oz);
                    }
                }
            }
        }

        const S = 1 / 16;
        // Update each friendly entity with authentic Minecraft physics, pathing and animations
        for (const [id, ent] of Array.from(this.entities.entries())) {
            ent.stateTimer -= dt;

            // Damage flash
            if (ent.flashTimer > 0) {
                ent.flashTimer -= dt;
            }

            const dxPlayer = playerPosition.x - ent.group.position.x;
            const dzPlayer = playerPosition.z - ent.group.position.z;
            const distToPlayer = Math.hypot(dxPlayer, dzPlayer);

            // Despawn if far away (> 85 blocks), but villagers and iron golems stay persistent
            if (distToPlayer > 85 && ent.type !== 'villager' && ent.type !== 'iron_golem') {
                this.scene.remove(ent.group);
                this.entities.delete(id);
                continue;
            }

            let desiredVx = 0;
            let desiredVz = 0;
            let targetHeadYaw = 0;
            let targetHeadPitch = 0;

            const isNight = daylight < 0.35;

            if (ent.state === 'panic') {
                // Sprint rapidly away from player
                const panicSpeed = ent.baseSpeed * 1.85;
                const safeDist = Math.max(0.1, distToPlayer);
                desiredVx = -(dxPlayer / safeDist) * panicSpeed;
                desiredVz = -(dzPlayer / safeDist) * panicSpeed;

                if (ent.stateTimer <= 0) {
                    ent.state = 'idle';
                    ent.stateTimer = 2 + Math.random() * 3;
                }
            } else if (ent.state === 'wander' && !isNight) {
                const dx = ent.targetX - ent.group.position.x;
                const dz = ent.targetZ - ent.group.position.z;
                const distToTarget = Math.hypot(dx, dz);

                if (distToTarget > 0.4) {
                    const wanderSpeed = ent.baseSpeed * 0.75;
                    desiredVx = (dx / distToTarget) * wanderSpeed;
                    desiredVz = (dz / distToTarget) * wanderSpeed;
                } else {
                    ent.state = 'idle';
                    ent.stateTimer = 2.5 + Math.random() * 3.5;
                }

                if (ent.stateTimer <= 0) {
                    ent.state = 'idle';
                    ent.stateTimer = 2.5 + Math.random() * 3.5;
                }
            } else {
                // Idle / Resting state: calm standing, grazing, or sleeping at night
                desiredVx = 0;
                desiredVz = 0;

                if (distToPlayer < 7.5 && !isNight) {
                    // Turn head to look directly at the player during day
                    const angleToPlayer = Math.atan2(dxPlayer, dzPlayer);
                    const relYaw = wrapAngle(angleToPlayer - ent.bodyYaw);
                    targetHeadYaw = Math.max(-1.25, Math.min(1.25, relYaw));

                    const dyPlayer = (playerPosition.y + 0.5) - (ent.group.position.y + 1.2);
                    targetHeadPitch = Math.max(-0.65, Math.min(0.65, Math.atan2(-dyPlayer, Math.max(0.5, distToPlayer))));

                    // If player is behind them, slowly rotate body towards player
                    if (Math.abs(relYaw) > 1.2) {
                        ent.bodyYaw += relYaw * dt * 2.0;
                    }
                } else if (isNight) {
                    // Sleeping / resting pose at night: head slightly dipped down
                    targetHeadPitch = 0.28;
                } else {
                    // Natural subtle glances when idle
                    ent.idleLookTimer -= dt;
                    if (ent.idleLookTimer <= 0) {
                        ent.idleLookTimer = 2.5 + Math.random() * 3.5;
                        ent.targetHeadYaw = (Math.random() - 0.5) * 0.7;
                        ent.targetHeadPitch = (Math.random() - 0.5) * 0.3;
                    }
                    targetHeadYaw = ent.targetHeadYaw || 0;
                    targetHeadPitch = ent.targetHeadPitch || 0;
                }

                if (ent.stateTimer <= 0) {
                    if (isNight) {
                        // Night resting: mostly stay idle with occasional tiny shift
                        ent.state = Math.random() < 0.2 ? 'wander' : 'idle';
                        ent.stateTimer = 4.0 + Math.random() * 5.0;
                    } else {
                        ent.state = Math.random() < 0.6 ? 'wander' : 'idle';
                        ent.stateTimer = 3.0 + Math.random() * 4.0;
                    }
                    const wanderRadius = isNight ? 3 : 7;
                    ent.targetX = ent.group.position.x + (Math.random() - 0.5) * wanderRadius * 2;
                    ent.targetZ = ent.group.position.z + (Math.random() - 0.5) * wanderRadius * 2;
                }
            }

            // Authentic Minecraft mob physics step
            const phys = updateMobMinecraftPhysics(
                this.world,
                ent.group.position,
                ent.vel,
                desiredVx,
                desiredVz,
                dt,
                ent.type,
                ent.bodyYaw,
                false
            );
            const wasGround = ent.onGround;
            ent.onGround = phys.onGround;
            ent.inWater = phys.inWater;

            // Minecraft authentic fall damage for friendly mobs
            if (ent.inWater || ent.type === 'chicken') {
                ent.fallStartY = ent.group.position.y;
            } else if (!ent.onGround) {
                if (ent.fallStartY === undefined || ent.group.position.y > ent.fallStartY) {
                    ent.fallStartY = ent.group.position.y;
                }
            } else if (ent.onGround && !wasGround) {
                if (ent.fallStartY !== undefined) {
                    const fallDist = ent.fallStartY - ent.group.position.y;
                    if (fallDist > 3.0 && ent.type !== 'chicken' && ent.type !== 'iron_golem') {
                        const fallDamage = Math.floor(fallDist - 3.0);
                        if (fallDamage > 0) {
                            this.damageEntityDirect(ent, id, fallDamage);
                        }
                    }
                }
                ent.fallStartY = ent.group.position.y;
            }

            if (phys.blocked && ent.state === 'wander') {
                // If obstacle is encountered, pick a new direction
                ent.state = 'idle';
                ent.stateTimer = 1.0 + Math.random() * 2.0;
            }

            // Smooth body yaw turning towards actual motion direction (no instant snapping)
            const horizSpeed = Math.hypot(ent.vel.x, ent.vel.z);
            if (horizSpeed > 0.08) {
                const moveYaw = Math.atan2(ent.vel.x, ent.vel.z);
                const yawDiff = wrapAngle(moveYaw - ent.bodyYaw);
                const maxTurn = 7.5 * dt;
                ent.bodyYaw += Math.max(-maxTurn, Math.min(maxTurn, yawDiff));
            }
            ent.group.rotation.y = ent.bodyYaw;

            // Smooth head tracking
            if (ent.head) {
                ent.headYaw = THREE.MathUtils.lerp(ent.headYaw || 0, targetHeadYaw, dt * 6.5);
                ent.headPitch = THREE.MathUtils.lerp(ent.headPitch || 0, targetHeadPitch, dt * 6.5);
                ent.head.rotation.y = ent.headYaw;
                ent.head.rotation.x = ent.headPitch;
            }

            // Authentic Minecraft damage tilt recovery
            if (ent.hurtTilt > 0) {
                ent.hurtTilt = Math.max(0, ent.hurtTilt - dt * 2.8);
                ent.group.rotation.z = Math.sin(ent.hurtTilt * Math.PI) * 0.24;
            } else {
                ent.group.rotation.z = 0;
            }

            // Limb swing calculations (scales smoothly with actual ground speed; returns to 0 at rest)
            const targetSwingAmount = Math.min(1.0, horizSpeed / (ent.baseSpeed || 1.4));
            ent.limbSwingAmount = THREE.MathUtils.lerp(ent.limbSwingAmount || 0, targetSwingAmount, dt * 8.5);
            ent.limbSwing = (ent.limbSwing || 0) + ent.limbSwingAmount * dt * 11.0;

            if (ent.type === 'cow' || ent.type === 'pig' || ent.type === 'sheep') {
                // Authentic Minecraft diagonal quadruped leg gait (QuadrupedModel.java formula)
                const swing = Math.cos(ent.limbSwing * 0.6662) * 1.25 * ent.limbSwingAmount;
                if (ent.legL1) ent.legL1.rotation.x = swing;
                if (ent.legR1) ent.legR1.rotation.x = -swing;
                if (ent.legL2 && ent.legL2 !== ent.legL1) ent.legL2.rotation.x = -swing;
                if (ent.legR2 && ent.legR2 !== ent.legR1) ent.legR2.rotation.x = swing;

                // Authentic grazing animation
                if (ent.eatTimer > 0) {
                    ent.eatTimer -= dt;
                    if (ent.head) {
                        ent.head.rotation.x = THREE.MathUtils.lerp(ent.head.rotation.x, 0.72, dt * 6.0);
                        ent.head.position.y = THREE.MathUtils.lerp(ent.head.position.y, (ent.type === 'sheep' ? 12 : 11) * S, dt * 6.0);
                    }
                } else {
                    if (ent.head) {
                        const defaultHeadY = (ent.type === 'sheep' ? 17 : (ent.type === 'pig' ? 12 : 16)) * S;
                        ent.head.position.y = THREE.MathUtils.lerp(ent.head.position.y, defaultHeadY, dt * 6.0);
                    }
                    if (ent.state === 'idle' && Math.random() < 0.003) {
                        ent.eatTimer = 2.2 + Math.random() * 1.8;
                    }
                }
            } else if (ent.type === 'chicken') {
                // Chicken fast alternating steps
                const chSwing = Math.sin(ent.limbSwing * 1.4) * 0.7 * ent.limbSwingAmount;
                if (ent.legL1) ent.legL1.rotation.x = chSwing;
                if (ent.legR1) ent.legR1.rotation.x = -chSwing;

                // Chicken head bobbing forward and back with stride
                if (ent.head) {
                    ent.head.position.z = 4 * S + Math.sin(ent.limbSwing * 1.4) * 0.035 * ent.limbSwingAmount;
                }

                // Chicken wing fluttering when in air (gliding) or folded against body when on ground
                if (ent.wingL && ent.wingR) {
                    if (!ent.onGround || ent.vel.y < -0.15) {
                        ent.wingFlapTime = (ent.wingFlapTime || 0) + dt * 28.0;
                        ent.wingL.rotation.z = Math.sin(ent.wingFlapTime) * 0.95;
                        ent.wingR.rotation.z = -Math.sin(ent.wingFlapTime) * 0.95;
                    } else {
                        ent.wingL.rotation.z = 0.06 + Math.sin(ent.limbSwing) * 0.14 * ent.limbSwingAmount;
                        ent.wingR.rotation.z = -0.06 - Math.sin(ent.limbSwing) * 0.14 * ent.limbSwingAmount;
                    }
                }
            } else if (ent.type === 'villager') {
                // Villager legs inside robe
                const vSwing = Math.sin(ent.limbSwing) * 0.6 * ent.limbSwingAmount;
                if (ent.legL1) ent.legL1.rotation.x = vSwing;
                if (ent.legR1) ent.legR1.rotation.x = -vSwing;

                // Iconic folded arms sway gently with breath and walking stride
                if (ent.arms) {
                    ent.arms.position.y = 13 * S + Math.sin(ent.limbSwing * 1.2) * 0.015 * ent.limbSwingAmount;
                    ent.arms.rotation.x = Math.sin(ent.limbSwing * 1.2) * 0.08 * ent.limbSwingAmount;
                }
            } else if (ent.type === 'iron_golem') {
                // Heavy Iron Golem stomping stride
                const gSwing = Math.sin(ent.limbSwing * 0.8) * 0.55 * ent.limbSwingAmount;
                if (ent.legL1) ent.legL1.rotation.x = gSwing;
                if (ent.legR1) ent.legR1.rotation.x = -gSwing;
                if (ent.armL) ent.armL.rotation.x = -gSwing * 1.1;
                if (ent.armR) ent.armR.rotation.x = gSwing * 1.1;
            }

            // Damage red flash animation
            if (ent.flashTimer !== undefined && ent.flashTimer > 0) {
                ent.flashTimer -= dt;
                ent.group.traverse((obj: any) => {
                    if (obj.isMesh && obj.material) {
                        if (obj.userData.origColor === undefined && obj.material.color) {
                            obj.userData.origColor = obj.material.color.getHex();
                        }
                        obj.material.color?.setHex(0xff3333);
                    }
                });
            } else if (ent.flashTimer !== undefined && ent.flashTimer <= 0 && ent.flashTimer > -10) {
                ent.flashTimer = -99;
                ent.group.traverse((obj: any) => {
                    if (obj.isMesh && obj.material && obj.userData.origColor !== undefined) {
                        obj.material.color?.setHex(obj.userData.origColor);
                    }
                });
            }
        }
    }

    getRaycastTargets(): THREE.Mesh[] {
        const list: THREE.Mesh[] = [];
        for (const ent of this.entities.values()) {
            ent.group.traverse((obj: any) => {
                if (obj.isMesh) list.push(obj);
            });
        }
        return list;
    }

    damageEntityDirect(ent: any, id: string, amount = 1, attackerPos?: THREE.Vector3): boolean {
        ent.health -= amount;
        ent.flashTimer = 0.25;
        ent.state = 'panic';
        ent.stateTimer = 3.0;

        // Authentic Minecraft knockback arc & damage tilt
        ent.hurtTilt = 1.0;
        if (attackerPos) {
            const dx = ent.group.position.x - attackerPos.x;
            const dz = ent.group.position.z - attackerPos.z;
            const dist = Math.hypot(dx, dz) || 1;
            ent.vel.x = (dx / dist) * 6.5;
            ent.vel.z = (dz / dist) * 6.5;
            ent.vel.y = 4.8; // Vertical knockback pop
            ent.onGround = false;
        }

        if (ent.health <= 0) {
            // Drop authentic animal products into the world as spinning items
            const app = (window as any).app;
            const dropPos = ent.group.position.clone();
            dropPos.y += 0.35;

            const spawnOrAdd = (kind: 'resource' | 'block', itemId: any, count: number) => {
                if (count <= 0) return;
                if (app?.droppedItemManager) {
                    app.droppedItemManager.spawn({ kind, id: itemId, count }, dropPos);
                } else if (app?.inventory) {
                    if (kind === 'resource') app.inventory.addResource(itemId, count);
                    else app.inventory.addBlock(itemId, count);
                }
            };

            if (ent.type === 'cow') {
                spawnOrAdd('resource', 'raw_beef', 1 + Math.floor(Math.random() * 3));
                spawnOrAdd('resource', 'leather', 1 + Math.floor(Math.random() * 2));
            } else if (ent.type === 'pig') {
                spawnOrAdd('resource', 'raw_porkchop', 1 + Math.floor(Math.random() * 3));
            } else if (ent.type === 'sheep') {
                spawnOrAdd('resource', 'raw_mutton', 1 + Math.floor(Math.random() * 2));
                spawnOrAdd('block', BLOCK_ID.SNOW, 1);
            } else if (ent.type === 'villager') {
                spawnOrAdd('resource', 'emerald', 1 + Math.floor(Math.random() * 2));
                spawnOrAdd('resource', 'bread', 1 + Math.floor(Math.random() * 3));
            } else if (ent.type === 'iron_golem') {
                spawnOrAdd('resource', 'iron_ingot', 3 + Math.floor(Math.random() * 3));
                spawnOrAdd('resource', 'poppy', 1 + Math.floor(Math.random() * 2));
            } else {
                spawnOrAdd('resource', 'raw_chicken', 1);
                spawnOrAdd('resource', 'feather', 1 + Math.floor(Math.random() * 2));
            }

            app?.audio?.playMobDeath('friendly', ent.type);
            app?.particleKernel?.spawnDebris(ent.group.position.x, ent.group.position.y + 0.5, ent.group.position.z, 0xf0f0f0);
            this.scene.remove(ent.group);
            this.entities.delete(id);
        } else {
            const app = (window as any).app;
            app?.audio?.playMobHurt('friendly', ent.type);
        }
        return true;
    }

    applyDamageFromHit(hit: any, amount = 1, attackerPos?: THREE.Vector3): boolean {
        const id = hit?.object?.userData?.mobId;
        if (!id) return false;
        const ent = this.entities.get(id);
        if (!ent) return false;
        return this.damageEntityDirect(ent, id, amount, attackerPos);
    }

    getCount() { return this.entities.size; }

    tryOpenTrade(pos: THREE.Vector3): boolean {
        const app = (window as any).app;
        for (const ent of this.entities.values()) {
            if (ent.type === 'villager') {
                const dist = pos.distanceTo(ent.group.position);
                if (dist < 4.0) {
                    // Turn villager towards player
                    const dx = pos.x - ent.group.position.x;
                    const dz = pos.z - ent.group.position.z;
                    ent.group.rotation.y = Math.atan2(dx, dz);
                    app?.audio?.playVillagerHmm?.();

                    const emeraldCount = app?.inventory?.getResourceCount?.('emerald') || 0;
                    const wheatCount = app?.inventory?.getResourceCount?.('wheat') || 0;
                    const coalCount = app?.inventory?.getResourceCount?.('coal') || 0;
                    const ironCount = app?.inventory?.getResourceCount?.('iron_ingot') || 0;

                    if (emeraldCount >= 8) {
                        app.inventory.removeResource('emerald', 8);
                        const weapon = Math.random() < 0.5 ? 'diamond_mace' : 'diamond_spear';
                        app.inventory.addResource(weapon, 1);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Weaponsmith)', `§a*Hrrr! A master weapon!* Traded 8 Emeralds for 1 ${weapon.replace('_', ' ').toUpperCase()}! ⚔️`, 'system');
                    } else if (emeraldCount >= 5) {
                        app.inventory.removeResource('emerald', 5);
                        app.inventory.addResource('diamond', 1);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Cleric)', '§a*Pleasure doing business!* Traded 5 Emeralds for 1 Diamond! 💎', 'system');
                    } else if (emeraldCount >= 1) {
                        app.inventory.removeResource('emerald', 1);
                        app.inventory.addResource('bread', 6);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Farmer)', '§a*Hrrr! Fresh harvest!* Traded 1 Emerald for 6 Bread! 🍞', 'system');
                    } else if (wheatCount >= 12) {
                        app.inventory.removeResource('wheat', 12);
                        app.inventory.addResource('emerald', 1);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Farmer)', '§a*Hrrr!* Traded 12 Wheat for 1 Emerald! 🟩', 'system');
                    } else if (coalCount >= 15) {
                        app.inventory.removeResource('coal', 15);
                        app.inventory.addResource('emerald', 1);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Armorer)', '§a*Hrrr!* Traded 15 Coal for 1 Emerald! 🟩', 'system');
                    } else if (ironCount >= 4) {
                        app.inventory.removeResource('iron_ingot', 4);
                        app.inventory.addResource('emerald', 1);
                        app?.audio?.playVillagerTrade?.();
                        app?.pushChatLine?.('Villager (Armorer)', '§a*Hrrr!* Traded 4 Iron Ingots for 1 Emerald! 🟩', 'system');
                    } else {
                        app?.pushChatLine?.('Villager', '§eHrrr... [Trades: 12 Wheat / 15 Coal / 4 Iron ➔ 1 Emerald | 1 Emerald ➔ 6 Bread | 5 Emeralds ➔ 1 Diamond | 8 Emeralds ➔ Diamond Mace / Spear]', 'system');
                    }
                    return true;
                }
            }
        }
        return false;
    }
}

export class HostileMobManager {
    scene: THREE.Scene;
    world: VoxelWorld;
    entities = new Map<string, any>();
    materials: Record<string, THREE.Material>;
    arrowManager: ArrowManager;
    spawnTimer = 0;
    maxHostiles = 10;
    nextId = 1;

    constructor(scene: THREE.Scene, world: VoxelWorld) {
        this.scene = scene;
        this.world = world;
        this.arrowManager = new ArrowManager(this.scene);

        // Authentic Minecraft Zombie Face Texture (16x16 pixel art)
        const zombieFaceTex = createPixelTexture(16, 16, (ctx) => {
            // Rotten green skin base
            ctx.fillStyle = '#4c7b38';
            ctx.fillRect(0, 0, 16, 16);

            // Mossy decayed skin spots
            ctx.fillStyle = '#5c9245';
            ctx.fillRect(2, 2, 4, 3);
            ctx.fillRect(10, 3, 3, 3);
            ctx.fillRect(1, 10, 4, 4);

            // Dark messy hair across forehead and scalp
            ctx.fillStyle = '#2b4720';
            ctx.fillRect(0, 0, 16, 4);
            ctx.fillRect(2, 4, 3, 2);
            ctx.fillRect(8, 4, 2, 1);
            ctx.fillRect(11, 4, 3, 2);

            // Sunken dark black/navy zombie eyes (classic 2x1 Minecraft eye bars)
            ctx.fillStyle = '#141e12';
            ctx.fillRect(2, 6, 3, 2);
            ctx.fillRect(9, 6, 3, 2);

            // Nose
            ctx.fillStyle = '#395d2a';
            ctx.fillRect(6, 8, 3, 2);

            // Decayed dark mouth
            ctx.fillStyle = '#1f3317';
            ctx.fillRect(4, 11, 6, 2);
        });

        // Creeper Face Texture (16x16 pixel art)
        const creeperFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#4fa847';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#3d8636';
            ctx.fillRect(1, 1, 4, 3);
            ctx.fillRect(10, 2, 4, 4);

            // Black Creeper eyes and frowning mouth
            ctx.fillStyle = '#0f140e';
            ctx.fillRect(2, 4, 3, 3); // left eye
            ctx.fillRect(9, 4, 3, 3); // right eye
            ctx.fillRect(6, 7, 2, 5); // center nose bar
            ctx.fillRect(4, 9, 6, 4); // mouth box
            ctx.fillRect(3, 11, 2, 4); // mouth drop left
            ctx.fillRect(9, 11, 2, 4); // mouth drop right
        });

        // Skeleton Face Texture (16x16 pixel art)
        const skeletonFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#d2d0c7'; // Bone white
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#1c1c1c'; // Eye sockets
            ctx.fillRect(2, 5, 3, 3);
            ctx.fillRect(9, 5, 3, 3);
            ctx.fillRect(6, 8, 2, 2); // Nasal cavity
            ctx.fillRect(4, 11, 6, 2); // Teeth gap
        });

        // Spider Face Texture (16x16 pixel art)
        const spiderFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#261b16';
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#aa1515'; // Glowing red spider eyes
            ctx.fillRect(3, 5, 2, 2);
            ctx.fillRect(10, 5, 2, 2);
            ctx.fillRect(5, 8, 2, 1);
            ctx.fillRect(8, 8, 2, 1);
            ctx.fillRect(1, 5, 1, 1);
            ctx.fillRect(13, 5, 1, 1);
        });

        // Enderman Face Texture (16x16 pixel art)
        const endermanFaceTex = createPixelTexture(16, 16, (ctx) => {
            ctx.fillStyle = '#121017'; // Obsidian black
            ctx.fillRect(0, 0, 16, 16);
            ctx.fillStyle = '#c828e8'; // Glowing purple eyes
            ctx.fillRect(2, 6, 3, 1);
            ctx.fillRect(9, 6, 3, 1);
            ctx.fillStyle = '#ffffff'; // Center eye glint
            ctx.fillRect(3, 6, 1, 1);
            ctx.fillRect(10, 6, 1, 1);
        });

        this.materials = {
            zombieSkin: new THREE.MeshLambertMaterial({ color: 0x4c7b38 }),
            zombieFace: new THREE.MeshLambertMaterial({ map: zombieFaceTex }),
            zombieShirt: new THREE.MeshLambertMaterial({ color: 0x2e7d95 }), // Steve's cyan shirt
            zombiePants: new THREE.MeshLambertMaterial({ color: 0x28325a }), // Indigo pants
            creeperSkin: new THREE.MeshLambertMaterial({ color: 0x4fa847 }),
            creeperFace: new THREE.MeshLambertMaterial({ map: creeperFaceTex }),
            creeperLeg: new THREE.MeshLambertMaterial({ color: 0x3d8636 }),
            skeletonBone: new THREE.MeshLambertMaterial({ color: 0xd2d0c7 }),
            skeletonFace: new THREE.MeshLambertMaterial({ map: skeletonFaceTex }),
            skeletonBow: new THREE.MeshLambertMaterial({ color: 0x664426 }),
            spiderBody: new THREE.MeshLambertMaterial({ color: 0x221712 }),
            spiderFace: new THREE.MeshLambertMaterial({ map: spiderFaceTex }),
            spiderLeg: new THREE.MeshLambertMaterial({ color: 0x170f0c }),
            endermanSkin: new THREE.MeshLambertMaterial({ color: 0x121017 }),
            endermanFace: new THREE.MeshLambertMaterial({ map: endermanFaceTex })
        };
    }

    _box(mat: THREE.Material | THREE.Material[], w: number, h: number, d: number) {
        const geo = new THREE.BoxGeometry(w / 16, h / 16, d / 16);
        return new THREE.Mesh(geo, mat);
    }

    _limb(mat: THREE.Material, w: number, h: number, d: number, pivotOffsetY = h / 2) {
        const pivot = new THREE.Group();
        const mesh = this._box(mat, w, h, d);
        mesh.position.y = -pivotOffsetY / 16;
        pivot.add(mesh);
        return pivot;
    }

    createHostile(type: string, x: number, y: number, z: number) {
        const group = new THREE.Group();
        const S = 1 / 16;
        let legL: THREE.Group, legR: THREE.Group, legL2: THREE.Group | null = null, legR2: THREE.Group | null = null;
        let armL: THREE.Group | null = null, armR: THREE.Group | null = null;
        let headMesh: THREE.Mesh;
        let spiderLegs: THREE.Group[] | null = null;
        let health = 20;
        let speed = 1.75;

        if (type === 'creeper') {
            const headMaterials = [
                this.materials.creeperSkin,
                this.materials.creeperSkin,
                this.materials.creeperSkin,
                this.materials.creeperSkin,
                this.materials.creeperFace,
                this.materials.creeperSkin
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 24 * S, 0);

            const torso = this._box(this.materials.creeperSkin, 8, 12, 4);
            torso.position.set(0, 14 * S, 0);
            group.add(headMesh, torso);

            // Authentic 4 Minecraft creeper legs (2 front, 2 back)
            legL = this._limb(this.materials.creeperLeg, 4, 6, 4, 3);
            legL.position.set(-2.5 * S, 6 * S, 3 * S);
            legR = this._limb(this.materials.creeperLeg, 4, 6, 4, 3);
            legR.position.set(2.5 * S, 6 * S, 3 * S);
            legL2 = this._limb(this.materials.creeperLeg, 4, 6, 4, 3);
            legL2.position.set(-2.5 * S, 6 * S, -3 * S);
            legR2 = this._limb(this.materials.creeperLeg, 4, 6, 4, 3);
            legR2.position.set(2.5 * S, 6 * S, -3 * S);
            group.add(legL, legR, legL2, legR2);
            speed = 1.55;
        } else if (type === 'skeleton') {
            // Skeleton: Bone skull, ribs torso, bone limbs, wooden bow
            const headMaterials = [
                this.materials.skeletonBone,
                this.materials.skeletonBone,
                this.materials.skeletonBone,
                this.materials.skeletonBone,
                this.materials.skeletonFace,
                this.materials.skeletonBone
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 28 * S, 0);

            const torso = this._box(this.materials.skeletonBone, 8, 12, 4);
            torso.position.set(0, 18 * S, 0);

            armL = this._limb(this.materials.skeletonBone, 2, 12, 2, 6);
            armL.position.set(-5 * S, 22 * S, 0);
            armL.rotation.x = -1.4;

            armR = this._limb(this.materials.skeletonBone, 2, 12, 2, 6);
            armR.position.set(5 * S, 22 * S, 0);
            armR.rotation.x = -1.4;

            // Bow in skeleton's hand
            const bow = this._box(this.materials.skeletonBow, 1.5, 10, 1.5);
            bow.position.set(0, -5 * S, 4 * S);
            bow.rotation.y = Math.PI / 4;
            armR.add(bow);

            legL = this._limb(this.materials.skeletonBone, 2, 12, 2, 6);
            legL.position.set(-2 * S, 12 * S, 0);

            legR = this._limb(this.materials.skeletonBone, 2, 12, 2, 6);
            legR.position.set(2 * S, 12 * S, 0);

            group.add(headMesh, torso, armL, armR, legL, legR);
            speed = 1.65;
        } else if (type === 'spider') {
            // Spider: Head with red eyes, thorax, abdomen, 8 articulated legs
            const headMaterials = [
                this.materials.spiderBody,
                this.materials.spiderBody,
                this.materials.spiderBody,
                this.materials.spiderBody,
                this.materials.spiderFace,
                this.materials.spiderBody
            ];
            headMesh = this._box(headMaterials, 6, 6, 6);
            headMesh.position.set(0, 6 * S, 6 * S);

            const thorax = this._box(this.materials.spiderBody, 6, 6, 6);
            thorax.position.set(0, 6 * S, 0);

            const abdomen = this._box(this.materials.spiderBody, 10, 8, 12);
            abdomen.position.set(0, 7 * S, -8 * S);

            group.add(headMesh, thorax, abdomen);

            // 8 Spider legs extending outward
            spiderLegs = [];
            for (let i = 0; i < 4; i++) {
                const zOffset = (3 - i * 2.5) * S;
                // Left leg
                const legLeft = this._limb(this.materials.spiderLeg, 2, 10, 2, 5);
                legLeft.position.set(-4 * S, 6 * S, zOffset);
                legLeft.rotation.z = Math.PI / 3;
                // Right leg
                const legRight = this._limb(this.materials.spiderLeg, 2, 10, 2, 5);
                legRight.position.set(4 * S, 6 * S, zOffset);
                legRight.rotation.z = -Math.PI / 3;

                group.add(legLeft, legRight);
                spiderLegs.push(legLeft, legRight);
            }
            legL = spiderLegs[0];
            legR = spiderLegs[1];
            speed = 2.4;
            health = 16;
        } else if (type === 'enderman') {
            // Enderman (3 blocks tall = 48 pixels tall)
            const headMaterials = [
                this.materials.endermanSkin,
                this.materials.endermanSkin,
                this.materials.endermanSkin,
                this.materials.endermanSkin,
                this.materials.endermanFace,
                this.materials.endermanSkin
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 42 * S, 0);

            const torso = this._box(this.materials.endermanSkin, 8, 12, 4);
            torso.position.set(0, 32 * S, 0);

            armL = this._limb(this.materials.endermanSkin, 2, 30, 2, 15);
            armL.position.set(-5 * S, 36 * S, 0);

            armR = this._limb(this.materials.endermanSkin, 2, 30, 2, 15);
            armR.position.set(5 * S, 36 * S, 0);

            legL = this._limb(this.materials.endermanSkin, 2, 30, 2, 15);
            legL.position.set(-2 * S, 26 * S, 0);

            legR = this._limb(this.materials.endermanSkin, 2, 30, 2, 15);
            legR.position.set(2 * S, 26 * S, 0);

            group.add(headMesh, torso, armL, armR, legL, legR);
            speed = 2.6;
            health = 40;
        } else {
            // Authentic Minecraft Zombie (2 blocks tall = 32 pixels)
            const headMaterials = [
                this.materials.zombieSkin,
                this.materials.zombieSkin,
                this.materials.zombieSkin,
                this.materials.zombieSkin,
                this.materials.zombieFace,
                this.materials.zombieSkin
            ];
            headMesh = this._box(headMaterials, 8, 8, 8);
            headMesh.position.set(0, 28 * S, 0);

            const torso = this._box(this.materials.zombieShirt, 8, 12, 4);
            torso.position.set(0, 18 * S, 0);

            armL = this._limb(this.materials.zombieSkin, 4, 12, 4, 6);
            armL.position.set(-6 * S, 22 * S, 0);
            armL.rotation.x = -1.50; // Outstretched forward

            armR = this._limb(this.materials.zombieSkin, 4, 12, 4, 6);
            armR.position.set(6 * S, 22 * S, 0);
            armR.rotation.x = -1.50;

            legL = this._limb(this.materials.zombiePants, 4, 12, 4, 6);
            legL.position.set(-2 * S, 12 * S, 0);

            legR = this._limb(this.materials.zombiePants, 4, 12, 4, 6);
            legR.position.set(2 * S, 12 * S, 0);

            group.add(headMesh, torso, armL, armR, legL, legR);
        }

        const id = `hostile_${this.nextId++}`;
        group.position.set(x, y + 1, z);
        group.traverse((obj) => {
            if ((obj as any).isMesh) {
                obj.userData.mobId = id;
                obj.userData.mobKind = 'hostile';
            }
        });

        const initialYaw = Math.random() * Math.PI * 2;
        group.rotation.y = initialYaw;

        this.scene.add(group);
        this.entities.set(id, {
            id,
            type,
            group,
            head: headMesh,
            armL,
            armR,
            legL,
            legR,
            legL2,
            legR2,
            spiderLegs,
            health,
            speed,
            baseSpeed: speed,
            attackCooldown: 0,
            walkTime: 0,
            fuse: 0,
            isHissing: false,
            // Full Minecraft physics & animation state:
            vel: new THREE.Vector3(0, 0, 0),
            onGround: true,
            inWater: false,
            bodyYaw: initialYaw,
            headYaw: 0,
            headPitch: 0,
            limbSwing: 0,
            limbSwingAmount: 0,
            strafeTimer: 0,
            strafeDir: 1,
            leapCooldown: 0,
            hurtTilt: 0,
            flashTimer: 0,
            wanderTimer: 2 + Math.random() * 3,
            targetX: x,
            targetZ: z,
            state: 'idle',
            // 3D Voxel Pathfinding & Tactical Combat State:
            path: [],
            pathIndex: 0,
            pathRecalcTimer: Math.random() * 0.4,
            lastTargetPos: new THREE.Vector3(x, y, z),
            isClimbing: false,
            bowDrawTimer: 0,
            isDrawingBow: false,
            attackSwing: 0
        });
    }

    spawnFromEgg(eggId: string, x: number, y: number, z: number): boolean {
        let type = 'zombie';
        const lower = (eggId || '').toLowerCase();
        if (lower.includes('creeper')) type = 'creeper';
        else if (lower.includes('skeleton')) type = 'skeleton';
        else if (lower.includes('spider')) type = 'spider';
        else if (lower.includes('enderman')) type = 'enderman';
        else {
            const types = ['zombie', 'skeleton', 'creeper', 'spider', 'enderman'];
            type = types[Math.floor(Math.random() * types.length)];
        }
        this.createHostile(type, x, y, z);
        return true;
    }

    update(dt: number, playerPos: THREE.Vector3, daylight: number, survival: SurvivalSystem, friendlyMobs?: any) {
        const app = (window as any).app;

        // Update 3D ballistic arrow projectiles
        this.arrowManager.update(dt, this.world, playerPos, survival, friendlyMobs || app?.friendlyMobManager, this, app?.audio, app?.particleKernel);

        // Sunlight Burning for Zombies and Skeletons during daytime
        if (daylight > 0.52) {
            for (const [id, ent] of Array.from(this.entities.entries())) {
                if (ent.type === 'zombie' || ent.type === 'skeleton') {
                    const blockX = Math.floor(ent.group.position.x);
                    const blockY = Math.floor(ent.group.position.y);
                    const blockZ = Math.floor(ent.group.position.z);
                    const surfaceY = this.world.findSurfaceY(blockX, blockZ);

                    // Check if directly exposed to open sky (not under a roof or trees)
                    const isExposedToSky = ent.group.position.y >= surfaceY - 0.5;
                    const inWater = this.world.getVoxel(blockX, blockY, blockZ) === BLOCK_ID.WATER;

                    if (isExposedToSky && !inWater) {
                        // Mob catches fire!
                        if (Math.random() < 0.35) {
                            app?.particleKernel?.spawnFlame?.(
                                ent.group.position.x,
                                ent.group.position.y + 0.9,
                                ent.group.position.z
                            );
                            app?.particleKernel?.spawnSmoke?.(
                                ent.group.position.x,
                                ent.group.position.y + 1.25,
                                ent.group.position.z
                            );
                        }

                        ent.burnTimer = (ent.burnTimer || 0) + dt;
                        if (ent.burnTimer > 0.85) {
                            ent.burnTimer = 0;
                            this.damageEntityDirect(ent, id, 1.5);
                        }
                    }
                }
            }
        }

        // Spawn hostiles during dark hours (night / twilight or deep caves)
        this.spawnTimer += dt;
        const isNightOrDark = daylight < 0.42;
        const isUnderground = playerPos.y < 28;
        const spawnInterval = daylight < 0.20 ? 2.4 : 3.6; // Higher spawn density at midnight!

        if ((isNightOrDark || isUnderground) && this.spawnTimer > spawnInterval && this.entities.size < this.maxHostiles) {
            this.spawnTimer = 0;
            const angle = Math.random() * Math.PI * 2;
            const dist = 18 + Math.random() * 18;
            const x = Math.floor(playerPos.x + Math.cos(angle) * dist);
            const z = Math.floor(playerPos.z + Math.sin(angle) * dist);

            let y = this.world.findSurfaceY(x, z);
            let canSpawn = false;

            if (isNightOrDark) {
                // Surface spawn at night
                if (y > 4 && y < 120) {
                    canSpawn = true;
                }
            } else if (isUnderground) {
                // Underground cave spawn
                y = Math.floor(playerPos.y + (Math.random() - 0.5) * 6);
                if (y > 4 && this.world.getVoxel(x, y - 1, z) !== BLOCK_ID.AIR && this.world.getVoxel(x, y, z) === BLOCK_ID.AIR) {
                    canSpawn = true;
                }
            }

            if (canSpawn) {
                const types = ['zombie', 'skeleton', 'creeper', 'spider', 'enderman'];
                const picked = types[Math.floor(Math.random() * types.length)];
                this.createHostile(picked, x + 0.5, y, z + 0.5);

                // Midnight pack spawning: 35% chance to spawn an extra companion mob
                if (daylight < 0.20 && Math.random() < 0.35 && this.entities.size < this.maxHostiles) {
                    const companionType = Math.random() < 0.5 ? picked : types[Math.floor(Math.random() * types.length)];
                    this.createHostile(companionType, x + 1.5, y, z + 0.5);
                }
            }
        }

        const isCreative = survival.isCreative();
        const isPlayerDead = survival.health <= 0;
        const canAgro = !isCreative && !isPlayerDead;

        for (const ent of Array.from(this.entities.values())) {
            ent.attackCooldown = Math.max(0, ent.attackCooldown - dt);
            if (ent.leapCooldown !== undefined) {
                ent.leapCooldown = Math.max(0, ent.leapCooldown - dt);
            }
            if (ent.attackSwing > 0) {
                ent.attackSwing = Math.max(0, ent.attackSwing - dt * 4.0);
            }

            // Damage flash timer
            if (ent.flashTimer !== undefined && ent.flashTimer > 0) {
                ent.flashTimer -= dt;
                ent.group.traverse((obj: any) => {
                    if (obj.isMesh && obj.material) {
                        if (obj.userData.origColor === undefined && obj.material.color) {
                            obj.userData.origColor = obj.material.color.getHex();
                        }
                        obj.material.color?.setHex(0xff3333);
                    }
                });
            } else if (ent.flashTimer !== undefined && ent.flashTimer <= 0 && ent.flashTimer > -10) {
                ent.flashTimer = -99;
                ent.group.traverse((obj: any) => {
                    if (obj.isMesh && obj.material && obj.userData.origColor !== undefined) {
                        obj.material.color?.setHex(obj.userData.origColor);
                    }
                });
            }

            const dx = playerPos.x - ent.group.position.x;
            const dz = playerPos.z - ent.group.position.z;
            const dist = Math.hypot(dx, dz);

            let desiredVx = 0;
            let desiredVz = 0;
            let targetHeadYaw = 0;
            let targetHeadPitch = 0;

            const trackingRange = (ent.type === 'enderman') ? 36 : 26;

            // Spiders are peaceful & docile during daytime (daylight > 0.55) unless provoked!
            const isSpiderDocile = (ent.type === 'spider' && daylight > 0.55 && !ent.hasBeenProvoked);
            const mobCanAgro = canAgro && !isSpiderDocile;

            // 3D Line of Sight check
            const mobEyeY = ent.group.position.y + (ent.type === 'spider' ? 0.45 : (ent.type === 'enderman' ? 2.5 : 1.4));
            const mobEyePos = new THREE.Vector3(ent.group.position.x, mobEyeY, ent.group.position.z);
            const playerEyePos = new THREE.Vector3(playerPos.x, playerPos.y + 0.55, playerPos.z);
            const hasLos = mobCanAgro && dist < trackingRange && hasLineOfSight(this.world, mobEyePos, playerEyePos);

            // Creeper specific explosion logic
            if (ent.type === 'creeper') {
                if (canAgro && dist < 3.2 && hasLos) {
                    ent.fuse += dt;
                    if (!ent.isHissing) {
                        ent.isHissing = true;
                        app?.audio?.playCreeperHiss?.();
                    }
                    const flash = Math.sin(ent.fuse * 18) > 0;
                    ent.group.scale.set(flash ? 1.15 : 1.0, flash ? 1.15 : 1.0, flash ? 1.15 : 1.0);

                    if (ent.fuse >= 1.5) {
                        // DETONATE!
                        app?.audio?.playCreeperExplode?.();
                        if (dist < 4.8) {
                            survival.damage(12);
                            if (app?.player?.velocity) {
                                const kbSpeed = 14.0 * (1 - dist / 5.0);
                                app.player.velocity.x += (dx / Math.max(0.1, dist)) * kbSpeed;
                                app.player.velocity.z += (dz / Math.max(0.1, dist)) * kbSpeed;
                                app.player.velocity.y = Math.max(app.player.velocity.y, 6.0);
                            }
                        }
                        app?.particleKernel?.spawnDebris(ent.group.position.x, ent.group.position.y + 0.5, ent.group.position.z, 0x444444);
                        this.scene.remove(ent.group);
                        this.entities.delete(ent.id);
                        continue;
                    }
                } else {
                    ent.fuse = Math.max(0, ent.fuse - dt * 2);
                    ent.isHissing = false;
                    ent.group.scale.set(1, 1, 1);
                }
            }

            // Pathfinding navigation helper
            const updatePathfinding = (canClimbObstacles: boolean, mobH: number) => {
                ent.pathRecalcTimer = (ent.pathRecalcTimer || 0) - dt;
                const targetMovedFar = !ent.lastTargetPos || ent.lastTargetPos.distanceTo(playerPos) > 2.5;
                const needsPath = !ent.path || ent.path.length === 0 || ent.pathIndex >= ent.path.length;

                if (ent.pathRecalcTimer <= 0 || (targetMovedFar && needsPath)) {
                    ent.pathRecalcTimer = 0.55 + Math.random() * 0.35;
                    if (!ent.lastTargetPos) ent.lastTargetPos = new THREE.Vector3();
                    ent.lastTargetPos.copy(playerPos);
                    ent.path = findMobPath(this.world, ent.group.position, playerPos, {
                        maxDistance: 24,
                        canClimb: canClimbObstacles,
                        mobHeight: mobH
                    });
                    ent.pathIndex = 0;
                }

                // Steer along path waypoints
                if (ent.path && ent.path.length > 0 && ent.pathIndex < ent.path.length) {
                    const wp = ent.path[ent.pathIndex];
                    const wdx = wp.x - ent.group.position.x;
                    const wdz = wp.z - ent.group.position.z;
                    const wdist = Math.hypot(wdx, wdz);
                    if (wdist < 0.45 && Math.abs(wp.y - ent.group.position.y) < 1.35) {
                        ent.pathIndex++;
                    }
                    if (ent.pathIndex < ent.path.length) {
                        const cwp = ent.path[ent.pathIndex];
                        const cdx = cwp.x - ent.group.position.x;
                        const cdz = cwp.z - ent.group.position.z;
                        const cdist = Math.max(0.08, Math.hypot(cdx, cdz));
                        desiredVx = (cdx / cdist) * ent.speed;
                        desiredVz = (cdz / cdist) * ent.speed;
                        if (cwp.y > ent.group.position.y + 0.35 && ent.onGround) {
                            ent.vel.y = 5.2; // Jump up ledge
                        }
                        return;
                    }
                }
                // Direct fallback
                desiredVx = (dx / Math.max(0.1, dist)) * ent.speed;
                desiredVz = (dz / Math.max(0.1, dist)) * ent.speed;
            };

            // AI Navigation & Target Tracking
            if (canAgro && dist < trackingRange && dist > 0.8) {
                const angleToPlayer = Math.atan2(dx, dz);
                const relYaw = wrapAngle(angleToPlayer - ent.bodyYaw);
                targetHeadYaw = Math.max(-1.25, Math.min(1.25, relYaw));
                const dyPlayer = (playerPos.y + 0.5) - mobEyeY;
                targetHeadPitch = -Math.atan2(dyPlayer, Math.max(0.5, dist));
                targetHeadPitch = Math.max(-0.65, Math.min(0.65, targetHeadPitch));

                if (ent.type === 'skeleton') {
                    // Skeleton Tactical Archery AI: ranged shooting & circling strafe
                    if (hasLos && dist >= 3.8 && dist <= 17.5) {
                        ent.isDrawingBow = true;
                        ent.bowDrawTimer = (ent.bowDrawTimer || 0) + dt;

                        // Tactical circling strafe
                        ent.strafeTimer -= dt;
                        if (ent.strafeTimer <= 0) {
                            ent.strafeTimer = 1.8 + Math.random() * 2.2;
                            ent.strafeDir = (Math.random() < 0.5 ? 1 : -1);
                        }

                        const perpX = -dz / dist * ent.strafeDir;
                        const perpZ = dx / dist * ent.strafeDir;
                        let forwardFactor = 0;
                        if (dist > 12.5) forwardFactor = 0.55;
                        else if (dist < 6.0) forwardFactor = -0.85; // Back away to keep archery distance!

                        desiredVx = (perpX + (dx / dist) * forwardFactor) * ent.speed;
                        desiredVz = (perpZ + (dz / dist) * forwardFactor) * ent.speed;

                        // Shoot 3D physical arrow with ballistic trajectory!
                        if (ent.bowDrawTimer >= 1.35 && ent.attackCooldown <= 0) {
                            ent.bowDrawTimer = 0;
                            ent.attackCooldown = 1.8 + Math.random() * 0.9;
                            const arrowOrigin = ent.group.position.clone().add(new THREE.Vector3(0, 1.25, 0));
                            const arrowTarget = playerPos.clone().add(new THREE.Vector3(0, 0.45, 0));
                            this.arrowManager.shootArrow(arrowOrigin, arrowTarget, 'skeleton', 0.045);
                            app?.audio?.playSkeletonShoot?.();
                        }
                    } else {
                        // Player behind wall/cover: stow bow and navigate around obstacles
                        ent.isDrawingBow = false;
                        updatePathfinding(false, 2);
                    }
                } else if (ent.type === 'spider') {
                    ent.isDrawingBow = false;
                    // Spider AI: authentic pounce leap when in open clear view at 2.5 - 5.2 blocks
                    if (dist >= 2.5 && dist <= 5.2 && ent.onGround && ent.leapCooldown <= 0 && hasLos) {
                        ent.vel.y = 5.4;
                        ent.vel.x = (dx / dist) * 7.8;
                        ent.vel.z = (dz / dist) * 7.8;
                        ent.onGround = false;
                        ent.leapCooldown = 3.2;
                        app?.audio?.playMobHurt?.('hostile', 'spider');
                    } else {
                        // Pathfind with wall climbing capability (canClimb: true)
                        updatePathfinding(true, 1);
                    }
                } else {
                    // Zombie, Creeper, Enderman: 3D pathfinding towards player
                    ent.isDrawingBow = false;
                    const mobH = (ent.type === 'enderman' ? 3 : 2);
                    updatePathfinding(false, mobH);

                    // Enderman aggressive body shivering
                    if (ent.type === 'enderman') {
                        ent.group.position.x += (Math.random() - 0.5) * 0.035;
                        ent.group.position.z += (Math.random() - 0.5) * 0.035;
                    }
                }
            } else if (canAgro && dist <= 1.35 && ent.attackCooldown <= 0 && ent.type !== 'creeper') {
                // Melee attack hit & knockback
                ent.attackCooldown = 1.1;
                ent.attackSwing = 1.0;
                const dmg = (ent.type === 'enderman' ? 6 : (ent.type === 'spider' ? 2.5 : 3));
                survival.damage(dmg);
                app?.audio?.playAttackHit?.();

                // Apply authentic Minecraft player knockback
                if (app?.player?.velocity) {
                    const kbSpeed = (ent.type === 'enderman' ? 8.0 : 5.8);
                    const kx = (dx / Math.max(0.1, dist)) * kbSpeed;
                    const kz = (dz / Math.max(0.1, dist)) * kbSpeed;
                    app.player.velocity.x += kx;
                    app.player.velocity.z += kz;
                    app.player.velocity.y = Math.max(app.player.velocity.y, 3.8);
                }
            } else {
                // Idle wander when player is out of detection range, dead, or in Creative mode
                ent.isDrawingBow = false;
                ent.path = [];
                ent.wanderTimer -= dt;
                if (ent.wanderTimer <= 0) {
                    ent.wanderTimer = 3.0 + Math.random() * 4.0;
                    if (Math.random() < 0.55) {
                        ent.state = 'wander';
                        ent.targetX = ent.group.position.x + (Math.random() - 0.5) * 10;
                        ent.targetZ = ent.group.position.z + (Math.random() - 0.5) * 10;
                    } else {
                        ent.state = 'idle';
                    }
                }

                if (ent.state === 'wander') {
                    const tx = ent.targetX - ent.group.position.x;
                    const tz = ent.targetZ - ent.group.position.z;
                    const tdist = Math.hypot(tx, tz);
                    if (tdist > 0.4) {
                        desiredVx = (tx / tdist) * (ent.speed * 0.45);
                        desiredVz = (tz / tdist) * (ent.speed * 0.45);
                    } else {
                        ent.state = 'idle';
                    }
                }
            }

            // Authentic Minecraft mob physics step
            const canClimb = (ent.type === 'spider');
            const phys = updateMobMinecraftPhysics(
                this.world,
                ent.group.position,
                ent.vel,
                desiredVx,
                desiredVz,
                dt,
                ent.type,
                ent.bodyYaw,
                canClimb
            );
            const wasGround = ent.onGround;
            ent.onGround = phys.onGround;
            ent.inWater = phys.inWater;
            ent.isClimbing = !!phys.isClimbing;

            // Minecraft authentic fall damage for hostile mobs
            if (ent.inWater) {
                ent.fallStartY = ent.group.position.y;
            } else if (!ent.onGround) {
                if (ent.fallStartY === undefined || ent.group.position.y > ent.fallStartY) {
                    ent.fallStartY = ent.group.position.y;
                }
            } else if (ent.onGround && !wasGround) {
                if (ent.fallStartY !== undefined) {
                    const fallDist = ent.fallStartY - ent.group.position.y;
                    if (fallDist > 3.0) {
                        const fallDamage = Math.floor(fallDist - 3.0);
                        if (fallDamage > 0) {
                            this.damageEntityDirect(ent, ent.id, fallDamage);
                        }
                    }
                }
                ent.fallStartY = ent.group.position.y;
            }

            // Smooth body yaw turning towards motion or target
            const horizSpeed = Math.hypot(ent.vel.x, ent.vel.z);
            if (horizSpeed > 0.08) {
                const moveYaw = Math.atan2(ent.vel.x, ent.vel.z);
                const yawDiff = wrapAngle(moveYaw - ent.bodyYaw);
                const maxTurn = 8.5 * dt;
                ent.bodyYaw += Math.max(-maxTurn, Math.min(maxTurn, yawDiff));
            } else if (dist < trackingRange) {
                const facePlayerYaw = Math.atan2(dx, dz);
                const yawDiff = wrapAngle(facePlayerYaw - ent.bodyYaw);
                ent.bodyYaw += Math.max(-4.5 * dt, Math.min(4.5 * dt, yawDiff));
            }
            ent.group.rotation.y = ent.bodyYaw;

            // Smooth head tracking
            if (ent.head) {
                ent.headYaw = THREE.MathUtils.lerp(ent.headYaw || 0, targetHeadYaw, dt * 7.5);
                ent.headPitch = THREE.MathUtils.lerp(ent.headPitch || 0, targetHeadPitch, dt * 7.5);
                ent.head.rotation.y = ent.headYaw;
                ent.head.rotation.x = ent.headPitch;
            }

            // Authentic Minecraft damage tilt recovery
            if (ent.hurtTilt > 0) {
                ent.hurtTilt = Math.max(0, ent.hurtTilt - dt * 2.8);
                ent.group.rotation.z = Math.sin(ent.hurtTilt * Math.PI) * 0.24;
            } else {
                ent.group.rotation.z = 0;
            }

            // Limb swing calculations (scales smoothly with actual ground speed; returns to 0 at rest)
            const targetSwingAmount = Math.min(1.0, horizSpeed / (ent.baseSpeed || 1.8));
            ent.limbSwingAmount = THREE.MathUtils.lerp(ent.limbSwingAmount || 0, targetSwingAmount, dt * 9.0);
            ent.limbSwing = (ent.limbSwing || 0) + ent.limbSwingAmount * dt * 11.0;

            if (ent.type === 'spider' && ent.spiderLegs) {
                // When climbing vertical wall, tilt spider body upward!
                if (ent.isClimbing) {
                    ent.group.rotation.x = THREE.MathUtils.lerp(ent.group.rotation.x, -Math.PI / 3.2, dt * 10.0);
                    ent.limbSwing = (ent.limbSwing || 0) + dt * 18.0; // Rapid scuttling
                } else {
                    ent.group.rotation.x = THREE.MathUtils.lerp(ent.group.rotation.x, 0, dt * 8.0);
                }

                // Authentic Minecraft 8-legged spider gait (alternating diagonal pairs with ground lift)
                ent.spiderLegs.forEach((leg: THREE.Group, i: number) => {
                    const isLeft = (i % 2 === 0);
                    const pairIndex = Math.floor(i / 2);
                    const phase = (pairIndex % 2 === 0 ? 0 : Math.PI);
                    const xSwing = Math.sin(ent.limbSwing * 1.3 + phase) * 0.45 * ent.limbSwingAmount;
                    const zLift = Math.cos(ent.limbSwing * 1.3 + phase) * 0.16 * ent.limbSwingAmount;
                    leg.rotation.x = xSwing;
                    const baseZ = isLeft ? Math.PI / 3 : -Math.PI / 3;
                    leg.rotation.z = baseZ + (isLeft ? -zLift : zLift);
                });
            } else if (ent.type === 'creeper') {
                // Creeper 4-legged diagonal walking gait
                const crSwing = Math.sin(ent.limbSwing) * 0.62 * ent.limbSwingAmount;
                if (ent.legL) ent.legL.rotation.x = crSwing;
                if (ent.legR) ent.legR.rotation.x = -crSwing;
                if (ent.legL2) ent.legL2.rotation.x = -crSwing;
                if (ent.legR2) ent.legR2.rotation.x = crSwing;
            } else if (ent.type === 'skeleton') {
                // Skeleton bipedal swing + aiming bow pose
                const skSwing = Math.sin(ent.limbSwing) * 0.65 * ent.limbSwingAmount;
                if (ent.legL) ent.legL.rotation.x = skSwing;
                if (ent.legR) ent.legR.rotation.x = -skSwing;
                if (ent.isDrawingBow) {
                    // Authentic archery aiming pose: arms raised aiming towards target with bow draw
                    const drawPull = Math.min(1.0, (ent.bowDrawTimer || 0) / 1.2);
                    if (ent.armL) {
                        ent.armL.rotation.x = -1.55 - targetHeadPitch;
                        ent.armL.rotation.y = 0.22 - drawPull * 0.15;
                    }
                    if (ent.armR) {
                        ent.armR.rotation.x = -1.55 - targetHeadPitch;
                        ent.armR.rotation.y = -0.35 + drawPull * 0.25;
                    }
                } else {
                    if (ent.armL) { ent.armL.rotation.x = -1.45; ent.armL.rotation.y = 0.2; }
                    if (ent.armR) { ent.armR.rotation.x = -1.45; ent.armR.rotation.y = -0.2; }
                }
            } else if (ent.type === 'enderman') {
                // Enderman long slow strides
                const eSwing = Math.sin(ent.limbSwing * 0.7) * 0.7 * ent.limbSwingAmount;
                if (ent.legL) ent.legL.rotation.x = eSwing;
                if (ent.legR) ent.legR.rotation.x = -eSwing;
                if (ent.armL) ent.armL.rotation.x = -eSwing * 0.7;
                if (ent.armR) ent.armR.rotation.x = eSwing * 0.7;
            } else {
                // Zombie classic outstretched arms + bipedal stride + attack punch
                const zSwing = Math.sin(ent.limbSwing) * 0.65 * ent.limbSwingAmount;
                if (ent.legL) ent.legL.rotation.x = zSwing;
                if (ent.legR) ent.legR.rotation.x = -zSwing;
                const punch = (ent.attackSwing || 0) * 0.7;
                if (ent.armL) ent.armL.rotation.x = -1.50 - punch + Math.sin(ent.limbSwing * 0.5) * 0.08;
                if (ent.armR) ent.armR.rotation.x = -1.50 - punch - Math.sin(ent.limbSwing * 0.5) * 0.08;
                if (ent.head) ent.head.rotation.z = 0.08; // Iconic tilted zombie head
            }
        }
    }

    getRaycastTargets(): THREE.Mesh[] {
        const list: THREE.Mesh[] = [];
        for (const ent of this.entities.values()) {
            ent.group.traverse((obj: any) => {
                if (obj.isMesh) list.push(obj);
            });
        }
        return list;
    }

    damageEntityDirect(ent: any, id: string, amount = 1, attackerPos?: THREE.Vector3): boolean {
        ent.health -= amount;
        ent.flashTimer = 0.25;
        ent.hasBeenProvoked = true;
        const app = (window as any).app;

        // Authentic Minecraft knockback impulse & damage tilt
        ent.hurtTilt = 1.0;
        if (attackerPos) {
            const dx = ent.group.position.x - attackerPos.x;
            const dz = ent.group.position.z - attackerPos.z;
            const dist = Math.hypot(dx, dz) || 1;
            ent.vel.x = (dx / dist) * 7.5;
            ent.vel.z = (dz / dist) * 7.5;
            ent.vel.y = 4.8; // Vertical knockback pop
            ent.onGround = false;
        }

        // Enderman teleports away when damaged!
        if (ent.type === 'enderman' && ent.health > 0) {
            const angle = Math.random() * Math.PI * 2;
            const dist = 9 + Math.random() * 11;
            const tx = Math.floor(ent.group.position.x + Math.cos(angle) * dist);
            const tz = Math.floor(ent.group.position.z + Math.sin(angle) * dist);
            const ty = this.world.findSurfaceY(tx, tz);
            ent.group.position.set(tx + 0.5, ty + 1, tz + 0.5);
            ent.vel.set(0, 0, 0);
            app?.audio?.playEndermanTeleport?.();
        }

        if (ent.health <= 0) {
            // Drop authentic monster loot into world as spinning 3D items
            const dropPos = ent.group.position.clone();
            dropPos.y += 0.35;

            const spawnOrAdd = (kind: 'resource' | 'block', itemId: any, count: number) => {
                if (count <= 0) return;
                if (app?.droppedItemManager) {
                    app.droppedItemManager.spawn({ kind, id: itemId, count }, dropPos);
                } else if (app?.inventory) {
                    if (kind === 'resource') app.inventory.addResource(itemId, count);
                    else app.inventory.addBlock(itemId, count);
                }
            };

            if (ent.type === 'zombie') {
                if (Math.random() < 0.25) spawnOrAdd('resource', 'iron_ingot', 1);
                spawnOrAdd('resource', 'rotten_flesh', 1 + Math.floor(Math.random() * 2));
            } else if (ent.type === 'skeleton') {
                spawnOrAdd('resource', 'arrow', 1 + Math.floor(Math.random() * 2));
                spawnOrAdd('resource', 'bone', 1 + Math.floor(Math.random() * 2));
            } else if (ent.type === 'creeper') {
                spawnOrAdd('resource', 'gunpowder', 1 + Math.floor(Math.random() * 2));
            } else if (ent.type === 'spider') {
                spawnOrAdd('resource', 'string', 1 + Math.floor(Math.random() * 2));
                if (Math.random() < 0.5) spawnOrAdd('resource', 'spider_eye', 1);
            } else if (ent.type === 'enderman') {
                spawnOrAdd('resource', 'ender_pearl', 1);
            }

            app?.audio?.playMobDeath('hostile', ent.type);
            app?.particleKernel?.spawnDebris(ent.group.position.x, ent.group.position.y + 0.5, ent.group.position.z, 0xf0f0f0);
            this.scene.remove(ent.group);
            this.entities.delete(id);
        } else {
            app?.audio?.playMobHurt('hostile', ent.type);
        }
        return true;
    }

    applyDamageFromHit(hit: any, amount = 1, attackerPos?: THREE.Vector3): boolean {
        const id = hit?.object?.userData?.mobId;
        if (!id) return false;
        const ent = this.entities.get(id);
        if (!ent) return false;
        return this.damageEntityDirect(ent, id, amount, attackerPos);
    }

    clear() {
        for (const ent of this.entities.values()) {
            this.scene.remove(ent.group);
        }
        this.entities.clear();
        this.arrowManager?.clear();
    }

    getCount() { return this.entities.size; }
}
