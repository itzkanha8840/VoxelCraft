import * as THREE from 'three';
import { CONFIG, BLOCK_ID, PLAYER_SKINS, RESOURCE_DEFS, RESOURCE_ITEM, isDurabilityTool, getToolMaxDurability, TOOL_MAX_DURABILITY } from './constants';
import { VoxelWorld, MathKernel } from './world';
import { InventorySystem, SurvivalSystem, CraftingSystem, DroppedItemManager, OnlineSessionManager } from './systems';
import { FriendlyMobManager, HostileMobManager } from './mobs';
import { WindChargeManager } from './windCharge';
import { CloudGenerator, ParticleKernel, WeatherKernel, DayNightCycleKernel, TimeKernel, AudioProcessor, MinecraftLogicKernel } from './environment';
import { PlayerController } from './player';
import { setupCraftingTable } from './craftingTable';
import { executeCommand, getCommandSuggestions, COMMAND_LIST } from './commands';
import { AccountServerManager, ServerEntry, GoogleUser } from './accountServerManager';
import { VideoSettingsManager } from './videoSettings';

export { isDurabilityTool, getToolMaxDurability, TOOL_MAX_DURABILITY, ToolEnchantmentSystem, ENCHANTMENTS };

/**
 * Durability system for tools (pickaxes, axes, shovels).
 * Tracks tool wear per item, depletes on block mining, updates hotbar visual durability bar,
 * and triggers authentic break audio, particle effects, and inventory removal upon zero durability.
 */
export class ToolDurabilitySystem {
    app: VoxelApplication;

    constructor(app: VoxelApplication) {
        this.app = app;
    }

    isTool(itemId: any): boolean {
        return isDurabilityTool(itemId);
    }

    getMaxDurability(itemId: string): number {
        return getToolMaxDurability(itemId);
    }

    getHeldToolDurability(): { current: number; max: number; id: string; label: string } | null {
        const selected = this.app.inventory.getSelectedEntry();
        if (!selected || selected.kind !== 'resource' || !this.isTool(selected.id)) {
            return null;
        }
        const max = (selected as any).maxDurability ?? this.getMaxDurability(selected.id);
        const current = (selected as any).durability ?? max;
        const label = RESOURCE_DEFS[selected.id]?.label || selected.id;
        return { current, max, id: selected.id, label };
    }

    setHeldToolDurability(durability: number): boolean {
        const selected = this.app.inventory.getSelectedEntry();
        if (!selected || selected.kind !== 'resource' || !this.isTool(selected.id)) {
            return false;
        }
        const max = (selected as any).maxDurability ?? this.getMaxDurability(selected.id);
        (selected as any).maxDurability = max;
        (selected as any).durability = Math.max(0, Math.min(max, durability));

        if ((selected as any).durability <= 0) {
            this.breakTool(this.app.inventory.selected, selected.id);
        } else {
            this.app.inventory.render();
            this.app.inventory.updateSelectedName();
        }
        return true;
    }

    repairHeldTool(): boolean {
        const selected = this.app.inventory.getSelectedEntry();
        if (!selected || selected.kind !== 'resource' || !this.isTool(selected.id)) {
            return false;
        }
        const max = this.getMaxDurability(selected.id);
        (selected as any).maxDurability = max;
        (selected as any).durability = max;
        this.app.inventory.render();
        this.app.inventory.updateSelectedName();
        return true;
    }

    onBlockMined(blockId: number): void {
        if (this.app.survival.isCreative()) return;

        const slotIndex = this.app.inventory.selected;
        const slot = this.app.inventory.hotbar[slotIndex];
        if (!slot || slot.kind !== 'resource' || !this.isTool(slot.id)) return;

        // Check if Unbreaking enchantment negates durability loss!
        if (this.app.toolEnchantments?.shouldNegateDurabilityDamage(slot)) {
            this.app.toolEnchantments.notifyUnbreakingEffect(slot);
            return;
        }

        if ((slot as any).maxDurability === undefined) {
            (slot as any).maxDurability = this.getMaxDurability(slot.id);
        }
        if ((slot as any).durability === undefined) {
            (slot as any).durability = (slot as any).maxDurability;
        }

        this.damageTool(slotIndex, 1);
    }

    damageTool(slotIndex: number, amount = 1): boolean {
        const slot = this.app.inventory.hotbar[slotIndex];
        if (!slot || slot.kind !== 'resource' || !this.isTool(slot.id)) return false;

        if ((slot as any).maxDurability === undefined) {
            (slot as any).maxDurability = this.getMaxDurability(slot.id);
        }
        if ((slot as any).durability === undefined) {
            (slot as any).durability = (slot as any).maxDurability;
        }

        (slot as any).durability = Math.max(0, (slot as any).durability - amount);

        if ((slot as any).durability <= 0) {
            this.breakTool(slotIndex, slot.id);
            return true;
        } else {
            this.app.inventory.render();
            this.app.inventory.updateSelectedName();
            return false;
        }
    }

    breakTool(slotIndex: number, toolId: string): void {
        const toolLabel = RESOURCE_DEFS[toolId]?.label || toolId.replace(/_/g, ' ');
        const toolColorHex = RESOURCE_DEFS[toolId]?.color || '#ffffff';
        const toolColorNum = parseInt(toolColorHex.replace('#', ''), 16) || 0xcccccc;

        // 1. Clear hotbar slot
        this.app.inventory.hotbar[slotIndex] = null;

        // 2. Decrement inventory count
        const currentCount = this.app.inventory.getResourceCount(toolId);
        this.app.inventory.setCount('resource', toolId, Math.max(0, currentCount - 1));

        // 3. Reset mining state in player controller if active
        if (this.app.player.breakState.active) {
            this.app.player.breakState.active = false;
            this.app.player.breakState.progress = 0;
            this.app.world.hideBreakOverlay();
        }

        // 4. Play authentic tool break crack & snap sound
        this.app.audio?.playToolBreak?.();

        // 5. Spawn fragment burst particles in front of player
        const cam = this.app.camera;
        const dir = new THREE.Vector3();
        cam.getWorldDirection(dir);
        const particlePos = cam.position.clone().add(dir.clone().multiplyScalar(1.1));
        this.app.particleKernel?.spawnToolBreak(particlePos.x, particlePos.y, particlePos.z, toolColorNum);

        // 6. Push chat and HUD notification
        this.app.pushChatLine('System', `§cYour ${toolLabel} broke!`, 'system');
        this.app.showHelpTipFor(`Your ${toolLabel} broke!`, 3000);

        // 7. Refresh inventory display
        this.app.inventory.render();
        this.app.inventory.updateSelectedName();
    }
}

export interface EnchantmentDef {
    id: string;
    name: string;
    description: string;
    maxLevel: number;
    color: string;
    abbreviation: string;
}

export const ENCHANTMENTS: Record<string, EnchantmentDef> = {
    efficiency: {
        id: 'efficiency',
        name: 'Efficiency',
        description: 'Increases tool mining speed significantly',
        maxLevel: 5,
        color: '#55ffff',
        abbreviation: 'Eff'
    },
    unbreaking: {
        id: 'unbreaking',
        name: 'Unbreaking',
        description: 'Gives a chance to avoid durability loss when mining',
        maxLevel: 3,
        color: '#ffaa00',
        abbreviation: 'Unb'
    },
    fortune: {
        id: 'fortune',
        name: 'Fortune',
        description: 'Increases drops from mined ores',
        maxLevel: 3,
        color: '#ffff55',
        abbreviation: 'Fort'
    },
    silk_touch: {
        id: 'silk_touch',
        name: 'Silk Touch',
        description: 'Mined blocks drop themselves directly',
        maxLevel: 1,
        color: '#55ff55',
        abbreviation: 'Silk'
    },
    sharpness: {
        id: 'sharpness',
        name: 'Sharpness',
        description: 'Increases melee attack damage',
        maxLevel: 5,
        color: '#ff5555',
        abbreviation: 'Shp'
    }
};

/**
 * Enchantment system for tools (pickaxes, axes, shovels, weapons).
 * Manages item modifiers like Efficiency (accelerated block break speed)
 * and Unbreaking (durability loss reduction).
 */
export class ToolEnchantmentSystem {
    app: VoxelApplication;

    constructor(app: VoxelApplication) {
        this.app = app;
    }

    isEnchantable(itemId: any): boolean {
        if (!itemId || typeof itemId !== 'string') return false;
        const id = itemId.toLowerCase();
        return isDurabilityTool(id) || id.includes('sword') || id.includes('mace') || id.includes('spear') || id.includes('trident');
    }

    getEnchantments(slot: any): Record<string, number> {
        if (!slot || typeof slot !== 'object') return {};
        return slot.enchantments || {};
    }

    getEnchantmentLevel(slot: any, enchName: string): number {
        if (!slot || !slot.enchantments) return 0;
        const key = enchName.toLowerCase();
        for (const [k, v] of Object.entries(slot.enchantments)) {
            if (k.toLowerCase() === key) {
                return typeof v === 'number' ? v : 0;
            }
        }
        return 0;
    }

    setEnchantment(slot: any, enchName: string, level: number): boolean {
        if (!slot || slot.kind !== 'resource') return false;
        if (!slot.enchantments) {
            slot.enchantments = {};
        }
        const normalized = enchName.toLowerCase() === 'efficiency' ? 'Efficiency' :
                           enchName.toLowerCase() === 'unbreaking' ? 'Unbreaking' :
                           enchName.toLowerCase() === 'fortune' ? 'Fortune' :
                           enchName.toLowerCase() === 'silk_touch' ? 'Silk Touch' :
                           enchName.toLowerCase() === 'sharpness' ? 'Sharpness' :
                           enchName.charAt(0).toUpperCase() + enchName.slice(1);
        if (level <= 0) {
            delete slot.enchantments[normalized];
            delete slot.enchantments[enchName.toLowerCase()];
        } else {
            slot.enchantments[normalized] = level;
        }
        return true;
    }

    enchantHeldTool(enchName: string, level: number): { success: boolean; message: string } {
        const selected = this.app.inventory.getSelectedEntry();
        if (!selected || selected.kind !== 'resource' || !this.isEnchantable(selected.id)) {
            return { success: false, message: 'Hold a tool (pickaxe, axe, shovel, sword) in hand to enchant it.' };
        }

        const validName = enchName.toLowerCase();
        let targetName = 'Efficiency';
        let maxLvl = 5;

        if (validName.startsWith('eff')) {
            targetName = 'Efficiency';
            maxLvl = 5;
        } else if (validName.startsWith('unb')) {
            targetName = 'Unbreaking';
            maxLvl = 3;
        } else if (validName.startsWith('fort')) {
            targetName = 'Fortune';
            maxLvl = 3;
        } else if (validName.startsWith('silk')) {
            targetName = 'Silk Touch';
            maxLvl = 1;
        } else if (validName.startsWith('sharp')) {
            targetName = 'Sharpness';
            maxLvl = 5;
        } else {
            return { success: false, message: `Unknown enchantment "${enchName}". Supported: Efficiency, Unbreaking, Fortune, Silk Touch, Sharpness` };
        }

        const finalLevel = Math.max(1, Math.min(maxLvl, level || 1));
        this.setEnchantment(selected, targetName, finalLevel);

        if ((selected as any).maxDurability === undefined) {
            (selected as any).maxDurability = getToolMaxDurability(selected.id);
        }
        if ((selected as any).durability === undefined) {
            (selected as any).durability = (selected as any).maxDurability;
        }

        // Enchanting chime tone and purple spark particles
        this.app.audio?.playTone?.(580, 880, 0.22);
        const cam = this.app.camera;
        if (cam) {
            const dir = new THREE.Vector3();
            cam.getWorldDirection(dir);
            const p = cam.position.clone().add(dir.clone().multiplyScalar(1.2));
            this.app.particleKernel?.spawnDebris(p.x, p.y, p.z, 0xbb86fc);
        }

        const roman = this.toRoman(finalLevel);
        const toolLabel = RESOURCE_DEFS[selected.id]?.label || selected.id;
        const msg = `Enchanted ${toolLabel} with ${targetName} ${roman}!`;

        this.app.inventory.render();
        this.app.inventory.updateSelectedName();
        this.app.showHelpTipFor(msg, 3000);
        return { success: true, message: msg };
    }

    clearHeldToolEnchantments(): { success: boolean; message: string } {
        const selected = this.app.inventory.getSelectedEntry();
        if (!selected || selected.kind !== 'resource') {
            return { success: false, message: 'You are not holding an item.' };
        }
        delete (selected as any).enchantments;
        this.app.inventory.render();
        this.app.inventory.updateSelectedName();
        return { success: true, message: 'Removed all enchantments from held item.' };
    }

    getMiningSpeedMultiplier(slot: any): number {
        const eff = this.getEnchantmentLevel(slot, 'efficiency');
        if (eff <= 0) return 1.0;
        // In Minecraft: Efficiency significantly increases tool speed
        // Level 1: 1.55x, Level 2: 2.1x, Level 3: 2.65x, Level 4: 3.2x, Level 5: 3.75x
        return 1.0 + (eff * 0.55);
    }

    shouldNegateDurabilityDamage(slot: any): boolean {
        const unb = this.getEnchantmentLevel(slot, 'unbreaking');
        if (unb <= 0) return false;
        // Minecraft mechanics: Chance of tool taking durability damage is 1 / (unbreakingLevel + 1)
        // Level 1: 50% damage reduction
        // Level 2: 66.7% damage reduction
        // Level 3: 75% damage reduction
        const chanceOfDamage = 1.0 / (unb + 1);
        return Math.random() >= chanceOfDamage;
    }

    notifyUnbreakingEffect(slot: any): void {
        const cam = this.app.camera;
        if (cam) {
            const dir = new THREE.Vector3();
            cam.getWorldDirection(dir);
            const p = cam.position.clone().add(dir.clone().multiplyScalar(1.2));
            this.app.particleKernel?.spawnDebris(p.x, p.y, p.z, 0xbb86fc);
        }
        this.app.audio?.playTone?.(560, 720, 0.05);
    }

    toRoman(num: number): string {
        const romans = ['', 'I', 'II', 'III', 'IV', 'V'];
        return romans[num] || String(num);
    }

    getEnchantmentSummary(slot: any): string {
        const enchs = this.getEnchantments(slot);
        const entries = Object.entries(enchs).filter(([_, lvl]) => (lvl as number) > 0);
        if (entries.length === 0) return '';
        return entries.map(([name, lvl]) => `${name} ${this.toRoman(lvl as number)}`).join(', ');
    }
}

export class VoxelApplication {
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    world: VoxelWorld;
    inventory: InventorySystem;
    survival: SurvivalSystem;
    crafting: CraftingSystem;
    toolDurability: ToolDurabilitySystem;
    toolEnchantments: ToolEnchantmentSystem;
    audio: AudioProcessor;
    droppedItemManager: DroppedItemManager;
    onlineSession: OnlineSessionManager;
    player: PlayerController;
    cloudGenerator: CloudGenerator;
    weatherKernel: WeatherKernel;
    particleKernel: ParticleKernel;
    dayNightCycle: DayNightCycleKernel;
    timeKernel: TimeKernel;
    friendlyMobManager: FriendlyMobManager;
    hostileMobManager: HostileMobManager;
    windChargeManager: WindChargeManager;
    minecraftLogic: MinecraftLogicKernel;
    accountManager: AccountServerManager;
    videoSettings: VideoSettingsManager;
    ambientLight!: THREE.AmbientLight;
    sunLight!: THREE.DirectionalLight;
    moonLight!: THREE.DirectionalLight;
    hemisphereLight!: THREE.HemisphereLight;
    clock = new THREE.Clock();

    gameStarted = false;
    startingWorld = false;
    currentDaylight = 1.0;
    dimension = 'overworld';
    selectedSkinId = PLAYER_SKINS[0].id;
    activeSessionMode = 'world';

    chatHistory: string[] = [];
    chatHistoryIndex = -1;
    debugTimer = 0;

    constructor() {
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(CONFIG.FOVY, window.innerWidth / window.innerHeight, CONFIG.NEAR, CONFIG.FAR);
        this.scene.add(this.camera);

        this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, CONFIG.MAX_PIXEL_RATIO));
        this.renderer.setClearColor(0x87ceeb);
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        this.renderer.shadowMap.enabled = false;
        document.body.appendChild(this.renderer.domElement);

        this.world = new VoxelWorld(this.scene);
        this.inventory = new InventorySystem();
        this.survival = new SurvivalSystem();
        this.inventory.setSurvivalSystem(this.survival);
        this.survival.setInventorySystem(this.inventory);
        this.audio = new AudioProcessor();
        this.droppedItemManager = new DroppedItemManager(this.scene, this.world, this.inventory, this.audio);
        this.onlineSession = new OnlineSessionManager(this.scene, this.world);
        this.crafting = new CraftingSystem(this.inventory, this.survival);
        this.toolDurability = new ToolDurabilitySystem(this);
        this.toolEnchantments = new ToolEnchantmentSystem(this);

        this.accountManager = new AccountServerManager();

        this.player = new PlayerController(this.camera, this.world, this.scene, this.inventory, this.survival, this.droppedItemManager, this.audio);
        this.player.setOnlineSession(this.onlineSession);
        this.player.setToolDurability(this.toolDurability);
        this.player.setToolEnchantments(this.toolEnchantments);

        this.cloudGenerator = new CloudGenerator(this.scene);
        this.weatherKernel = new WeatherKernel(this.scene);
        this.particleKernel = new ParticleKernel(this.scene);
        this.dayNightCycle = new DayNightCycleKernel(this.scene, this.renderer);
        this.timeKernel = new TimeKernel();
        this.friendlyMobManager = new FriendlyMobManager(this.scene, this.world);
        this.hostileMobManager = new HostileMobManager(this.scene, this.world);
        this.windChargeManager = new WindChargeManager(this.scene);
        this.minecraftLogic = new MinecraftLogicKernel(this.world);
        this.player.setMobManagers(this.friendlyMobManager, this.hostileMobManager);
        this.player.setWindChargeManager(this.windChargeManager);
        this.player.setParticleKernel(this.particleKernel);

        this.setupLighting();
        this.videoSettings = new VideoSettingsManager();
        this.videoSettings.setApp(this);
        this.setupMenuUI();
        this.setupEnchantmentUI();
        this.handleResize();

        (window as any).app = this;
        setupCraftingTable(this);
    }

    setupLighting() {
        const ambient = new THREE.AmbientLight(0xffffff, 0.65);
        this.scene.add(ambient);
        this.ambientLight = ambient;

        const hemi = new THREE.HemisphereLight(0x78abff, 0x385522, 0.35);
        this.scene.add(hemi);
        this.hemisphereLight = hemi;

        this.sunLight = new THREE.DirectionalLight(0xffffff, 0.90);
        this.sunLight.position.set(80, 150, 40);
        this.sunLight.castShadow = false;
        this.scene.add(this.sunLight);

        this.moonLight = new THREE.DirectionalLight(0x90b2ff, 0.25);
        this.moonLight.position.set(-80, 150, -40);
        this.moonLight.castShadow = false;
        this.moonLight.visible = false;
        this.scene.add(this.moonLight);

        this.scene.fog = new THREE.Fog(0x87ceeb, 95, 260);
        this.scene.background = new THREE.Color(0x87ceeb);
    }

    showHelpTipFor(text: string, durationMs = 3000) {
        const helpTip = document.getElementById('help-tip');
        if (!helpTip) return;
        helpTip.innerText = text;
        helpTip.style.display = 'block';
        helpTip.style.opacity = '1';
        setTimeout(() => {
            helpTip.style.opacity = '0';
            setTimeout(() => { helpTip.style.display = 'none'; }, 300);
        }, durationMs);
    }

    pushChatLine(sender: string, text: string, kind = 'chat') {
        const log = document.getElementById('chat-log');
        if (!log) return;
        const line = document.createElement('div');
        line.className = `chat-line ${kind}`;

        const COLOR_MAP: Record<string, string> = {
            '0': '#000000', '1': '#0000aa', '2': '#00aa00', '3': '#00aaaa',
            '4': '#aa0000', '5': '#aa00aa', '6': '#ffaa00', '7': '#aaaaaa',
            '8': '#555555', '9': '#5555ff', 'a': '#55ff55', 'b': '#55ffff',
            'c': '#ff5555', 'd': '#ff55ff', 'e': '#ffff55', 'f': '#ffffff'
        };

        const formatColors = (raw: string) => {
            const escaped = raw
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            return escaped.replace(/(?:§|&amp;)([0-9a-fklmnor])/gi, (_, code) => {
                const c = code.toLowerCase();
                if (COLOR_MAP[c]) {
                    return `</span><span style="color:${COLOR_MAP[c]}">`;
                } else if (c === 'l') {
                    return `</span><span style="font-weight:bold">`;
                } else if (c === 'r') {
                    return `</span><span style="color:#ffffff">`;
                }
                return '';
            });
        };

        if (kind === 'chat') {
            line.innerHTML = `<span style="color:#ffff55">&lt;${formatColors(sender)}&gt;</span> <span>${formatColors(text)}</span>`;
        } else {
            line.innerHTML = `<span>${formatColors(text)}</span>`;
        }

        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
        this.audio?.playChatMessage();
    }

    logChat(text: string, kind = 'system') {
        this.pushChatLine('System', text, kind);
    }

    setupMenuUI() {
        const startBtn = document.getElementById('btn-start');
        const skinsBtn = document.getElementById('btn-skins');
        const customBtn = document.getElementById('btn-custom');
        const settingsBtn = document.getElementById('btn-settings');
        const accountsBtn = document.getElementById('btn-accounts');
        const playMenu = document.getElementById('play-menu');
        const playBackBtn = document.getElementById('btn-play-back');
        const playContinueBtn = document.getElementById('btn-play-continue');
        const createWorldBtn = document.getElementById('btn-create-world');
        const mainMenu = document.getElementById('main-menu');
        const skinsMenu = document.getElementById('skins-menu');
        const customMenu = document.getElementById('custom-menu');
        const settingsMenu = document.getElementById('settings-menu');
        const accountsMenu = document.getElementById('accounts-menu');

        // Death Menu buttons
        const deathMenu = document.getElementById('death-menu');
        const deathRespawnBtn = document.getElementById('btn-death-respawn');
        const deathMainMenuBtn = document.getElementById('btn-death-mainmenu');

        deathRespawnBtn?.addEventListener('click', () => {
            if (this.survival.isHardcore()) {
                // In Hardcore mode, player cannot respawn with items; they spectate the world
                this.survival.setGameMode('Creative');
                this.inventory.setCreativeMode(true);
                this.player.isFlying = true;
                if (deathMenu) deathMenu.style.display = 'none';
                this.player.controls.lock();
                this.showHelpTipFor('Spectating Hardcore World as Ghost', 3500);
            } else {
                const respawnPos = this.world.findSafeSpawnSurface(0, 0);
                this.camera.position.set(respawnPos.x + 0.5, respawnPos.y + 2.62, respawnPos.z + 0.5);
                this.player.velocity.set(0, 0, 0);
                this.survival.resetForRespawn();
                if (deathMenu) deathMenu.style.display = 'none';
                this.player.controls.lock();
                this.showHelpTipFor('Respawned at world surface!', 3000);
            }
        });

        deathMainMenuBtn?.addEventListener('click', () => {
            if (deathMenu) deathMenu.style.display = 'none';
            const mainMenu = document.getElementById('main-menu');
            if (mainMenu) mainMenu.style.display = 'flex';
            this.gameStarted = false;
        });

        startBtn?.addEventListener('click', () => {
            if (mainMenu) mainMenu.style.display = 'none';
            if (playMenu) playMenu.style.display = 'flex';
        });

        playBackBtn?.addEventListener('click', () => {
            if (playMenu) playMenu.style.display = 'none';
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        playContinueBtn?.addEventListener('click', () => {
            this.startWorld();
        });

        createWorldBtn?.addEventListener('click', () => {
            this.startWorld();
        });

        skinsBtn?.addEventListener('click', () => {
            if (mainMenu) mainMenu.style.display = 'none';
            if (skinsMenu) skinsMenu.style.display = 'flex';
        });

        document.getElementById('btn-skins-back')?.addEventListener('click', () => {
            if (skinsMenu) skinsMenu.style.display = 'none';
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        customBtn?.addEventListener('click', () => {
            if (mainMenu) mainMenu.style.display = 'none';
            if (customMenu) customMenu.style.display = 'flex';
        });

        document.getElementById('btn-custom-back')?.addEventListener('click', () => {
            if (customMenu) customMenu.style.display = 'none';
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        settingsBtn?.addEventListener('click', () => {
            this.videoSettings.openSettingsUI();
        });

        document.getElementById('btn-settings-back')?.addEventListener('click', () => {
            if (settingsMenu) settingsMenu.style.display = 'none';
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        accountsBtn?.addEventListener('click', () => {
            if (mainMenu) mainMenu.style.display = 'none';
            if (accountsMenu) accountsMenu.style.display = 'flex';
        });

        document.getElementById('btn-accounts-back')?.addEventListener('click', () => {
            if (accountsMenu) accountsMenu.style.display = 'none';
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        // Setup Google Auth & Server Manager
        this.accountManager.setup((server, user) => {
            this.startWorld(server, user);
        });

        // Chat Enter, Slash, Suggestions, & Tab/History handlers
        const chatInput = document.getElementById('chat-input') as HTMLInputElement;
        const chatWrap = document.getElementById('chat-input-wrap');
        const chatSuggestions = document.getElementById('chat-suggestions');

        const updateSuggestions = () => {
            if (!chatSuggestions || !chatInput) return;
            const val = chatInput.value;
            if (val.startsWith('/')) {
                const suggs = getCommandSuggestions(val);
                if (suggs.length > 0) {
                    chatSuggestions.innerHTML = '';
                    chatSuggestions.style.display = 'flex';
                    suggs.slice(0, 7).forEach((s, idx) => {
                        const item = document.createElement('div');
                        item.className = `chat-sugg-item ${idx === 0 ? 'selected' : ''}`;
                        item.innerHTML = `<span class="chat-sugg-syntax">${s.syntax}</span><span class="chat-sugg-desc">${s.desc}</span>`;
                        item.addEventListener('mousedown', (ev) => {
                            ev.preventDefault();
                            chatInput.value = s.cmd + ' ';
                            chatInput.focus();
                            updateSuggestions();
                        });
                        chatSuggestions.appendChild(item);
                    });
                    return;
                }
            }
            chatSuggestions.style.display = 'none';
        };

        chatInput?.addEventListener('input', updateSuggestions);

        document.addEventListener('keydown', (e) => {
            if ((e.code === 'KeyT' || e.code === 'Slash') && this.gameStarted) {
                const activeEl = document.activeElement;
                if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) return;
                e.preventDefault();
                this.player.controls.unlock();
                if (chatWrap) chatWrap.style.display = 'flex';
                if (chatInput) {
                    chatInput.value = e.code === 'Slash' ? '/' : '';
                    chatInput.focus();
                    updateSuggestions();
                }
            }
        });

        chatInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const val = chatInput.value.trim();
                if (val) {
                    this.chatHistory.push(val);
                    this.chatHistoryIndex = this.chatHistory.length;
                    if (val.startsWith('/')) {
                        const res = executeCommand(val, {
                            app: this,
                            survival: this.survival,
                            inventory: this.inventory,
                            player: this.player,
                            world: this.world
                        });
                        if (res.message) {
                            this.pushChatLine('System', res.message, res.success ? 'command' : 'system');
                        }
                    } else {
                        const pName = this.accountManager.getEffectiveUsername();
                        this.pushChatLine(pName, val);
                    }
                    chatInput.value = '';
                }
                if (chatSuggestions) chatSuggestions.style.display = 'none';
                if (chatWrap) chatWrap.style.display = 'none';
                this.player.controls.lock();
            } else if (e.key === 'Tab') {
                e.preventDefault();
                const val = chatInput.value;
                if (val.startsWith('/')) {
                    const suggs = getCommandSuggestions(val);
                    if (suggs.length > 0) {
                        chatInput.value = suggs[0].cmd + ' ';
                        updateSuggestions();
                    }
                }
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                if (this.chatHistory.length > 0 && this.chatHistoryIndex > 0) {
                    this.chatHistoryIndex--;
                    chatInput.value = this.chatHistory[this.chatHistoryIndex];
                    updateSuggestions();
                }
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                if (this.chatHistoryIndex < this.chatHistory.length - 1) {
                    this.chatHistoryIndex++;
                    chatInput.value = this.chatHistory[this.chatHistoryIndex];
                    updateSuggestions();
                } else {
                    this.chatHistoryIndex = this.chatHistory.length;
                    chatInput.value = '';
                    updateSuggestions();
                }
            } else if (e.key === 'Escape') {
                if (chatSuggestions) chatSuggestions.style.display = 'none';
                if (chatWrap) chatWrap.style.display = 'none';
                this.player.controls.lock();
            }
        });

        // Pause Menu & In-Game Video Settings Handler
        const pauseMenu = document.getElementById('pause-menu');
        const resumeBtn = document.getElementById('btn-resume');
        const pauseSettingsBtn = document.getElementById('btn-pause-settings');
        const pauseMainMenuBtn = document.getElementById('btn-pause-mainmenu');
        const deathSettingsBtn = document.getElementById('btn-death-settings');

        resumeBtn?.addEventListener('click', () => {
            if (pauseMenu) pauseMenu.style.display = 'none';
            this.player.controls.lock();
        });

        pauseSettingsBtn?.addEventListener('click', () => {
            if (pauseMenu) pauseMenu.style.display = 'none';
            this.videoSettings.openSettingsUI(true);
        });

        deathSettingsBtn?.addEventListener('click', () => {
            this.videoSettings.openSettingsUI(false);
        });

        pauseMainMenuBtn?.addEventListener('click', () => {
            if (pauseMenu) pauseMenu.style.display = 'none';
            this.gameStarted = false;
            this.player.controls.unlock();
            if (mainMenu) mainMenu.style.display = 'flex';
        });

        // PointerLock events - DO NOT show pause menu on unlock. Pause menu ONLY opens on ESC!
        this.player.controls.addEventListener('unlock', () => {
            // Intentionally empty: pause menu is strictly triggered by ESC key
        });

        this.player.controls.addEventListener('lock', () => {
            if (pauseMenu) pauseMenu.style.display = 'none';
            if (this.videoSettings.isSettingsOpen()) {
                this.videoSettings.closeSettingsUI(false);
            }
        });

        // Clicking the 3D canvas locks the pointer when playing and no menus/dialogs are open
        this.renderer.domElement.addEventListener('click', () => {
            if (!this.gameStarted) return;
            const chatWrapEl = document.getElementById('chat-input-wrap');
            const deathMenuEl = document.getElementById('death-menu');
            const craftOverlay = document.getElementById('mc-craft-overlay');

            const isChatOpen = chatWrapEl && chatWrapEl.style.display === 'flex';
            const isInvOpen = this.inventory.isExpandedVisible();
            const isCraftOpen = craftOverlay && craftOverlay.style.display === 'flex';
            const isDeathOpen = deathMenuEl && deathMenuEl.style.display === 'flex';
            const isVideoOpen = this.videoSettings.isSettingsOpen();
            const isPauseOpen = pauseMenu && pauseMenu.style.display === 'flex';

            if (!isChatOpen && !isInvOpen && !isCraftOpen && !isDeathOpen && !isVideoOpen && !isPauseOpen) {
                this.player.controls.lock();
            }
        });

        // Global ESC key listener - Pause Menu and Video Settings ONLY open/close when ESC is pressed!
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Escape') {
                if (!this.gameStarted) return;

                // 1. If Video Settings is open, close it (returning to pause menu if it was opened from pause)
                if (this.videoSettings.isSettingsOpen()) {
                    e.preventDefault();
                    this.videoSettings.closeSettingsUI(this.videoSettings.wasOpenedFromPause());
                    return;
                }

                // 2. If 3x3 Crafting Table modal is open, close it and lock controls
                const craftOverlay = document.getElementById('mc-craft-overlay');
                if (craftOverlay && craftOverlay.style.display === 'flex') {
                    e.preventDefault();
                    craftOverlay.style.display = 'none';
                    this.player.controls.lock();
                    return;
                }

                // 3. If Inventory panel is open, close it and lock controls
                const enchModal = document.getElementById('enchantment-modal');
                if (enchModal && enchModal.classList.contains('open')) {
                    e.preventDefault();
                    enchModal.classList.remove('open');
                    return;
                }

                if (this.inventory.isExpandedVisible()) {
                    e.preventDefault();
                    this.inventory.hideExpanded();
                    this.player.controls.lock();
                    return;
                }

                // 4. If Chat is open, close it and lock controls
                const chatWrapEl = document.getElementById('chat-input-wrap');
                if (chatWrapEl && chatWrapEl.style.display === 'flex') {
                    e.preventDefault();
                    chatWrapEl.style.display = 'none';
                    const chatSuggestions = document.getElementById('chat-suggestions');
                    if (chatSuggestions) chatSuggestions.style.display = 'none';
                    this.player.controls.lock();
                    return;
                }

                // 5. If Death menu is open, ESC does nothing
                const deathMenuEl = document.getElementById('death-menu');
                if (deathMenuEl && deathMenuEl.style.display === 'flex') {
                    return;
                }

                // 6. If Pause menu is already open, pressing ESC acts as RESUME
                if (pauseMenu && pauseMenu.style.display === 'flex') {
                    e.preventDefault();
                    pauseMenu.style.display = 'none';
                    this.player.controls.lock();
                    return;
                }

                // 7. Strictly when ESC is pressed during gameplay, open the Pause Menu
                if (pauseMenu) {
                    e.preventDefault();
                    pauseMenu.style.display = 'flex';
                    this.player.controls.unlock();
                }
            }
        });
    }

    async startWorld(serverEntry?: ServerEntry, googleUser?: GoogleUser) {
        if (this.gameStarted || this.startingWorld) return;
        this.startingWorld = true;

        const loadingScreen = document.getElementById('loading-screen');
        const playMenu = document.getElementById('play-menu');
        const mainMenu = document.getElementById('main-menu');
        const pauseMenu = document.getElementById('pause-menu');
        const bar = document.getElementById('progress-fill');
        const status = document.getElementById('loading-status');

        if (pauseMenu) pauseMenu.style.display = 'none';

        // Configure game mode from menu selection
        const modeSelect = document.getElementById('new-world-type') as HTMLSelectElement;
        const selectedMode = modeSelect ? modeSelect.value : 'Survival';

        if (selectedMode === 'Creative') {
            this.survival.setGameMode('Creative');
            this.inventory.setCreativeMode(true);
        } else if (selectedMode === 'Hardcore') {
            this.survival.setGameMode('Hardcore');
            this.inventory.setCreativeMode(false);
            this.inventory.clearAll();
        } else {
            this.survival.setGameMode('Survival');
            this.inventory.setCreativeMode(false);
            this.inventory.clearAll();
        }

        if (playMenu) playMenu.style.display = 'none';
        if (mainMenu) mainMenu.style.display = 'none';
        if (loadingScreen) loadingScreen.style.display = 'flex';

        // Preload center chunks
        const radius = 2;
        let total = (radius * 2 + 1) ** 2;
        let done = 0;

        for (let x = -radius; x <= radius; x++) {
            for (let z = -radius; z <= radius; z++) {
                this.world.generateChunk(x, z, true);
                done++;
                if (bar) bar.style.width = `${(done / total) * 100}%`;
                if (status) status.innerText = `Loading Chunk ${x}, ${z}...`;
                await new Promise((r) => setTimeout(r, 10));
            }
        }

        const safeSpawn = this.world.findSafeSpawnSurface(0, 0);
        this.camera.position.set(safeSpawn.x + 0.5, safeSpawn.y + 2.62, safeSpawn.z + 0.5);

        // Spawn initial villagers and iron golem near spawn so player can trade immediately!
        this.friendlyMobManager.spawnInitialVillagers(this.camera.position);

        if (loadingScreen) loadingScreen.style.display = 'none';
        if (pauseMenu) pauseMenu.style.display = 'none';
        this.gameStarted = true;
        this.startingWorld = false;

        this.player.controls.lock();
        this.startLoop();

        if (serverEntry) {
            this.activeSessionMode = 'server';
            const username = googleUser?.name || this.accountManager.getEffectiveUsername();
            this.pushChatLine('Server', `§aConnected to §6${serverEntry.name} §a[${serverEntry.address}]!`, 'system');
            this.pushChatLine('Server', `§bAuthenticated with Google: §e${googleUser?.email || 'Verified'}. Welcome §f${username}!`, 'system');
            this.pushChatLine('Server', `§eMotD: ${serverEntry.motd}`, 'system');
            this.pushChatLine('Server', `§7Ping: ${serverEntry.ping}ms • Players online: ${serverEntry.players + 1}/${serverEntry.maxPlayers}`, 'system');
            this.showHelpTipFor(`Joined server: ${serverEntry.name}`, 4000);
        } else {
            this.activeSessionMode = 'singleplayer';
            this.pushChatLine('System', '§eEntered Singleplayer World (Offline Mode).', 'system');
            this.pushChatLine('System', '§7No Google account required for singleplayer. Have fun!', 'system');
            this.showHelpTipFor('Press "E" for Inventory, "T" or "/" for Chat & Commands, WASD to Move', 6000);
        }
    }

    handleResize() {
        window.addEventListener('resize', () => {
            this.camera.aspect = window.innerWidth / window.innerHeight;
            this.camera.updateProjectionMatrix();
            this.renderer.setSize(window.innerWidth, window.innerHeight);
        });
    }

    updateAtmosphericFog(dt: number) {
        if (!this.scene.fog || !(this.scene.fog instanceof THREE.Fog)) return;

        const eyeX = Math.floor(this.camera.position.x);
        const eyeY = Math.floor(this.camera.position.y);
        const eyeZ = Math.floor(this.camera.position.z);
        const eyeVoxel = this.world.getVoxel(eyeX, eyeY, eyeZ);

        const rChunks = this.videoSettings?.settings?.renderDistance || this.world.renderDistance || 4;
        const maxBlockDist = rChunks * CONFIG.CHUNK_SIZE;

        let targetFogColor: THREE.Color;
        let targetNear: number;
        let targetFar: number;

        const underwaterOverlay = document.getElementById('underwater-overlay');

        if (eyeVoxel === BLOCK_ID.WATER) {
            // Authentic Minecraft underwater fog: deep aquatic tint, short visibility
            targetFogColor = new THREE.Color(0x13386e);
            targetNear = 1.0;
            targetFar = Math.min(22, maxBlockDist * 0.45);
            if (underwaterOverlay) underwaterOverlay.style.opacity = '1';
        } else if (eyeVoxel === BLOCK_ID.LAVA) {
            // Dense fiery lava fog
            targetFogColor = new THREE.Color(0xd4380d);
            targetNear = 0.4;
            targetFar = 4.0;
            if (underwaterOverlay) underwaterOverlay.style.opacity = '0';
        } else if (this.dimension === 'nether' || this.camera.position.y < -35) {
            // Nether atmosphere: dark crimson foggy haze
            targetFogColor = new THREE.Color(0x380b0b);
            targetNear = 12;
            targetFar = Math.max(28, maxBlockDist * 0.72);
            if (underwaterOverlay) underwaterOverlay.style.opacity = '0';
        } else {
            // Overworld: authentic Minecraft distance fog fading chunk boundary
            targetFogColor = (this.scene.background instanceof THREE.Color) ? this.scene.background : new THREE.Color(0x78a7ff);
            targetNear = Math.max(16, maxBlockDist * 0.60);
            targetFar = Math.max(36, maxBlockDist * 0.96);
            if (underwaterOverlay) underwaterOverlay.style.opacity = '0';
        }

        this.scene.fog.color.lerp(targetFogColor, Math.min(1.0, dt * 6.0));
        this.scene.fog.near = THREE.MathUtils.lerp(this.scene.fog.near, targetNear, Math.min(1.0, dt * 5.0));
        this.scene.fog.far = THREE.MathUtils.lerp(this.scene.fog.far, targetFar, Math.min(1.0, dt * 5.0));
    }

    startLoop() {
        const animate = () => {
            requestAnimationFrame(animate);

            try {
                const dt = Math.min(this.clock.getDelta(), 0.05);

                this.world.flushMeshBuilds(CONFIG.MESH_UPDATES_PER_FRAME);
                this.world.updateWaterAnimation(dt);
                this.updateAtmosphericFog(dt);
                this.cloudGenerator.update(dt);
                this.particleKernel.update(dt);
                this.weatherKernel.update(dt);

                this.currentDaylight = this.dayNightCycle.update(
                    dt,
                    this.sunLight,
                    this.scene,
                    this.camera.position,
                    this.ambientLight,
                    this.moonLight,
                    this.hemisphereLight,
                    this.cloudGenerator
                );

                // Update player and mob systems
                this.player.update(dt);
                const movement = this.player.getMovementState();
                this.survival.update(dt, movement.moving, movement.sprinting);

                // Death screen check or safe respawn
                if (this.survival.health <= 0 && !this.survival.isCreative()) {
                    const deathMenu = document.getElementById('death-menu');
                    const deathTitle = document.getElementById('death-menu-title');
                    const deathSubtitle = document.getElementById('death-menu-subtitle');
                    const respawnBtn = document.getElementById('btn-death-respawn');

                    if (deathMenu && deathMenu.style.display !== 'flex') {
                        this.player.controls.unlock();
                        deathMenu.style.display = 'flex';
                        if (this.survival.isHardcore()) {
                            if (deathTitle) deathTitle.innerText = 'GAME OVER!';
                            if (deathSubtitle) deathSubtitle.innerText = 'You died in Hardcore mode! You have only 1 life.';
                            if (respawnBtn) respawnBtn.innerText = 'SPECTATE WORLD';
                        } else {
                            if (deathTitle) deathTitle.innerText = 'YOU DIED!';
                            if (deathSubtitle) deathSubtitle.innerText = 'Score: 0';
                            if (respawnBtn) respawnBtn.innerText = 'RESPAWN';
                        }
                    }
                } else if (this.camera.position.y < -5) {
                    const respawnPos = this.world.findSafeSpawnSurface(0, 0);
                    this.camera.position.set(respawnPos.x + 0.5, respawnPos.y + 2.62, respawnPos.z + 0.5);
                    this.player.velocity.set(0, 0, 0);
                    if (!this.survival.isCreative()) {
                        this.survival.damage(4);
                        this.showHelpTipFor('Fell into the void!', 2000);
                    }
                }

                this.droppedItemManager.update(dt, this.camera.position);
                this.friendlyMobManager.update(dt, this.camera.position, this.currentDaylight);
                this.hostileMobManager.update(dt, this.camera.position, this.currentDaylight, this.survival, this.friendlyMobManager);
                this.windChargeManager.update(dt, this.world, this.player, this.friendlyMobManager, this.hostileMobManager, this.particleKernel, this.audio);

                // Smooth chunk streaming around player honoring Video Settings render distance
                const px = Math.floor(this.camera.position.x / CONFIG.CHUNK_SIZE);
                const pz = Math.floor(this.camera.position.z / CONFIG.CHUNK_SIZE);
                const r = this.world.renderDistance || CONFIG.RENDER_DISTANCE;
                let generatedCount = 0;
                // Generate outward in concentric rings, max 1 chunk per frame to guarantee 60-70+ FPS
                for (let d = 0; d <= r && generatedCount < 1; d++) {
                    for (let dx = -d; dx <= d && generatedCount < 1; dx++) {
                        for (let dz = -d; dz <= d && generatedCount < 1; dz++) {
                            if (Math.max(Math.abs(dx), Math.abs(dz)) !== d) continue;
                            const key = `${px + dx},${pz + dz}`;
                            const chunk = this.world.chunks.get(key);
                            if (!chunk || !chunk.isGenerated) {
                                this.world.generateChunk(px + dx, pz + dz, false);
                                generatedCount++;
                            }
                        }
                    }
                }

                // Periodic distant chunk unloading (every ~2 seconds) to guarantee 60+ FPS
                if (Math.random() < 0.008) {
                    this.world.unloadFarChunks(px, pz, r + 2);
                }

                // Update debug HUD with Minecraft F3 info (throttled for peak framerates)
                this.debugTimer = (this.debugTimer || 0) + dt;
                if (this.debugTimer >= 0.12) {
                    this.debugTimer = 0;
                    const debug = document.getElementById('debug-console');
                    if (debug && debug.style.display !== 'none') {
                        const curX = Math.round(this.camera.position.x);
                        const curZ = Math.round(this.camera.position.z);
                        const biomeName = this.world.synthesizer.getBiomeType(curX, curZ);
                        const fps = Math.round(1 / Math.max(0.001, dt));
                        debug.innerText =
                            `POS: ${curX} / ${Math.round(this.camera.position.y)} / ${curZ}\n` +
                            `BIOME: ${biomeName.replace('_', ' ')}\n` +
                            `FPS: ${fps} | CHUNKS: ${this.world.chunks.size}\n` +
                            `CAMERA: ${this.player.cameraMode === 0 ? '1ST PERSON' : (this.player.cameraMode === 1 ? '3RD (BACK)' : '3RD (FRONT)')}\n` +
                            `HP/HUNGER: ${Math.round(this.survival.health)}/${Math.round(this.survival.hunger)}`;
                    }
                }

                this.renderer.render(this.scene, this.camera);
            } catch (err) {
                console.error('[VoxelCraft] Frame loop caught error (preventing stuck frame):', err);
            }
        };

        animate();
    }
}

// Instantiate application on window load
window.addEventListener('DOMContentLoaded', () => {
    new VoxelApplication();
});
