import * as THREE from 'three';
import { isVoxelSolid } from './pathfinding';
import { VoxelWorld } from './world';
import { SurvivalSystem } from './systems';
import { AudioProcessor, ParticleKernel } from './environment';
import { FriendlyMobManager, HostileMobManager } from './mobs';

export interface ArrowInstance {
    mesh: THREE.Group;
    velocity: THREE.Vector3;
    life: number;
    stuck: boolean;
    stuckTimer: number;
    firedBy: 'skeleton' | 'player';
}

export class ArrowManager {
    scene: THREE.Scene;
    arrows: ArrowInstance[] = [];

    private shaftGeom: THREE.BoxGeometry;
    private tipGeom: THREE.BoxGeometry;
    private fletchHGeom: THREE.BoxGeometry;
    private fletchVGeom: THREE.BoxGeometry;

    private shaftMat: THREE.MeshLambertMaterial;
    private tipMat: THREE.MeshLambertMaterial;
    private fletchMat: THREE.MeshLambertMaterial;

    constructor(scene: THREE.Scene) {
        this.scene = scene;

        // Shared geometries and materials for optimal performance
        this.shaftGeom = new THREE.BoxGeometry(0.04, 0.04, 0.62);
        this.tipGeom = new THREE.BoxGeometry(0.08, 0.08, 0.12);
        this.fletchHGeom = new THREE.BoxGeometry(0.14, 0.015, 0.12);
        this.fletchVGeom = new THREE.BoxGeometry(0.015, 0.14, 0.12);

        this.shaftMat = new THREE.MeshLambertMaterial({ color: 0x9b6b3e });
        this.tipMat = new THREE.MeshLambertMaterial({ color: 0x2b2b2b });
        this.fletchMat = new THREE.MeshLambertMaterial({ color: 0xe8e8e8 });
    }

    /**
     * Spawns and fires a 3D arrow with authentic Minecraft ballistic arc trajectory
     */
    shootArrow(
        origin: THREE.Vector3,
        target: THREE.Vector3,
        firedBy: 'skeleton' | 'player' = 'skeleton',
        inaccuracy = 0.05
    ): ArrowInstance {
        const group = new THREE.Group();

        // Shaft (along Z axis)
        const shaft = new THREE.Mesh(this.shaftGeom, this.shaftMat);
        group.add(shaft);

        // Dark Flint Arrowhead tip (at positive Z)
        const tip = new THREE.Mesh(this.tipGeom, this.tipMat);
        tip.position.set(0, 0, 0.35);
        group.add(tip);

        // White feather fletching (at negative Z)
        const fletchH = new THREE.Mesh(this.fletchHGeom, this.fletchMat);
        fletchH.position.set(0, 0, -0.25);
        group.add(fletchH);

        const fletchV = new THREE.Mesh(this.fletchVGeom, this.fletchMat);
        fletchV.position.set(0, 0, -0.25);
        group.add(fletchV);

        // Position arrow at launch origin
        group.position.copy(origin);

        // Ballistic velocity calculation
        const dx = target.x - origin.x;
        const dz = target.z - origin.z;
        const dist = Math.hypot(dx, dz);
        const speed = 21.0;
        const timeToTarget = Math.max(0.1, dist / speed);

        const dy = (target.y + 0.65) - origin.y;
        // Compensate for -17.5 m/s^2 gravity
        const vy = dy / timeToTarget + 0.5 * 17.5 * timeToTarget;

        const spreadX = (Math.random() - 0.5) * inaccuracy * speed;
        const spreadZ = (Math.random() - 0.5) * inaccuracy * speed;

        const velocity = new THREE.Vector3(
            (dx / dist) * speed + spreadX,
            vy,
            (dz / dist) * speed + spreadZ
        );

        // Face trajectory
        const lookTarget = group.position.clone().add(velocity);
        group.lookAt(lookTarget);

        this.scene.add(group);

        const arrow: ArrowInstance = {
            mesh: group,
            velocity,
            life: 0,
            stuck: false,
            stuckTimer: 0,
            firedBy
        };

        this.arrows.push(arrow);
        return arrow;
    }

    /**
     * Updates physics, trajectories, voxel collisions, and entity damage
     */
    update(
        dt: number,
        world: VoxelWorld,
        playerPos: THREE.Vector3,
        survival: SurvivalSystem,
        friendlyMobs?: FriendlyMobManager,
        hostileMobs?: HostileMobManager,
        audio?: AudioProcessor,
        particles?: ParticleKernel
    ) {
        const app = (window as any).app;

        for (let i = this.arrows.length - 1; i >= 0; i--) {
            const arrow = this.arrows[i];
            arrow.life += dt;

            // Handle stuck arrow (embedded in block)
            if (arrow.stuck) {
                arrow.stuckTimer += dt;

                // Player pickup check: if player walks over stuck arrow, collect it!
                const pDist = arrow.mesh.position.distanceTo(playerPos);
                if (pDist < 1.1 && !survival.isCreative()) {
                    if (app?.inventory?.addResource) {
                        app.inventory.addResource('arrow', 1);
                        audio?.playPickup?.();
                        app?.showHelpTipFor?.('+1 Arrow picked up', 1200);
                    }
                    this.scene.remove(arrow.mesh);
                    this.arrows.splice(i, 1);
                    continue;
                }

                // Despawn stuck arrows after 16 seconds
                if (arrow.stuckTimer > 16.0) {
                    this.scene.remove(arrow.mesh);
                    this.arrows.splice(i, 1);
                }
                continue;
            }

            // Despawn if falling into void or flying for too long
            if (arrow.life > 9.0 || arrow.mesh.position.y < -12) {
                this.scene.remove(arrow.mesh);
                this.arrows.splice(i, 1);
                continue;
            }

            // In-flight physics step
            const prevPos = arrow.mesh.position.clone();
            const stepDelta = arrow.velocity.clone().multiplyScalar(dt);
            const nextPos = prevPos.clone().add(stepDelta);

            // Gravity & air resistance
            arrow.velocity.y -= 17.5 * dt;
            arrow.velocity.multiplyScalar(Math.pow(0.993, dt * 20));

            // Align arrow mesh with flight direction
            const flightDir = arrow.velocity.clone().normalize();
            if (flightDir.lengthSq() > 0.001) {
                arrow.mesh.lookAt(nextPos.clone().add(flightDir));
            }

            // Voxel collision check along step path
            const tipPos = nextPos.clone().addScaledVector(flightDir, 0.35);
            const bx = Math.floor(tipPos.x);
            const by = Math.floor(tipPos.y);
            const bz = Math.floor(tipPos.z);

            if (isVoxelSolid(world, bx, by, bz)) {
                // Arrow embeds into the solid block!
                arrow.stuck = true;
                arrow.mesh.position.copy(tipPos);
                audio?.playAttackHit?.();
                particles?.spawnDebris(tipPos.x, tipPos.y, tipPos.z, 0x8b5a2b);
                continue;
            }

            // Advance position
            arrow.mesh.position.copy(nextPos);

            // Check hit against player (for skeleton arrows)
            if (arrow.firedBy === 'skeleton') {
                const pDistH = Math.hypot(nextPos.x - playerPos.x, nextPos.z - playerPos.z);
                const pDistY = nextPos.y - playerPos.y;

                if (pDistH < 0.62 && pDistY >= -0.2 && pDistY <= 1.85) {
                    // Hit player!
                    if (!survival.isCreative() && survival.health > 0) {
                        survival.damage(4); // 4 damage (2 full hearts), reduced by armor
                        audio?.playAttackHit?.();
                        particles?.spawnDebris(nextPos.x, nextPos.y, nextPos.z, 0xbb2222);

                        // Apply knockback to player
                        if (app?.player?.velocity) {
                            const kbSpeed = 6.2;
                            app.player.velocity.x += flightDir.x * kbSpeed;
                            app.player.velocity.z += flightDir.z * kbSpeed;
                            app.player.velocity.y = Math.max(app.player.velocity.y, 3.6);
                        }
                    }

                    this.scene.remove(arrow.mesh);
                    this.arrows.splice(i, 1);
                    continue;
                }
            }

            // Check hit against friendly mobs (e.g. cows, pigs, sheep)
            if (friendlyMobs) {
                let hitMob = false;
                for (const [mId, mob] of friendlyMobs.entities.entries()) {
                    const mDist = mob.group.position.distanceTo(nextPos);
                    if (mDist < 0.95) {
                        friendlyMobs.damageEntityDirect(mob, mId, 4);
                        audio?.playAttackHit?.();
                        particles?.spawnDebris(nextPos.x, nextPos.y, nextPos.z, 0xbb2222);
                        hitMob = true;
                        break;
                    }
                }
                if (hitMob) {
                    this.scene.remove(arrow.mesh);
                    this.arrows.splice(i, 1);
                    continue;
                }
            }
        }
    }

    clear() {
        for (const arrow of this.arrows) {
            this.scene.remove(arrow.mesh);
        }
        this.arrows = [];
    }
}
