// ==============================================================
// VOXELCRAFT - VIDEO SETTINGS & PERFORMANCE MANAGER
// Authentic Minecraft-style Video Settings & Pause Menu Handler
// ==============================================================

export interface VideoSettings {
    graphics: 'fast' | 'fancy';
    renderDistance: number; // chunks
    maxFps: number; // 0 = unlimited, 30, 60, 120
    fov: number; // 60 to 110
    brightness: number; // 0 to 100
    smoothLighting: boolean;
    shadows: boolean;
    viewBobbing: boolean;
    highDpi: boolean;
}

const STORAGE_KEY = 'voxelcraft_video_settings';

const DEFAULT_SETTINGS: VideoSettings = {
    graphics: 'fancy',
    renderDistance: 3,
    maxFps: 0,
    fov: 70,
    brightness: 50,
    smoothLighting: true,
    shadows: false, // Disabled by default for rock-solid 60+ FPS
    viewBobbing: true,
    highDpi: false
};

export class VideoSettingsManager {
    settings: VideoSettings;
    app: any;
    private modalEl: HTMLElement | null = null;
    private isOpen: boolean = false;

    constructor() {
        this.settings = this.load();
    }

    setApp(app: any) {
        this.app = app;
        this.apply();
        this.createSettingsUI();
    }

    load(): VideoSettings {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            if (raw) {
                return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
            }
        } catch (e) {
            console.warn('[VideoSettings] Failed to read from localStorage:', e);
        }
        return { ...DEFAULT_SETTINGS };
    }

    save() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
        } catch (e) {
            console.warn('[VideoSettings] Failed to save to localStorage:', e);
        }
    }

    apply() {
        if (!this.app) return;

        // Apply FOV to camera
        if (this.app.camera) {
            this.app.camera.fov = this.settings.fov;
            this.app.camera.updateProjectionMatrix();
        }

        // Apply Pixel Ratio & Shadows to WebGLRenderer
        if (this.app.renderer) {
            const ratio = this.settings.highDpi ? Math.min(window.devicePixelRatio, 1.5) : 1.0;
            this.app.renderer.setPixelRatio(ratio);

            const prevShadows = this.app.renderer.shadowMap.enabled;
            this.app.renderer.shadowMap.enabled = this.settings.shadows;
            if (prevShadows !== this.settings.shadows) {
                this.app.renderer.shadowMap.needsUpdate = true;
            }
        }

        // Apply Brightness to Ambient Lighting
        if (this.app.ambientLight) {
            // Brightness 0 -> 0.35 intensity; 100 -> 0.85 intensity
            const intensity = 0.35 + (this.settings.brightness / 100) * 0.50;
            this.app.ambientLight.intensity = intensity;
        }

        // Apply Render Distance to World
        if (this.app.world && typeof this.app.world.setRenderDistance === 'function') {
            this.app.world.setRenderDistance(this.settings.renderDistance);
        }

        // Apply View Bobbing flag
        if (this.app.player) {
            this.app.player.viewBobbingEnabled = this.settings.viewBobbing;
        }
    }

    private openedFromPause = false;

    isSettingsOpen(): boolean {
        return this.isOpen;
    }

    wasOpenedFromPause(): boolean {
        return this.openedFromPause;
    }

    openSettingsUI(fromPause: boolean = false) {
        this.openedFromPause = fromPause;
        if (!this.modalEl) {
            this.createSettingsUI();
        }
        if (this.modalEl) {
            this.modalEl.style.display = 'flex';
            this.isOpen = true;
            this.refreshUIElements();
        }
    }

    closeSettingsUI(returnToPause: boolean = true) {
        if (!this.isOpen && (!this.modalEl || this.modalEl.style.display === 'none')) {
            return;
        }
        if (this.modalEl) {
            this.modalEl.style.display = 'none';
            this.isOpen = false;
        }
        this.save();
        this.apply();
        // Pause menu strictly opens ONLY when ESC is pressed by the player
        if (this.app && this.app.gameStarted) {
            this.app.player?.controls?.lock();
        }
        this.openedFromPause = false;
    }

    private createSettingsUI() {
        let existing = document.getElementById('video-settings-modal');
        if (existing) {
            this.modalEl = existing;
            return;
        }

        const modal = document.createElement('div');
        modal.id = 'video-settings-modal';
        modal.style.position = 'fixed';
        modal.style.inset = '0';
        modal.style.background = 'rgba(15, 18, 24, 0.88)';
        modal.style.backdropFilter = 'blur(6px)';
        modal.style.zIndex = '9000';
        modal.style.display = 'none';
        modal.style.flexDirection = 'column';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.style.fontFamily = 'Minecraft, monospace, sans-serif';
        modal.style.color = '#ffffff';
        modal.style.userSelect = 'none';

        modal.innerHTML = `
            <div style="background: rgba(30, 34, 45, 0.95); border: 2px solid #555b6e; border-radius: 4px; padding: 24px 32px; width: 620px; max-width: 92vw; box-shadow: 0 12px 36px rgba(0,0,0,0.7);">
                <div style="text-align: center; margin-bottom: 22px;">
                    <h2 style="font-size: 22px; font-weight: bold; letter-spacing: 1px; color: #ffffff; margin: 0 0 6px 0;">VIDEO SETTINGS</h2>
                    <div style="font-size: 12px; color: #9aa0a6;">Tune graphics, framerate, and render distance</div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px 16px; margin-bottom: 24px;">
                    <!-- Graphics -->
                    <button class="vs-btn" id="vs-btn-graphics" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Graphics: <span style="color: #66f5e8;" id="vs-val-graphics">Fancy</span>
                    </button>

                    <!-- Render Distance -->
                    <button class="vs-btn" id="vs-btn-render-dist" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Render Distance: <span style="color: #66f5e8;" id="vs-val-render-dist">3 Chunks</span>
                    </button>

                    <!-- Max Framerate -->
                    <button class="vs-btn" id="vs-btn-fps" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Max Framerate: <span style="color: #66f5e8;" id="vs-val-fps">Unlimited</span>
                    </button>

                    <!-- Smooth Lighting -->
                    <button class="vs-btn" id="vs-btn-smooth-light" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Smooth Lighting: <span style="color: #66f5e8;" id="vs-val-smooth-light">ON</span>
                    </button>

                    <!-- Dynamic Shadows (Major FPS boost) -->
                    <button class="vs-btn" id="vs-btn-shadows" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Shadows: <span style="color: #66f5e8;" id="vs-val-shadows">OFF (High FPS)</span>
                    </button>

                    <!-- Resolution / DPI -->
                    <button class="vs-btn" id="vs-btn-dpi" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        Resolution: <span style="color: #66f5e8;" id="vs-val-dpi">Performance (1.0x)</span>
                    </button>

                    <!-- View Bobbing -->
                    <button class="vs-btn" id="vs-btn-bobbing" style="padding: 10px 14px; background: #3b4252; color: #fff; border: 2px solid #5a6478; border-radius: 3px; cursor: pointer; text-align: left; font-size: 13px; font-weight: 500;">
                        View Bobbing: <span style="color: #66f5e8;" id="vs-val-bobbing">ON</span>
                    </button>

                    <!-- Brightness -->
                    <div style="display: flex; flex-direction: column; justify-content: center; background: #2e3440; padding: 6px 14px; border: 2px solid #434c5e; border-radius: 3px;">
                        <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 4px;">
                            <span>Brightness:</span>
                            <span id="vs-val-brightness" style="color: #66f5e8;">Bright (+50%)</span>
                        </div>
                        <input type="range" id="vs-slider-brightness" min="0" max="100" value="50" style="width: 100%; cursor: pointer; accent-color: #48d8cc;" />
                    </div>
                </div>

                <!-- FOV Slider -->
                <div style="background: #2e3440; padding: 10px 14px; border: 2px solid #434c5e; border-radius: 3px; margin-bottom: 20px;">
                    <div style="display: flex; justify-content: space-between; font-size: 13px; margin-bottom: 6px;">
                        <span>Field of View (FOV):</span>
                        <span id="vs-val-fov" style="color: #66f5e8;">Normal (70)</span>
                    </div>
                    <input type="range" id="vs-slider-fov" min="60" max="105" value="70" style="width: 100%; cursor: pointer; accent-color: #48d8cc;" />
                </div>

                <!-- Done Button -->
                <div style="text-align: center;">
                    <button id="vs-btn-done" style="width: 220px; padding: 12px 24px; background: #4c566a; color: #ffffff; border: 2px solid #d8dee9; border-radius: 3px; cursor: pointer; font-size: 14px; font-weight: bold; letter-spacing: 1px; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
                        DONE
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        this.modalEl = modal;

        // Wire event handlers
        const btnGraphics = modal.querySelector('#vs-btn-graphics');
        btnGraphics?.addEventListener('click', () => {
            this.settings.graphics = this.settings.graphics === 'fancy' ? 'fast' : 'fancy';
            this.refreshUIElements();
            this.apply();
        });

        const btnRenderDist = modal.querySelector('#vs-btn-render-dist');
        btnRenderDist?.addEventListener('click', () => {
            const steps = [2, 3, 4, 6, 8];
            const idx = steps.indexOf(this.settings.renderDistance);
            this.settings.renderDistance = steps[(idx + 1) % steps.length];
            this.refreshUIElements();
            this.apply();
        });

        const btnFps = modal.querySelector('#vs-btn-fps');
        btnFps?.addEventListener('click', () => {
            const steps = [0, 30, 60, 120];
            const idx = steps.indexOf(this.settings.maxFps);
            this.settings.maxFps = steps[(idx + 1) % steps.length];
            this.refreshUIElements();
            this.apply();
        });

        const btnSmoothLight = modal.querySelector('#vs-btn-smooth-light');
        btnSmoothLight?.addEventListener('click', () => {
            this.settings.smoothLighting = !this.settings.smoothLighting;
            this.refreshUIElements();
            this.apply();
        });

        const btnShadows = modal.querySelector('#vs-btn-shadows');
        btnShadows?.addEventListener('click', () => {
            this.settings.shadows = !this.settings.shadows;
            this.refreshUIElements();
            this.apply();
        });

        const btnDpi = modal.querySelector('#vs-btn-dpi');
        btnDpi?.addEventListener('click', () => {
            this.settings.highDpi = !this.settings.highDpi;
            this.refreshUIElements();
            this.apply();
        });

        const btnBobbing = modal.querySelector('#vs-btn-bobbing');
        btnBobbing?.addEventListener('click', () => {
            this.settings.viewBobbing = !this.settings.viewBobbing;
            this.refreshUIElements();
            this.apply();
        });

        const sliderBrightness = modal.querySelector('#vs-slider-brightness') as HTMLInputElement;
        sliderBrightness?.addEventListener('input', () => {
            this.settings.brightness = parseInt(sliderBrightness.value);
            this.refreshUIElements();
            this.apply();
        });

        const sliderFov = modal.querySelector('#vs-slider-fov') as HTMLInputElement;
        sliderFov?.addEventListener('input', () => {
            this.settings.fov = parseInt(sliderFov.value);
            this.refreshUIElements();
            this.apply();
        });

        const btnDone = modal.querySelector('#vs-btn-done');
        btnDone?.addEventListener('click', () => {
            this.closeSettingsUI();
        });
    }

    private refreshUIElements() {
        if (!this.modalEl) return;

        const valGraphics = this.modalEl.querySelector('#vs-val-graphics');
        if (valGraphics) valGraphics.textContent = this.settings.graphics === 'fancy' ? 'Fancy' : 'Fast (Max FPS)';

        const valDist = this.modalEl.querySelector('#vs-val-render-dist');
        if (valDist) valDist.textContent = `${this.settings.renderDistance} Chunks`;

        const valFps = this.modalEl.querySelector('#vs-val-fps');
        if (valFps) valFps.textContent = this.settings.maxFps === 0 ? 'Unlimited' : `${this.settings.maxFps} FPS`;

        const valLight = this.modalEl.querySelector('#vs-val-smooth-light');
        if (valLight) valLight.textContent = this.settings.smoothLighting ? 'ON' : 'OFF';

        const valShadows = this.modalEl.querySelector('#vs-val-shadows');
        if (valShadows) valShadows.textContent = this.settings.shadows ? 'ON (Fancy)' : 'OFF (High FPS)';

        const valDpi = this.modalEl.querySelector('#vs-val-dpi');
        if (valDpi) valDpi.textContent = this.settings.highDpi ? 'Native (Sharp)' : '1.0x (Optimal)';

        const valBobbing = this.modalEl.querySelector('#vs-val-bobbing');
        if (valBobbing) valBobbing.textContent = this.settings.viewBobbing ? 'ON' : 'OFF';

        const valBright = this.modalEl.querySelector('#vs-val-brightness');
        const sliderBright = this.modalEl.querySelector('#vs-slider-brightness') as HTMLInputElement;
        if (valBright) {
            valBright.textContent = this.settings.brightness === 0 ? 'Moody' : (this.settings.brightness === 100 ? 'Bright (+100%)' : `+${this.settings.brightness}%`);
        }
        if (sliderBright) sliderBright.value = String(this.settings.brightness);

        const valFov = this.modalEl.querySelector('#vs-val-fov');
        const sliderFov = this.modalEl.querySelector('#vs-slider-fov') as HTMLInputElement;
        if (valFov) {
            valFov.textContent = this.settings.fov === 70 ? 'Normal (70)' : (this.settings.fov >= 100 ? `Quake Pro (${this.settings.fov})` : String(this.settings.fov));
        }
        if (sliderFov) sliderFov.value = String(this.settings.fov);
    }
}
