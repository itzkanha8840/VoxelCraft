import * as THREE from 'three';
import { createNoise2D, createNoise3D } from 'simplex-noise';
import {
    CONFIG,
    BLOCK_ID,
    BLOCK_DEFS,
    ORE_BLOCKS,
    OVERWORLD_STRUCTURE_BIOMES,
    RUIN_BIOMES,
    VILLAGE_BIOMES,
    RESOURCE_ITEM
} from './constants';
import { StructureGenerator } from './structures';
import { createMinecraftTexture } from './minecraftTextures';

/* ==============================================================
   VECTOR & MATH UTILITY MODULE
   ============================================================== */

export class MathKernel {
    static floor(val: number) { return Math.floor(val); }
    static round(val: number) { return Math.round(val); }
    static clamp(val: number, min: number, max: number) { return Math.max(min, Math.min(max, val)); }
    static lerp(a: number, b: number, t: number) { return a + (b - a) * t; }

    static getLocalCoords(wx: number, wy: number, wz: number) {
        const lx = ((wx % CONFIG.CHUNK_SIZE) + CONFIG.CHUNK_SIZE) % CONFIG.CHUNK_SIZE;
        const lz = ((wz % CONFIG.CHUNK_SIZE) + CONFIG.CHUNK_SIZE) % CONFIG.CHUNK_SIZE;
        return { lx, wy, lz };
    }

    static getChunkCoords(wx: number, wz: number) {
        return {
            cx: Math.floor(wx / CONFIG.CHUNK_SIZE),
            cz: Math.floor(wz / CONFIG.CHUNK_SIZE)
        };
    }

    static hash2(x: number, z: number) {
        const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
        return s - Math.floor(s);
    }

    static toWorldY(internalY: number) {
        return internalY + CONFIG.WORLD_MIN_Y;
    }

    static toInternalY(worldY: number) {
        return worldY - CONFIG.WORLD_MIN_Y;
    }
}

/* ==============================================================
   CHUNK DATA
   ============================================================== */

export class Chunk {
    cx: number;
    cz: number;
    data: Uint8Array;
    isDirty: boolean;
    isGenerated: boolean;

    constructor(cx: number, cz: number) {
        this.cx = cx;
        this.cz = cz;
        this.data = new Uint8Array(CONFIG.CHUNK_SIZE * CONFIG.CHUNK_HEIGHT * CONFIG.CHUNK_SIZE);
        this.isDirty = true;
        this.isGenerated = false;
    }

    getIndex(lx: number, y: number, lz: number) {
        return lx + (y * CONFIG.CHUNK_SIZE) + (lz * CONFIG.CHUNK_SIZE * CONFIG.CHUNK_HEIGHT);
    }

    setBlock(lx: number, y: number, lz: number, id: number) {
        if (lx < 0 || lx >= CONFIG.CHUNK_SIZE || lz < 0 || lz >= CONFIG.CHUNK_SIZE) return;
        if (y < 0 || y >= CONFIG.CHUNK_HEIGHT) return;
        this.data[this.getIndex(lx, y, lz)] = id;
        this.isDirty = true;
    }

    getBlock(lx: number, y: number, lz: number): number {
        if (lx < 0 || lx >= CONFIG.CHUNK_SIZE || lz < 0 || lz >= CONFIG.CHUNK_SIZE) return 0;
        if (y < 0 || y >= CONFIG.CHUNK_HEIGHT) return 0;
        return this.data[this.getIndex(lx, y, lz)];
    }

    cloneData() {
        return this.data.slice();
    }
}

/* ==============================================================
   PROCEDURAL TERRAIN SYNTHESIZER
   ============================================================== */

export interface ClimateSample {
    continental: number;
    heat: number;
    humidity: number;
    mountainFactor: number;
    variation: number;
    effectiveTemp: number; // altitude-adjusted temperature
    desertWeight: number; // 0..1 smooth blend for desert ecotone
    forestWeight: number; // 0..1 smooth blend from plains (0) to forest (1)
    snowWeight: number;   // 0..1 smooth blend for snowy biomes and alpine peaks
    isAlpinePeak: boolean;
    isSnowyPeak: boolean;
}

export class TerrainSynthesizer {
    noise: any;
    biomeNoise: any;
    mountainNoise: any;
    detailNoise: any;
    caveNoise: any;
    caveNoiseB: any;
    caveNoiseC: any;

    constructor(seed: number) {
        const makeNoise = (s: number) => {
            let current = s;
            const prng = () => {
                current = (current * 9301 + 49297) % 233280;
                return current / 233280;
            };
            return {
                noise2D: createNoise2D(prng),
                noise3D: createNoise3D(prng)
            };
        };

        this.noise = makeNoise(seed);
        this.biomeNoise = makeNoise(seed + 101);
        this.mountainNoise = makeNoise(seed + 202);
        this.detailNoise = makeNoise(seed + 303);
        this.caveNoise = makeNoise(seed + 404);
        this.caveNoiseB = makeNoise(seed + 505);
        this.caveNoiseC = makeNoise(seed + 606);
    }

    getClimate(x: number, z: number, y?: number): ClimateSample {
        const continental = this.noise.noise2D(x * 0.0022, z * 0.0022);
        const heat = this.biomeNoise.noise2D(x * 0.0028 + 150, z * 0.0028 - 150);
        const humidity = this.mountainNoise.noise2D(x * 0.0028 - 250, z * 0.0028 + 250);
        const mountainFactor = this.detailNoise.noise2D(x * 0.0035 + 500, z * 0.0035 - 500);
        const variation = this.detailNoise.noise2D(x * 0.006 + 70, z * 0.006 - 70);

        const currentY = y !== undefined ? y : this.getHeight(x, z);

        // Elevation temperature lapse rate: temperature decreases with altitude!
        // Peaks above Y = 56 freeze, creating snowy mountain peaks even near hot deserts!
        const altitudeCooling = Math.max(0, currentY - 45) * 0.032;
        const effectiveTemp = heat - altitudeCooling;

        // Smooth desert weight (high heat, dry humidity):
        const heatDesertFactor = MathKernel.clamp((heat - 0.22) / 0.14, 0, 1);
        const humidityDesertFactor = MathKernel.clamp((-humidity - 0.10) / 0.14, 0, 1);
        const desertWeight = heatDesertFactor * humidityDesertFactor;

        // Smooth forest weight vs plains (temperate heat, moderate-to-high humidity):
        // 0 = open plains, 1 = dense forest; smooth transition between 0.04 and 0.20
        const forestWeight = MathKernel.clamp((humidity - 0.04) / 0.16, 0, 1);

        // Snow weight (cold climate or alpine altitude):
        const coldClimateFactor = MathKernel.clamp((-effectiveTemp - 0.20) / 0.14, 0, 1);
        const alpineElevationFactor = MathKernel.clamp((currentY - 56) / 8, 0, 1);
        const snowWeight = Math.max(coldClimateFactor, alpineElevationFactor);

        const isAlpinePeak = currentY >= 50 && mountainFactor > 0.36 && continental > -0.15;
        const isSnowyPeak = currentY >= 58 && (isAlpinePeak || snowWeight > 0.55);

        return {
            continental,
            heat,
            humidity,
            mountainFactor,
            variation,
            effectiveTemp,
            desertWeight,
            forestWeight,
            snowWeight,
            isAlpinePeak,
            isSnowyPeak
        };
    }

    getBiomeType(x: number, z: number, y?: number): string {
        const c = this.getClimate(x, z, y);
        if (c.continental < -0.38) return 'OCEAN';
        if (c.continental < -0.25) return 'BEACH';

        // Mountain peaks (including snowy peaks near desert edges!)
        if (c.isSnowyPeak) {
            return 'SNOWY_SLOPES';
        }
        if (c.isAlpinePeak) {
            return 'MOUNTAINS';
        }

        // Cold biomes
        if (c.effectiveTemp < -0.30) {
            if (c.humidity > 0.1) return 'SNOWY_TAIGA';
            return 'SNOWY_PLAINS';
        }

        // Hot biomes
        if (c.desertWeight > 0.65) {
            return 'DESERT';
        }
        if (c.heat > 0.30) {
            if (c.humidity < 0.15) return 'SAVANNA';
            if (c.humidity > 0.42) return 'JUNGLE';
            return 'BADLANDS';
        }

        // Temperate biomes
        if (c.humidity > 0.40) return 'SWAMP';
        if (c.forestWeight > 0.65) {
            if (c.variation > 0.35) return 'DARK_FOREST';
            if (c.variation < -0.35) return 'CHERRY_GROVE';
            if (c.variation < -0.05) return 'BIRCH_FOREST';
            return 'FOREST';
        }
        if (c.heat < -0.08) return 'TAIGA';

        // Plains variations
        if (c.variation > 0.35) return 'SUNFLOWER_PLAINS';
        return 'PLAINS';
    }

    getHeight(x: number, z: number): number {
        const continental = this.noise.noise2D(x * 0.0022, z * 0.0022);

        // Water depth for oceans (sea level is 30)
        if (continental < -0.38) {
            const depth = MathKernel.clamp((-continental - 0.38) * 22, 4, 12);
            return Math.floor(CONFIG.WATER_LEVEL - depth);
        }
        // Beach transition: smooth hermite spline
        if (continental < -0.25) {
            const t = (continental - (-0.38)) / 0.13;
            const smoothT = t * t * (3 - 2 * t);
            return Math.floor(CONFIG.WATER_LEVEL + smoothT * 2.0);
        }

        const baseLand = CONFIG.WATER_LEVEL + 4; // y = 34

        // Continuous multi-octave natural rolling hills:
        const roll1 = this.noise.noise2D(x * 0.0045, z * 0.0045) * 3.2;
        const roll2 = this.detailNoise.noise2D(x * 0.011, z * 0.011) * 1.6;
        let roll = roll1 + roll2;

        // Continuous wetland dampening:
        const humidity = this.mountainNoise.noise2D(x * 0.0028 - 250, z * 0.0028 + 250);
        const heat = this.biomeNoise.noise2D(x * 0.0028 + 150, z * 0.0028 - 150);
        const swampWeight = MathKernel.clamp((humidity - 0.34) / 0.12, 0, 1) * MathKernel.clamp(1 - Math.abs(heat) * 2.5, 0, 1);
        if (swampWeight > 0) {
            roll = MathKernel.lerp(roll, this.noise.noise2D(x * 0.008, z * 0.008) * 1.0, swampWeight);
        }

        // Mountain rise: smooth hermite curve that rises gracefully into towering alpine peaks
        const mountainRaw = this.detailNoise.noise2D(x * 0.0035 + 500, z * 0.0035 - 500);
        let mountainRise = 0;
        if (mountainRaw > 0.38 && continental > -0.18) {
            const mNorm = MathKernel.clamp((mountainRaw - 0.38) / 0.62, 0, 1);
            const smoothNorm = mNorm * mNorm * (3 - 2 * mNorm);
            const ridge = 1.0 - Math.abs(this.mountainNoise.noise2D(x * 0.0075, z * 0.0075));
            mountainRise = smoothNorm * 30 + ridge * 6.5;
        }

        const rawHeight = baseLand + roll + mountainRise;
        return Math.floor(rawHeight);
    }

    shouldSpawnTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.08, y * 0.08, z * 0.08) > 0.62;
    }

    shouldSpawnCactus(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.07 + 100, y * 0.07, z * 0.07) > 0.68;
    }

    shouldSpawnJungleTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.05 + 39.2, y * 0.05, z * 0.05 - 17.3) > 0.49;
    }

    shouldSpawnCherryTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.06 - 82.7, y * 0.06, z * 0.06 + 54.9) > 0.58;
    }

    shouldSpawnMushroomTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.055 + 121.3, y * 0.055, z * 0.055 - 77.6) > 0.54;
    }

    shouldSpawnBamboo(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.085 + 12.2, y * 0.085, z * 0.085 + 48.8) > -0.04;
    }

    shouldSpawnTaigaTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.057 - 41.3, y * 0.057, z * 0.057 + 73.9) > 0.43;
    }

    shouldSpawnAcaciaTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.062 + 154.7, y * 0.062, z * 0.062 - 52.8) > 0.52;
    }

    shouldSpawnSwampTree(x: number, y: number, z: number) {
        return this.detailNoise.noise3D(x * 0.067 - 202.4, y * 0.067, z * 0.067 + 106.1) > 0.5;
    }

    getCaveRegionRandom(x: number, z: number) {
        const cellX = Math.floor(x / 24);
        const cellZ = Math.floor(z / 24);
        return MathKernel.hash2(cellX * 1.37 + 77.3, cellZ * 1.91 - 42.8);
    }

    hasCave(x: number, y: number, z: number, h: number = 36): boolean {
        // Caves only exist deep underground below sea level (y <= 22)
        // Mountains and elevated terrain are NEVER hollow; always 100% solid rock & ores!
        if (y > 22 || y <= 4 || y >= h - 8) return false;

        // Protect the spawn region: no caves within 48 blocks of world spawn!
        if (Math.abs(x) < 48 && Math.abs(z) < 48) return false;

        // Minecraft authentic 3D noodle cave generation (small subterranean tunnels)
        const n1 = this.caveNoise.noise3D(x * 0.035, y * 0.045, z * 0.035);
        const n2 = this.caveNoiseB.noise3D(x * 0.035, y * 0.045, z * 0.035);
        const tube = n1 * n1 + n2 * n2;
        const isTunnel = tube < 0.0035;

        // Occasional underground spherical chamber
        const chamber = this.caveNoiseC.noise3D(x * 0.02, y * 0.028, z * 0.02);
        const isChamber = chamber > 0.78 && tube < 0.035 && y <= 16;

        return isTunnel || isChamber;
    }

    hasRavine(x: number, y: number, z: number, h: number = 36): boolean {
        // Ravines only deep underground below sea level, never in mountains
        if (y > 20 || y <= 8 || y >= h - 10) return false;
        if (Math.abs(x) < 48 && Math.abs(z) < 48) return false;

        const regionRand = this.getCaveRegionRandom(x + 311, z - 219);
        if (regionRand < 0.45) return false;
        const line = Math.abs(this.caveNoiseB.noise2D(x * 0.0052, z * 0.0052));
        if (line > 0.016) return false;
        const centerY = 14 + this.caveNoiseC.noise2D(x * 0.009, z * 0.009) * 4;
        const halfHeight = 4 + Math.abs(this.caveNoise.noise2D(x * 0.011, z * 0.011)) * 3;
        return Math.abs(y - centerY) <= halfHeight;
    }

    hasLavaPocket(x: number, y: number, z: number) {
        if (y > 18 || y < 4) return false;
        const blob = this.caveNoiseB.noise3D(x * 0.041, y * 0.055, z * 0.041);
        return blob > 0.65;
    }
}

/* ==============================================================
   VOXEL WORLD MANAGER
   ============================================================== */

export function createCrossPlantGeometry(): THREE.BufferGeometry {
    const geom = new THREE.BufferGeometry();
    const s = 0.42;
    const h = 0.88;
    const positions = new Float32Array([
        // Quad 1: (-s, 0, -s) -> (s, h, s)
        -s, 0, -s,
         s, 0,  s,
         s, h,  s,
        -s, 0, -s,
         s, h,  s,
        -s, h, -s,

        // Quad 2: (-s, 0, s) -> (s, h, -s)
        -s, 0,  s,
         s, 0, -s,
         s, h, -s,
        -s, 0,  s,
         s, h, -s,
        -s, h,  s
    ]);

    const uvs = new Float32Array([
        0, 0,  1, 0,  1, 1,
        0, 0,  1, 1,  0, 1,

        0, 0,  1, 0,  1, 1,
        0, 0,  1, 1,  0, 1
    ]);

    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geom.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
    geom.computeVertexNormals();
    return geom;
}

export class VoxelWorld {
    scene: THREE.Scene;
    chunks: Map<string, Chunk>;
    meshes: Map<string, THREE.Group>;
    synthesizer: TerrainSynthesizer;
    unitGeometry: THREE.BoxGeometry;
    foliageCrossGeometry: THREE.BufferGeometry;
    waterTopGeometry: THREE.PlaneGeometry;
    waterSideGeometry: THREE.PlaneGeometry;
    lavaTopGeometry: THREE.PlaneGeometry;
    lavaSideGeometry: THREE.PlaneGeometry;
    foliagePlaneGeometry: THREE.PlaneGeometry;
    meshBuildQueue: Array<{ cx: number; cz: number; key: string }>;
    meshBuildQueued: Set<string>;
    raycastTargets: THREE.Mesh[];
    raycastTargetIds: Set<number>;
    dummy: THREE.Object3D;
    chunkArchive: Map<string, Uint8Array>;
    villageCenters: Set<string>;
    villageSpawns: Map<string, any[]>;
    biomeSpawns: Map<string, any[]>;
    chestLoot: Map<string, any[]>;
    ruinCenters: Set<string>;
    overworldStructureCenters: Set<string>;
    netherStructureCenters: Set<string>;
    materials: Record<number, THREE.Material | THREE.Material[]>;
    highlighter: THREE.LineSegments;
    breakOverlay: THREE.Mesh;
    crackTextures: THREE.Texture[];
    waterTexture: THREE.CanvasTexture | null = null;
    lavaTexture: THREE.CanvasTexture | null = null;
    portalTexture: THREE.CanvasTexture | null = null;
    renderDistance: number = CONFIG.RENDER_DISTANCE;

    constructor(scene: THREE.Scene) {
        this.scene = scene;
        this.chunks = new Map();
        this.meshes = new Map();
        this.synthesizer = new TerrainSynthesizer(CONFIG.SEED);
        this.unitGeometry = new THREE.BoxGeometry(1, 1, 1);
        this.foliageCrossGeometry = createCrossPlantGeometry();
        this.waterTopGeometry = new THREE.PlaneGeometry(1, 1);
        this.waterTopGeometry.rotateX(-Math.PI / 2);
        this.waterSideGeometry = new THREE.PlaneGeometry(1, CONFIG.WATER_SURFACE_HEIGHT);
        this.lavaTopGeometry = new THREE.PlaneGeometry(1, 1);
        this.lavaTopGeometry.rotateX(-Math.PI / 2);
        this.lavaSideGeometry = new THREE.PlaneGeometry(1, CONFIG.LAVA_SURFACE_HEIGHT);
        this.foliagePlaneGeometry = new THREE.PlaneGeometry(0.92, 0.92);
        this.meshBuildQueue = [];
        this.meshBuildQueued = new Set();
        this.raycastTargets = [];
        this.raycastTargetIds = new Set();
        this.dummy = new THREE.Object3D();
        this.chunkArchive = new Map();
        this.villageCenters = new Set();
        this.villageSpawns = new Map();
        this.biomeSpawns = new Map();
        this.chestLoot = new Map();
        this.ruinCenters = new Set();
        this.overworldStructureCenters = new Set();
        this.netherStructureCenters = new Set();
        this.materials = this.initMaterials();

        // Authentic Minecraft black block wireframe highlighter
        this.highlighter = new THREE.LineSegments(
            new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002, 1.002, 1.002)),
            new THREE.LineBasicMaterial({
                color: 0x000000,
                linewidth: 2,
                transparent: true,
                opacity: 0.70,
                depthTest: true,
                depthWrite: false
            })
        );
        this.highlighter.renderOrder = 999;
        this.highlighter.visible = false;
        this.scene.add(this.highlighter);

        // Authentic Minecraft 10-stage crack textures and break overlay
        this.crackTextures = this.createCrackTextures();
        const breakMat = new THREE.MeshBasicMaterial({
            transparent: true,
            opacity: 0.88,
            depthWrite: false,
            polygonOffset: true,
            polygonOffsetFactor: -2,
            polygonOffsetUnits: -2
        });
        this.breakOverlay = new THREE.Mesh(new THREE.BoxGeometry(1.004, 1.004, 1.004), breakMat);
        this.breakOverlay.renderOrder = 1000;
        this.breakOverlay.visible = false;
        this.scene.add(this.breakOverlay);
    }

    createCrackTextures(): THREE.Texture[] {
        const textures: THREE.Texture[] = [];
        const size = 16;
        const crackPoints: Array<{ x: number; y: number; stage: number }> = [
            // Stage 0: central impact mark
            { x: 7, y: 7, stage: 0 }, { x: 8, y: 7, stage: 0 }, { x: 8, y: 8, stage: 0 },
            // Stage 1: initial fissure
            { x: 6, y: 8, stage: 1 }, { x: 9, y: 6, stage: 1 }, { x: 7, y: 6, stage: 1 }, { x: 8, y: 9, stage: 1 },
            // Stage 2: primary arms extending
            { x: 5, y: 9, stage: 2 }, { x: 10, y: 5, stage: 2 }, { x: 6, y: 5, stage: 2 }, { x: 9, y: 10, stage: 2 }, { x: 7, y: 10, stage: 2 },
            // Stage 3: branching to quadrant 2 & 4
            { x: 4, y: 10, stage: 3 }, { x: 11, y: 4, stage: 3 }, { x: 5, y: 4, stage: 3 }, { x: 10, y: 11, stage: 3 }, { x: 4, y: 7, stage: 3 }, { x: 11, y: 8, stage: 3 },
            // Stage 4: cracks reaching toward boundaries
            { x: 3, y: 11, stage: 4 }, { x: 12, y: 3, stage: 4 }, { x: 4, y: 3, stage: 4 }, { x: 12, y: 11, stage: 4 }, { x: 3, y: 6, stage: 4 }, { x: 12, y: 9, stage: 4 }, { x: 8, y: 12, stage: 4 }, { x: 7, y: 3, stage: 4 },
            // Stage 5: diagonal splits
            { x: 2, y: 12, stage: 5 }, { x: 13, y: 2, stage: 5 }, { x: 3, y: 2, stage: 5 }, { x: 13, y: 12, stage: 5 }, { x: 2, y: 5, stage: 5 }, { x: 13, y: 8, stage: 5 }, { x: 9, y: 13, stage: 5 }, { x: 6, y: 2, stage: 5 }, { x: 5, y: 12, stage: 5 }, { x: 10, y: 3, stage: 5 },
            // Stage 6: wide cross-cracks
            { x: 1, y: 13, stage: 6 }, { x: 14, y: 1, stage: 6 }, { x: 2, y: 1, stage: 6 }, { x: 14, y: 13, stage: 6 }, { x: 1, y: 4, stage: 6 }, { x: 14, y: 7, stage: 6 }, { x: 10, y: 14, stage: 6 }, { x: 5, y: 1, stage: 6 }, { x: 6, y: 13, stage: 6 }, { x: 11, y: 2, stage: 6 }, { x: 8, y: 4, stage: 6 }, { x: 7, y: 11, stage: 6 },
            // Stage 7: secondary fissures
            { x: 0, y: 14, stage: 7 }, { x: 15, y: 0, stage: 7 }, { x: 1, y: 0, stage: 7 }, { x: 15, y: 14, stage: 7 }, { x: 0, y: 3, stage: 7 }, { x: 15, y: 6, stage: 7 }, { x: 11, y: 15, stage: 7 }, { x: 4, y: 0, stage: 7 }, { x: 8, y: 14, stage: 7 }, { x: 12, y: 1, stage: 7 }, { x: 3, y: 8, stage: 7 }, { x: 12, y: 7, stage: 7 }, { x: 9, y: 3, stage: 7 }, { x: 6, y: 12, stage: 7 },
            // Stage 8: heavy fragmentation
            { x: 0, y: 15, stage: 8 }, { x: 15, y: 1, stage: 8 }, { x: 0, y: 1, stage: 8 }, { x: 15, y: 15, stage: 8 }, { x: 0, y: 2, stage: 8 }, { x: 15, y: 5, stage: 8 }, { x: 12, y: 15, stage: 8 }, { x: 3, y: 0, stage: 8 }, { x: 9, y: 15, stage: 8 }, { x: 13, y: 0, stage: 8 }, { x: 2, y: 7, stage: 8 }, { x: 13, y: 6, stage: 8 }, { x: 10, y: 2, stage: 8 }, { x: 5, y: 13, stage: 8 }, { x: 6, y: 7, stage: 8 }, { x: 9, y: 8, stage: 8 },
            // Stage 9: complete shattered web
            { x: 1, y: 15, stage: 9 }, { x: 14, y: 0, stage: 9 }, { x: 2, y: 0, stage: 9 }, { x: 14, y: 15, stage: 9 }, { x: 0, y: 4, stage: 9 }, { x: 15, y: 7, stage: 9 }, { x: 13, y: 14, stage: 9 }, { x: 2, y: 2, stage: 9 }, { x: 7, y: 15, stage: 9 }, { x: 14, y: 2, stage: 9 }, { x: 1, y: 8, stage: 9 }, { x: 14, y: 5, stage: 9 }, { x: 11, y: 1, stage: 9 }, { x: 4, y: 14, stage: 9 }, { x: 5, y: 6, stage: 9 }, { x: 10, y: 9, stage: 9 }, { x: 8, y: 2, stage: 9 }, { x: 7, y: 13, stage: 9 }
        ];

        for (let s = 0; s < 10; s++) {
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d')!;
            ctx.clearRect(0, 0, size, size);

            for (const pt of crackPoints) {
                if (pt.stage <= s) {
                    ctx.fillStyle = 'rgba(10, 10, 10, 0.95)';
                    ctx.fillRect(pt.x, pt.y, 1, 1);
                    if (pt.x + 1 < size && !crackPoints.some(p => p.stage <= s && p.x === pt.x + 1 && p.y === pt.y)) {
                        ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
                        ctx.fillRect(pt.x + 1, pt.y, 1, 1);
                    }
                }
            }

            const tex = new THREE.CanvasTexture(canvas);
            tex.colorSpace = THREE.SRGBColorSpace;
            tex.magFilter = THREE.NearestFilter;
            tex.minFilter = THREE.NearestFilter;
            tex.generateMipmaps = false;
            tex.needsUpdate = true;
            textures.push(tex);
        }

        return textures;
    }

    setHighlightBlock(bx: number, by: number, bz: number) {
        this.highlighter.position.set(bx + 0.5, by + 0.5, bz + 0.5);
        this.highlighter.visible = true;
    }

    hideHighlight() {
        this.highlighter.visible = false;
    }

    setBreakStage(bx: number, by: number, bz: number, stage: number) {
        if (stage < 0 || stage >= this.crackTextures.length) {
            this.breakOverlay.visible = false;
            return;
        }
        this.breakOverlay.position.set(bx + 0.5, by + 0.5, bz + 0.5);
        (this.breakOverlay.material as THREE.MeshBasicMaterial).map = this.crackTextures[stage];
        (this.breakOverlay.material as THREE.MeshBasicMaterial).needsUpdate = true;
        this.breakOverlay.visible = true;
    }

    hideBreakOverlay() {
        this.breakOverlay.visible = false;
    }

    createChunkFromData(cx: number, cz: number, data: Uint8Array): Chunk | null {
        if (!(data instanceof Uint8Array)) return null;
        const expected = CONFIG.CHUNK_SIZE * CONFIG.CHUNK_HEIGHT * CONFIG.CHUNK_SIZE;
        if (data.length !== expected) return null;
        const chunk = new Chunk(cx, cz);
        chunk.data = data.slice();
        chunk.isDirty = true;
        return chunk;
    }

    createWaterTexture(): THREE.CanvasTexture {
        const size = 32;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d')!;

        // Authentic Minecraft flowing water with soft surface crests
        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const w1 = Math.sin((x / size) * Math.PI * 4 + (y / size) * Math.PI * 2);
                const w2 = Math.cos((y / size) * Math.PI * 4 - (x / size) * Math.PI * 2);
                const noise = ((Math.sin(x * 9.1 + y * 13.7) * 43758.5453) % 1 + 1) % 1;
                const wave = (w1 + w2) * 0.5 * 0.4 + noise * 0.2 + 0.5;

                let r: number, g: number, b: number, a: number;
                if (wave < 0.35) {
                    r = 43; g = 82; b = 165; a = 0.82; // Deep shadow blue
                } else if (wave < 0.65) {
                    r = 55; g = 105; b = 210; a = 0.78; // Base Minecraft ocean blue
                } else if (wave < 0.85) {
                    r = 75; g = 135; b = 240; a = 0.80; // Water ripple crest
                } else {
                    r = 110; g = 170; b = 255; a = 0.86; // Foam glint
                }
                ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
                ctx.fillRect(x, y, 1, 1);
            }
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.generateMipmaps = false;
        tex.needsUpdate = true;
        return tex;
    }

    createLavaTexture(): THREE.CanvasTexture {
        const size = 32;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d')!;

        // Authentic Minecraft molten magma with fiery ripples and basalt eddies
        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const w = Math.sin((x / size) * Math.PI * 3 + (y / size) * Math.PI * 3);
                const noise = ((Math.sin(x * 7.3 + y * 11.2) * 43758.5453) % 1 + 1) % 1;
                const heat = w * 0.3 + noise * 0.3 + 0.5;

                let r = 240, g = 90, b = 10;
                if (heat > 0.80) {
                    r = 255; g = 225; b = 60; // Golden yellow crest
                } else if (heat > 0.55) {
                    r = 255; g = 145; b = 20; // Radiant orange
                } else if (heat > 0.30) {
                    r = 215; g = 60; b = 10;  // Fiery crimson
                } else {
                    r = 140; g = 25; b = 5;   // Basalt crust
                }
                ctx.fillStyle = `rgb(${r},${g},${b})`;
                ctx.fillRect(x, y, 1, 1);
            }
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.generateMipmaps = false;
        tex.needsUpdate = true;
        return tex;
    }

    createPortalTexture(): THREE.CanvasTexture {
        const size = 32;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d')!;

        // Authentic Minecraft Nether Portal: cosmic violet vortex
        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const angle = Math.atan2(y - 16, x - 16);
                const dist = Math.sqrt((x - 16) ** 2 + (y - 16) ** 2);
                const swirl = Math.sin(angle * 3 + dist * 0.4);
                const noise = ((Math.sin(x * 13.3 + y * 7.1) * 43758.5453) % 1 + 1) % 1;
                const v = swirl * 0.4 + noise * 0.3 + 0.5;

                let r = 70, g = 15, b = 130;
                if (v > 0.72) {
                    r = 225; g = 135; b = 255;
                } else if (v > 0.45) {
                    r = 155; g = 45; b = 225;
                } else {
                    r = 65; g = 15; b = 115;
                }
                ctx.fillStyle = `rgba(${r},${g},${b},0.82)`;
                ctx.fillRect(x, y, 1, 1);
            }
        }

        const tex = new THREE.CanvasTexture(canvas);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.generateMipmaps = false;
        tex.needsUpdate = true;
        return tex;
    }

    updateWaterAnimation(dt: number) {
        if (this.waterTexture) {
            this.waterTexture.offset.x = (this.waterTexture.offset.x + dt * 0.045) % 1;
            this.waterTexture.offset.y = (this.waterTexture.offset.y + dt * 0.065) % 1;
        }
        if (this.lavaTexture) {
            this.lavaTexture.offset.y = (this.lavaTexture.offset.y + dt * 0.02) % 1;
        }
        if (this.portalTexture) {
            this.portalTexture.offset.x = (this.portalTexture.offset.x + dt * 0.08) % 1;
            this.portalTexture.offset.y = (this.portalTexture.offset.y + dt * 0.12) % 1;
        }
    }

    initMaterials(): Record<number, THREE.Material | THREE.Material[]> {
        const mats: Record<number, THREE.Material | THREE.Material[]> = {};
        const makeLambert = (map: THREE.Texture | null, transparent = false, opacity = 1, alphaTest = 0) => {
            return new THREE.MeshLambertMaterial({
                map,
                color: 0xffffff,
                emissive: 0x000000,
                emissiveIntensity: 0,
                transparent,
                opacity,
                alphaTest,
                depthWrite: !transparent || alphaTest > 0,
                flatShading: false,
                fog: true
            });
        };

        for (const [idStr, def] of Object.entries(BLOCK_DEFS)) {
            const id = Number(idStr);
            if (id === BLOCK_ID.AIR) continue;

            const useTexture = id !== BLOCK_ID.WATER && id !== BLOCK_ID.LAVA && id !== BLOCK_ID.NETHER_PORTAL;
            if (id === BLOCK_ID.WATER) {
                this.waterTexture = this.createWaterTexture();
                mats[id] = new THREE.MeshPhongMaterial({
                    map: this.waterTexture,
                    color: 0xffffff,
                    emissive: 0x143472,
                    emissiveIntensity: 0.35,
                    transparent: true,
                    opacity: 0.75,
                    shininess: 90,
                    specular: 0x90c2ff,
                    depthWrite: false,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else if (id === BLOCK_ID.LAVA) {
                this.lavaTexture = this.createLavaTexture();
                mats[id] = new THREE.MeshPhongMaterial({
                    map: this.lavaTexture,
                    color: 0xff6600,
                    emissive: 0xd03000,
                    emissiveIntensity: 1.0,
                    transparent: false,
                    opacity: 1.0,
                    shininess: 60,
                    specular: 0xffaa55,
                    depthWrite: true,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else if (id === BLOCK_ID.NETHER_PORTAL) {
                this.portalTexture = this.createPortalTexture();
                mats[id] = new THREE.MeshPhongMaterial({
                    map: this.portalTexture,
                    color: 0xffffff,
                    emissive: 0x42186f,
                    emissiveIntensity: 0.95,
                    transparent: true,
                    opacity: 0.76,
                    shininess: 70,
                    specular: 0xb088ff,
                    depthWrite: false,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else if (id === BLOCK_ID.GRASS) {
                const side = this.createBlockTexture(id, def.color, 'side');
                const top = this.createBlockTexture(id, def.color, 'top');
                const bottom = this.createBlockTexture(BLOCK_ID.DIRT, BLOCK_DEFS[BLOCK_ID.DIRT].color, 'default');
                mats[id] = [
                    makeLambert(side, false, 1, 0),
                    makeLambert(side, false, 1, 0),
                    makeLambert(top, false, 1, 0),
                    makeLambert(bottom, false, 1, 0),
                    makeLambert(side, false, 1, 0),
                    makeLambert(side, false, 1, 0)
                ];
            } else if (id === BLOCK_ID.LOG || id === BLOCK_ID.CACTUS || id === BLOCK_ID.BAMBOO) {
                const side = this.createBlockTexture(id, def.color, 'side');
                const top = this.createBlockTexture(id, def.color, 'top');
                mats[id] = [
                    makeLambert(side, false, 1, 0),
                    makeLambert(side, false, 1, 0),
                    makeLambert(top, false, 1, 0),
                    makeLambert(top, false, 1, 0),
                    makeLambert(side, false, 1, 0),
                    makeLambert(side, false, 1, 0)
                ];
            } else if (id === BLOCK_ID.CHEST) {
                const front = this.createBlockTexture(id, def.color, 'front');
                const side = this.createBlockTexture(id, def.color, 'side');
                const top = this.createBlockTexture(id, def.color, 'side');
                mats[id] = [
                    makeLambert(side, false, 1, 0),
                    makeLambert(side, false, 1, 0),
                    makeLambert(top, false, 1, 0),
                    makeLambert(top, false, 1, 0),
                    makeLambert(front, false, 1, 0),
                    makeLambert(side, false, 1, 0)
                ];
            } else if (id === BLOCK_ID.LEAVES || id === BLOCK_ID.CHERRY_LEAVES || id === BLOCK_ID.RED_LEAVES) {
                const map = this.createBlockTexture(id, def.color, 'default');
                mats[id] = new THREE.MeshLambertMaterial({
                    map,
                    color: 0xffffff,
                    transparent: true,
                    alphaTest: 0.35,
                    depthWrite: true,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else if (id === BLOCK_ID.GLASS) {
                const map = this.createBlockTexture(id, def.color, 'default');
                mats[id] = new THREE.MeshLambertMaterial({
                    map,
                    color: 0xffffff,
                    transparent: true,
                    alphaTest: 0.05,
                    depthWrite: false,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else if (id === BLOCK_ID.TALL_GRASS || id === BLOCK_ID.FLOWER_RED || id === BLOCK_ID.FLOWER_YELLOW) {
                const map = this.createBlockTexture(id, def.color, 'plant');
                mats[id] = new THREE.MeshLambertMaterial({
                    map,
                    color: 0xffffff,
                    transparent: true,
                    alphaTest: 0.25,
                    depthWrite: true,
                    side: THREE.DoubleSide,
                    fog: true
                });
            } else {
                const map = useTexture ? this.createBlockTexture(id, def.color, 'default') : null;
                mats[id] = makeLambert(map, def.transparent, def.opacity, def.transparent ? 0.08 : 0);
            }
        }
        return mats;
    }

    createBlockTexture(id: number, baseHex: number, variant = 'default'): THREE.Texture {
        return createMinecraftTexture(id, variant as any);
    }

    isNetherWorldX(wx: number): boolean {
        return wx >= CONFIG.NETHER_OFFSET_X;
    }

    isNetherChunk(cx: number): boolean {
        const startX = cx * CONFIG.CHUNK_SIZE;
        const endX = startX + CONFIG.CHUNK_SIZE - 1;
        return endX >= CONFIG.NETHER_OFFSET_X;
    }

    getVoxel(wx: number, wy: number, wz: number): number {
        const { cx, cz } = MathKernel.getChunkCoords(wx, wz);
        const key = `${cx},${cz}`;
        const chunk = this.chunks.get(key);
        const { lx, lz } = MathKernel.getLocalCoords(wx, wy, wz);
        if (!chunk) {
            const archived = this.chunkArchive.get(key);
            if (!archived) return 0;
            if (wy < 0 || wy >= CONFIG.CHUNK_HEIGHT) return 0;
            const index = lx + (wy * CONFIG.CHUNK_SIZE) + (lz * CONFIG.CHUNK_SIZE * CONFIG.CHUNK_HEIGHT);
            return archived[index] || 0;
        }
        return chunk.getBlock(lx, wy, lz);
    }

    setVoxelRaw(wx: number, wy: number, wz: number, id: number, dirtyChunks: Set<string> | null = null): boolean {
        if (wy < 0 || wy >= CONFIG.CHUNK_HEIGHT) return false;
        const { cx, cz } = MathKernel.getChunkCoords(wx, wz);
        const key = `${cx},${cz}`;
        let chunk = this.chunks.get(key);
        if (!chunk) {
            chunk = new Chunk(cx, cz);
            this.chunks.set(key, chunk);
        }
        const { lx, lz } = MathKernel.getLocalCoords(wx, wy, wz);
        const prev = chunk.getBlock(lx, wy, lz);
        if (prev === id) return false;
        chunk.setBlock(lx, wy, lz, id);
        if (dirtyChunks) dirtyChunks.add(`${cx},${cz}`);
        return true;
    }

    setVoxel(wx: number, wy: number, wz: number, id: number, allowBedrock = false) {
        if (wy < 0 || wy >= CONFIG.CHUNK_HEIGHT) return;
        const current = this.getVoxel(wx, wy, wz);
        if (current === BLOCK_ID.BEDROCK && id !== BLOCK_ID.BEDROCK && !allowBedrock) return;

        const dirtyChunks = new Set<string>();
        const changed = this.setVoxelRaw(wx, wy, wz, id, dirtyChunks);
        if (!changed) return;

        const { cx, cz } = MathKernel.getChunkCoords(wx, wz);
        this.meshBuildQueued.delete(`${cx},${cz}`);
        this.refreshMesh(cx, cz);

        // Notify neighbor chunks if the voxel lies on a chunk boundary
        const { lx, lz } = MathKernel.getLocalCoords(wx, wy, wz);
        if (lx === 0) {
            this.meshBuildQueued.delete(`${cx - 1},${cz}`);
            this.refreshMesh(cx - 1, cz);
        }
        if (lx === CONFIG.CHUNK_SIZE - 1) {
            this.meshBuildQueued.delete(`${cx + 1},${cz}`);
            this.refreshMesh(cx + 1, cz);
        }
        if (lz === 0) {
            this.meshBuildQueued.delete(`${cx},${cz - 1}`);
            this.refreshMesh(cx, cz - 1);
        }
        if (lz === CONFIG.CHUNK_SIZE - 1) {
            this.meshBuildQueued.delete(`${cx},${cz + 1}`);
            this.refreshMesh(cx, cz + 1);
        }
    }

    findSurfaceY(wx: number, wz: number, startY = CONFIG.CHUNK_HEIGHT - 1): number {
        for (let y = Math.min(startY, CONFIG.CHUNK_HEIGHT - 1); y >= 1; y--) {
            const id = this.getVoxel(wx, y, wz);
            const def = BLOCK_DEFS[id];
            if (!def || !def.solid) continue;
            if (id === BLOCK_ID.LEAVES || id === BLOCK_ID.BAMBOO || id === BLOCK_ID.CACTUS) continue;
            return y;
        }
        return 1;
    }

    findSafeSpawnSurface(startX = 0, startZ = 0): { x: number; y: number; z: number } {
        // Spiral scan outwardly to guarantee a safe, open surface under the sky on lush green grass
        for (let r = 0; r <= 64; r += 2) {
            const steps = r === 0 ? 1 : Math.max(8, r * 4);
            for (let s = 0; s < steps; s++) {
                const angle = (s / steps) * Math.PI * 2;
                const wx = Math.round(startX + Math.cos(angle) * r);
                const wz = Math.round(startZ + Math.sin(angle) * r);

                const biome = this.synthesizer.getBiomeType(wx, wz);
                // Guaranteed lush green biome for spawn (Plains or Forest)
                if (biome !== 'PLAINS' && biome !== 'FOREST' && biome !== 'SUNFLOWER_PLAINS' && biome !== 'BIRCH_FOREST') continue;

                const h = this.synthesizer.getHeight(wx, wz);
                if (h < CONFIG.WATER_LEVEL + 2) continue;

                const { cx, cz } = MathKernel.getChunkCoords(wx, wz);
                if (!this.chunks.has(`${cx},${cz}`)) {
                    this.generateChunk(cx, cz, true);
                }

                const surfaceY = this.findSurfaceY(wx, wz);
                if (surfaceY < CONFIG.WATER_LEVEL + 2) continue;

                const under = this.getVoxel(wx, surfaceY, wz);
                // Ensure player spawns directly on lush green grass!
                if (under !== BLOCK_ID.GRASS) continue;

                // Open sky check: at least 6 blocks of clear air above player
                let clearSky = true;
                for (let dy = 1; dy <= 6; dy++) {
                    const above = this.getVoxel(wx, surfaceY + dy, wz);
                    if (above !== BLOCK_ID.AIR && above !== BLOCK_ID.TALL_GRASS && above !== BLOCK_ID.FLOWER_RED && above !== BLOCK_ID.FLOWER_YELLOW) {
                        clearSky = false;
                        break;
                    }
                }

                if (clearSky) {
                    return { x: wx, y: surfaceY, z: wz };
                }
            }
        }

        const fallbackH = Math.max(CONFIG.WATER_LEVEL + 3, this.synthesizer.getHeight(0, 0));
        return { x: 0, y: fallbackH, z: 0 };
    }

    generateChunk(cx: number, cz: number, immediateMesh = false) {
        const key = `${cx},${cz}`;
        let chunk = this.chunks.get(key);
        if (chunk && chunk.isGenerated) return;

        if (this.chunkArchive.has(key)) {
            if (!chunk) {
                chunk = new Chunk(cx, cz);
                this.chunks.set(key, chunk);
            }
            chunk.data.set(this.chunkArchive.get(key)!);
            chunk.isGenerated = true;
            chunk.isDirty = true;
            if (immediateMesh) this.refreshMesh(cx, cz);
            else this.requestMeshRebuild(cx, cz);
            return;
        }

        if (!chunk) {
            chunk = new Chunk(cx, cz);
            this.chunks.set(key, chunk);
        }

        const treePositions: { x: number; z: number }[] = [];

        for (let x = 0; x < CONFIG.CHUNK_SIZE; x++) {
            for (let z = 0; z < CONFIG.CHUNK_SIZE; z++) {
                const wx = cx * CONFIG.CHUNK_SIZE + x;
                const wz = cz * CONFIG.CHUNK_SIZE + z;
                const h = this.synthesizer.getHeight(wx, wz);
                const climate = this.synthesizer.getClimate(wx, wz, h);
                const biome = this.synthesizer.getBiomeType(wx, wz, h);

                for (let y = 0; y <= Math.max(h, CONFIG.WATER_LEVEL); y++) {
                    // Do not overwrite pre-existing non-air blocks placed by neighboring structures or trees
                    if (chunk.getBlock(x, y, z) !== BLOCK_ID.AIR) continue;

                    if (y === 0) {
                        chunk.setBlock(x, y, z, BLOCK_ID.BEDROCK);
                        continue;
                    }

                    // Minecraft authentic caves & ravines: ONLY deep underground (y <= 22 and y < h - 8)
                    // The surface, mountains, hills, and all terrain above y = 22 are 100% SOLID ROCK & ORES!
                    // Eliminates any hollow mountains or hollow terrain completely!
                    if (y <= 22 && y < h - 8 && (this.synthesizer.hasCave(wx, y, wz, h) || this.synthesizer.hasRavine(wx, y, wz, h))) {
                        if (y <= 7) {
                            chunk.setBlock(x, y, z, BLOCK_ID.LAVA);
                        } else {
                            chunk.setBlock(x, y, z, BLOCK_ID.AIR);
                        }
                        continue;
                    }

                    if (y > h) {
                        // Water only exists in Oceans, Beaches, and dedicated Swamp channels below sea level
                        if (y <= CONFIG.WATER_LEVEL && (biome === 'OCEAN' || biome === 'BEACH' || (biome === 'SWAMP' && h < CONFIG.WATER_LEVEL))) {
                            chunk.setBlock(x, y, z, BLOCK_ID.WATER);
                        }
                        continue;
                    }

                    // Solid underground: Stone and Minecraft Ore Veins
                    if (y < h - 4) {
                        if (y <= 14 && Math.random() < 0.0035) {
                            chunk.setBlock(x, y, z, BLOCK_ID.DIAMOND_ORE);
                        } else if (y <= 16 && Math.random() < 0.008) {
                            chunk.setBlock(x, y, z, BLOCK_ID.REDSTONE_ORE);
                        } else if (y <= 28 && Math.random() < 0.006) {
                            chunk.setBlock(x, y, z, BLOCK_ID.GOLD_ORE);
                        } else if (y >= 10 && y <= 28 && Math.random() < 0.005) {
                            chunk.setBlock(x, y, z, BLOCK_ID.LAPIS_ORE);
                        } else if (y <= 48 && Math.random() < 0.015) {
                            chunk.setBlock(x, y, z, BLOCK_ID.IRON_ORE);
                        } else if (y <= 64 && Math.random() < 0.022) {
                            chunk.setBlock(x, y, z, BLOCK_ID.COAL_ORE);
                        } else if ((climate.isAlpinePeak || climate.isSnowyPeak || biome === 'MOUNTAINS' || biome === 'SNOWY_SLOPES') && y >= 35 && Math.random() < 0.008) {
                            chunk.setBlock(x, y, z, BLOCK_ID.EMERALD_ORE);
                        } else {
                            chunk.setBlock(x, y, z, BLOCK_ID.STONE);
                        }
                    } else if (y < h) {
                        // Subsurface (h - 4 to h - 1)
                        if (h >= 52 && (climate.isAlpinePeak || climate.isSnowyPeak)) {
                            // High rocky mountain subsurface
                            chunk.setBlock(x, y, z, BLOCK_ID.STONE);
                        } else if (climate.desertWeight > 0.65) {
                            chunk.setBlock(x, y, z, BLOCK_ID.SAND);
                        } else if (climate.desertWeight > 0.15) {
                            // Desert ecotone subsurface: organic blend
                            const blendNoise = this.synthesizer.detailNoise.noise2D(wx * 0.12, wz * 0.12);
                            const isSandSub = (climate.desertWeight + blendNoise * 0.3) > 0.48;
                            chunk.setBlock(x, y, z, isSandSub ? BLOCK_ID.SAND : BLOCK_ID.DIRT);
                        } else if (biome === 'BEACH' || biome === 'BADLANDS') {
                            chunk.setBlock(x, y, z, BLOCK_ID.SAND);
                        } else {
                            chunk.setBlock(x, y, z, BLOCK_ID.DIRT);
                        }
                    } else {
                        // Surface block (y === h)
                        if (h < CONFIG.WATER_LEVEL) {
                            // Underwater floor
                            if (biome === 'OCEAN' || biome === 'BEACH') {
                                chunk.setBlock(x, y, z, Math.random() < 0.7 ? BLOCK_ID.SAND : BLOCK_ID.GRAVEL);
                            } else if (biome === 'SWAMP') {
                                chunk.setBlock(x, y, z, Math.random() < 0.25 ? BLOCK_ID.CLAY : BLOCK_ID.DIRT);
                            } else {
                                chunk.setBlock(x, y, z, BLOCK_ID.DIRT);
                            }
                        } else if (climate.isSnowyPeak || (h >= 58 && climate.isAlpinePeak)) {
                            // 1. Towering Snowy Peaks (including near desert edges!)
                            chunk.setBlock(x, y, z, BLOCK_ID.SNOW);
                        } else if (h >= 50 && climate.isAlpinePeak) {
                            // 2. Scree slope / rocky mountain transition
                            const screeRoll = MathKernel.hash2(wx * 4.3 + 12.1, wz * 4.3 - 21.7);
                            if (screeRoll > 0.52) {
                                chunk.setBlock(x, y, z, BLOCK_ID.STONE);
                            } else if (screeRoll > 0.26) {
                                chunk.setBlock(x, y, z, BLOCK_ID.GRAVEL);
                            } else {
                                chunk.setBlock(x, y, z, h >= 54 ? BLOCK_ID.SNOW : (climate.desertWeight > 0.4 ? BLOCK_ID.SAND : BLOCK_ID.GRASS));
                            }
                        } else if (climate.snowWeight > 0.65) {
                            // 3. Cold Snowy Plains / Taiga
                            chunk.setBlock(x, y, z, BLOCK_ID.SNOW);
                        } else if (climate.snowWeight > 0.20) {
                            // Cold transition fringe (snow dusting on grass)
                            const snowDither = this.synthesizer.detailNoise.noise2D(wx * 0.10, wz * 0.10);
                            const isSnow = (climate.snowWeight + snowDither * 0.35) > 0.50;
                            chunk.setBlock(x, y, z, isSnow ? BLOCK_ID.SNOW : BLOCK_ID.GRASS);
                        } else if (climate.desertWeight > 0.65) {
                            // 4. Pure Desert
                            chunk.setBlock(x, y, z, BLOCK_ID.SAND);
                        } else if (climate.desertWeight > 0.15) {
                            // 5. Desert to Plains/Grassland Ecotone (wavy natural sand/grass transition)
                            const blendNoise = this.synthesizer.detailNoise.noise2D(wx * 0.12, wz * 0.12);
                            const isSand = (climate.desertWeight + blendNoise * 0.35) > 0.48;
                            chunk.setBlock(x, y, z, isSand ? BLOCK_ID.SAND : BLOCK_ID.GRASS);
                        } else if (biome === 'BEACH' || biome === 'BADLANDS') {
                            chunk.setBlock(x, y, z, BLOCK_ID.SAND);
                        } else {
                            // 6. Lush green grass
                            chunk.setBlock(x, y, z, BLOCK_ID.GRASS);
                        }
                    }
                }

                // Surface Flora & Biome Vegetation (only placed above water on solid ground)
                const groundBlock = chunk.getBlock(x, h, z);
                if (h >= CONFIG.WATER_LEVEL && (groundBlock === BLOCK_ID.GRASS || groundBlock === BLOCK_ID.SAND || groundBlock === BLOCK_ID.SNOW)) {
                    const topY = h + 1;
                    const canTree = (groundBlock === BLOCK_ID.GRASS || groundBlock === BLOCK_ID.SNOW) &&
                        h < 50 && // Alpine tree line: no trees on high rocky/snowy summits!
                        treePositions.every(t => Math.hypot(t.x - x, t.z - z) >= 4);

                    // Smooth Forest to Plains transition!
                    if (groundBlock === BLOCK_ID.GRASS && climate.desertWeight < 0.25 && h < 50) {
                        // Tree density scales continuously from 0.002 (open plains) to 0.052 (dense forest)
                        const treeChance = MathKernel.lerp(0.002, 0.052, Math.pow(climate.forestWeight, 1.35));
                        const roll = Math.random();

                        if (roll < treeChance && canTree) {
                            treePositions.push({ x, z });
                            if (climate.variation < -0.35 && climate.forestWeight > 0.5) {
                                this.buildCherryTree(chunk, cx, cz, x, topY, z);
                            } else if (climate.variation < -0.05 && climate.forestWeight > 0.3) {
                                this.buildBirchTree(chunk, cx, cz, x, topY, z);
                            } else if (climate.variation > 0.35 && climate.forestWeight > 0.6) {
                                this.buildDarkOakTree(chunk, cx, cz, x, topY, z);
                            } else {
                                this.buildOakTree(chunk, cx, cz, x, topY, z);
                            }
                        } else {
                            // Flora density: plains are rich in yellow & red flowers; forest has shaded tall grass
                            const rollFlora = Math.random();
                            const dandelionChance = MathKernel.lerp(0.18, 0.03, climate.forestWeight);
                            const poppyChance = MathKernel.lerp(0.14, 0.04, climate.forestWeight);
                            const tallGrassChance = MathKernel.lerp(0.24, 0.16, climate.forestWeight);

                            if (rollFlora < dandelionChance) {
                                chunk.setBlock(x, topY, z, BLOCK_ID.FLOWER_YELLOW);
                            } else if (rollFlora < dandelionChance + poppyChance) {
                                chunk.setBlock(x, topY, z, BLOCK_ID.FLOWER_RED);
                            } else if (rollFlora < dandelionChance + poppyChance + tallGrassChance) {
                                chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                            }
                        }
                    } else if (groundBlock === BLOCK_ID.SAND) {
                        // Desert & Desert Edge
                        if (climate.desertWeight > 0.65) {
                            if (Math.random() < 0.016 && x > 1 && x < CONFIG.CHUNK_SIZE - 2 && z > 1 && z < CONFIG.CHUNK_SIZE - 2) {
                                this.buildCactus(chunk, x, topY, z);
                            }
                        } else {
                            // Desert fringe: dry tall grass tufts
                            if (Math.random() < 0.08) {
                                chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                            }
                        }
                    } else if (biome === 'SAVANNA') {
                        if (Math.random() < 0.022 && canTree) {
                            treePositions.push({ x, z });
                            this.buildAcaciaTree(chunk, cx, cz, x, topY, z);
                        } else if (Math.random() < 0.12) {
                            chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                        }
                    } else if (biome === 'JUNGLE') {
                        if (Math.random() < 0.04 && canTree) {
                            treePositions.push({ x, z });
                            this.buildJungleTree(chunk, cx, cz, x, topY, z);
                        } else if (Math.random() < 0.09) {
                            this.buildBambooStalk(chunk, x, topY, z);
                        } else if (Math.random() < 0.20) {
                            chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                        }
                    } else if (biome === 'SWAMP') {
                        if (Math.random() < 0.035 && canTree) {
                            treePositions.push({ x, z });
                            this.buildSwampTree(chunk, cx, cz, x, topY, z);
                        } else if (Math.random() < 0.14) {
                            chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                        }
                    } else if (biome === 'TAIGA' || biome === 'SNOWY_TAIGA' || biome === 'SNOWY_PLAINS') {
                        const spruceChance = (biome === 'SNOWY_PLAINS') ? 0.012 : 0.045;
                        if (Math.random() < spruceChance && canTree) {
                            treePositions.push({ x, z });
                            this.buildSpruceTree(chunk, cx, cz, x, topY, z);
                        } else if (Math.random() < 0.10) {
                            chunk.setBlock(x, topY, z, BLOCK_ID.TALL_GRASS);
                        }
                    }
                }
            }
        }

        chunk.isGenerated = true;
        chunk.isDirty = true;
        this.chunks.set(key, chunk);

        // Minecraft Structure Placement (Villages, Temples, Ruined Portals, Dungeons, Witch Huts)
        this.checkAndSpawnStructures(cx, cz);

        if (immediateMesh) this.refreshMesh(cx, cz);
        else this.requestMeshRebuild(cx, cz);

        // Rebuild existing neighbor chunks so that boundary walls cull against the newly placed blocks
        if (this.chunks.has(`${cx - 1},${cz}`)) this.requestMeshRebuild(cx - 1, cz);
        if (this.chunks.has(`${cx + 1},${cz}`)) this.requestMeshRebuild(cx + 1, cz);
        if (this.chunks.has(`${cx},${cz - 1}`)) this.requestMeshRebuild(cx, cz - 1);
        if (this.chunks.has(`${cx},${cz + 1}`)) this.requestMeshRebuild(cx, cz + 1);
    }

    checkAndSpawnStructures(cx: number, cz: number) {
        // Protect spawn chunks (cx: 0, cz: 0 and immediate neighbors) from sudden disruptive structure overlaps
        if (Math.abs(cx) <= 1 && Math.abs(cz) <= 1) return;

        const grid = 6;
        const gx = Math.floor(cx / grid);
        const gz = Math.floor(cz / grid);
        const hsh = MathKernel.hash2(gx * 53.7 + CONFIG.SEED, gz * 71.9 + CONFIG.SEED);
        const targetCx = gx * grid + Math.floor(hsh * (grid - 2)) + 1;
        const targetCz = gz * grid + Math.floor(((hsh * 100) % 1) * (grid - 2)) + 1;

        if (cx === targetCx && cz === targetCz) {
            const centerWx = cx * CONFIG.CHUNK_SIZE + 4;
            const centerWz = cz * CONFIG.CHUNK_SIZE + 4;
            const biome = this.synthesizer.getBiomeType(centerWx, centerWz);
            const surfaceY = this.findSurfaceY(centerWx, centerWz);

            if (surfaceY > CONFIG.WATER_LEVEL + 1) {
                const dirtyChunks = new Set<string>();
                if (biome === 'DESERT') {
                    if (hsh > 0.45) {
                        StructureGenerator.buildDesertTemple(this, centerWx, surfaceY, centerWz, dirtyChunks);
                    } else {
                        StructureGenerator.buildRuinedPortal(this, centerWx, surfaceY, centerWz, dirtyChunks);
                    }
                } else if (biome === 'SWAMP') {
                    StructureGenerator.buildWitchHut(this, centerWx, surfaceY, centerWz, dirtyChunks);
                } else if (biome === 'PLAINS' || biome === 'SAVANNA') {
                    if (hsh > 0.3) {
                        StructureGenerator.buildVillage(this, centerWx, surfaceY, centerWz, dirtyChunks);
                    } else {
                        StructureGenerator.buildRuinedPortal(this, centerWx, surfaceY, centerWz, dirtyChunks);
                    }
                } else {
                    if (hsh > 0.5) {
                        StructureGenerator.buildRuinedPortal(this, centerWx, surfaceY, centerWz, dirtyChunks);
                    }
                }

                // Underground Dungeon chance
                if (hsh < 0.4) {
                    const dungY = 18 + Math.floor(hsh * 12);
                    StructureGenerator.buildDungeon(this, centerWx, dungY, centerWz, dirtyChunks);
                }

                for (const chunkKey of dirtyChunks) {
                    const [dcx, dcz] = chunkKey.split(',').map(Number);
                    this.requestMeshRebuild(dcx, dcz);
                }
            }
        }
    }

    setTreeBlock(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number, id: number, overwrite = false) {
        if (y < 0 || y >= CONFIG.CHUNK_HEIGHT) return;
        if (lx >= 0 && lx < CONFIG.CHUNK_SIZE && lz >= 0 && lz < CONFIG.CHUNK_SIZE) {
            const current = chunk.getBlock(lx, y, lz);
            if (overwrite || current === BLOCK_ID.AIR || current === BLOCK_ID.TALL_GRASS || current === BLOCK_ID.FLOWER_RED || current === BLOCK_ID.FLOWER_YELLOW) {
                chunk.setBlock(lx, y, lz, id);
            }
        } else {
            // Target block crosses into an adjacent chunk
            const targetWx = cx * CONFIG.CHUNK_SIZE + lx;
            const targetWz = cz * CONFIG.CHUNK_SIZE + lz;
            const targetCx = Math.floor(targetWx / CONFIG.CHUNK_SIZE);
            const targetCz = Math.floor(targetWz / CONFIG.CHUNK_SIZE);
            const targetChunk = this.chunks.get(`${targetCx},${targetCz}`);
            if (targetChunk) {
                const targetLx = ((targetWx % CONFIG.CHUNK_SIZE) + CONFIG.CHUNK_SIZE) % CONFIG.CHUNK_SIZE;
                const targetLz = ((targetWz % CONFIG.CHUNK_SIZE) + CONFIG.CHUNK_SIZE) % CONFIG.CHUNK_SIZE;
                const current = targetChunk.getBlock(targetLx, y, targetLz);
                if (overwrite || current === BLOCK_ID.AIR || current === BLOCK_ID.TALL_GRASS || current === BLOCK_ID.FLOWER_RED || current === BLOCK_ID.FLOWER_YELLOW) {
                    targetChunk.setBlock(targetLx, y, targetLz, id);
                    targetChunk.isDirty = true;
                }
            }
        }
    }

    buildOakTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Oak Tree: logs vertically stacked on the exact same block column, topped with leaves
        const trunkHeight = 4 + Math.floor(Math.random() * 2);
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // User request: "some tree leaves become red in between some oak trees"
        // About 1 in 4 oak trees has autumn red leaves, or has red leaves mixed into the oak canopy!
        const isRedTree = Math.random() < 0.25;
        const getLeaf = () => {
            if (isRedTree) return Math.random() < 0.85 ? BLOCK_ID.RED_LEAVES : BLOCK_ID.LEAVES;
            return Math.random() < 0.08 ? BLOCK_ID.RED_LEAVES : BLOCK_ID.LEAVES;
        };

        // Layer at top of trunk (topY - 1): 3x3 leaf ring around the top log
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, getLeaf());
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, getLeaf());
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, getLeaf());
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, getLeaf());
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, getLeaf());
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, getLeaf());

        // Top crown leaf (topY + 1): directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, getLeaf());
    }

    buildCherryTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Cherry Blossom Tree: dark log trunk topped with pink cherry foliage
        const trunkHeight = 5;
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }
        const topY = y + trunkHeight;
        for (let dx = -2; dx <= 2; dx++) {
            for (let dz = -2; dz <= 2; dz++) {
                if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.CHERRY_LEAVES);
            }
        }
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY, lz + dz, BLOCK_ID.CHERRY_LEAVES);
            }
        }
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.CHERRY_LEAVES);
    }

    buildBirchTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Birch: logs vertically stacked on the exact same block column, topped with leaves
        const trunkHeight = 5;
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Layer at top of trunk (topY - 1): 3x3 leaf ring around the top log
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, BLOCK_ID.LEAVES);

        // Top crown leaf (topY + 1): directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildSpruceTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Spruce: logs vertically stacked on the exact same block column, topped with stepped leaves
        const trunkHeight = 5 + Math.floor(Math.random() * 2);
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Layer at topY - 1: 3x3 leaf ring around trunk
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, BLOCK_ID.LEAVES);

        // Needle tip (topY + 1): directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildCactus(chunk: Chunk, lx: number, y: number, lz: number) {
        const cactusHeight = 2 + Math.floor(Math.random() * 2);
        for (let i = 0; i < cactusHeight; i++) {
            if (y + i < CONFIG.CHUNK_HEIGHT) {
                chunk.setBlock(lx, y + i, lz, BLOCK_ID.CACTUS);
            }
        }
    }

    buildAcaciaTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Acacia: logs vertically stacked on the exact same block column, topped with flat leaf canopy
        const trunkHeight = 4 + Math.floor(Math.random() * 2);
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Flat umbrella layer directly on top of trunk (topY): 3x3 leaves centered on trunk
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Top crown leaf directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildDarkOakTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Dark Oak: logs vertically stacked on the exact same block column, topped with leaves
        const trunkHeight = 5;
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Layer at top of trunk (topY - 1): 3x3 leaf ring around the top log
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, BLOCK_ID.LEAVES);

        // Top crown leaf directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildMushroomTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Giant Red Mushroom: stem vertically stacked on the exact same block column, topped with cap
        const stemHeight = 4;
        for (let i = 0; i < stemHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const capY = y + stemHeight;
        // 3x3 red mushroom cap directly on top of stem
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                this.setTreeBlock(chunk, cx, cz, lx + dx, capY, lz + dz, BLOCK_ID.MUSHROOM_CAP, true);
            }
        }
        this.setTreeBlock(chunk, cx, cz, lx, capY + 1, lz, BLOCK_ID.MUSHROOM_CAP, true);
    }

    buildJungleTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Jungle Tree: logs vertically stacked on the exact same block column, topped with leaves
        const trunkHeight = 6;
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Layer at top of trunk (topY - 1): 3x3 leaf ring around the top log
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, BLOCK_ID.LEAVES);

        // Top crown leaf directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildSwampTree(chunk: Chunk, cx: number, cz: number, lx: number, y: number, lz: number) {
        // Authentic Minecraft Swamp Tree: logs vertically stacked on the exact same block column, topped with leaves
        const trunkHeight = 4;
        for (let i = 0; i < trunkHeight; i++) {
            this.setTreeBlock(chunk, cx, cz, lx, y + i, lz, BLOCK_ID.LOG, true);
        }

        const topY = y + trunkHeight;

        // Layer at top of trunk (topY - 1): 3x3 leaf ring around the top log
        for (let dx = -1; dx <= 1; dx++) {
            for (let dz = -1; dz <= 1; dz++) {
                if (dx === 0 && dz === 0) continue;
                this.setTreeBlock(chunk, cx, cz, lx + dx, topY - 1, lz + dz, BLOCK_ID.LEAVES);
            }
        }

        // Layer on top of trunk (topY): Center leaf directly on top of trunk + 4 cross leaves
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx + 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx - 1, topY, lz, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz + 1, BLOCK_ID.LEAVES);
        this.setTreeBlock(chunk, cx, cz, lx, topY, lz - 1, BLOCK_ID.LEAVES);

        // Top crown leaf directly on top of center leaf
        this.setTreeBlock(chunk, cx, cz, lx, topY + 1, lz, BLOCK_ID.LEAVES);
    }

    buildBambooStalk(chunk: Chunk, lx: number, y: number, lz: number) {
        const stalkHeight = 3 + Math.floor(Math.random() * 3);
        for (let i = 0; i < stalkHeight; i++) {
            if (y + i < CONFIG.CHUNK_HEIGHT) {
                chunk.setBlock(lx, y + i, lz, BLOCK_ID.BAMBOO);
            }
        }
    }

    requestMeshRebuild(cx: number, cz: number) {
        const key = `${cx},${cz}`;
        const chunk = this.chunks.get(key);
        if (!chunk) return;
        chunk.isDirty = true;
        if (this.meshBuildQueued.has(key)) return;
        this.meshBuildQueued.add(key);
        this.meshBuildQueue.push({ cx, cz, key });
    }

    setRenderDistance(dist: number) {
        this.renderDistance = Math.max(2, Math.min(8, dist));
        CONFIG.RENDER_DISTANCE = this.renderDistance;
    }

    flushMeshBuilds(maxCount = 1): number {
        let built = 0;
        while (built < maxCount && this.meshBuildQueue.length > 0) {
            const next = this.meshBuildQueue.shift()!;
            this.meshBuildQueued.delete(next.key);
            const chunk = this.chunks.get(next.key);
            if (!chunk || !chunk.isDirty) continue;
            this.refreshMesh(next.cx, next.cz);
            built++;
        }
        return built;
    }

    addRaycastMesh(mesh: THREE.Mesh) {
        if (this.raycastTargetIds.has(mesh.id)) return;
        this.raycastTargetIds.add(mesh.id);
        this.raycastTargets.push(mesh);
    }

    removeRaycastMesh(mesh: THREE.Mesh) {
        if (!this.raycastTargetIds.has(mesh.id)) return;
        this.raycastTargetIds.delete(mesh.id);
        const idx = this.raycastTargets.indexOf(mesh);
        if (idx !== -1) this.raycastTargets.splice(idx, 1);
    }

    disposeChunkMesh(key: string) {
        if (!this.meshes.has(key)) return;
        const oldGroup = this.meshes.get(key)!;
        this.scene.remove(oldGroup);
        oldGroup.children.forEach((child) => {
            const mesh = child as THREE.Mesh;
            this.removeRaycastMesh(mesh);
            if (mesh.geometry && mesh.geometry !== this.unitGeometry && mesh.geometry !== this.foliageCrossGeometry) {
                mesh.geometry.dispose();
            }
        });
        this.meshes.delete(key);
    }

    unloadFarChunks(centerCx: number, centerCz: number, maxDistance: number) {
        const maxDistanceSq = maxDistance * maxDistance;
        for (const key of Array.from(this.chunks.keys())) {
            const [cxStr, czStr] = key.split(',');
            const cx = Number(cxStr);
            const cz = Number(czStr);
            const dx = cx - centerCx;
            const dz = cz - centerCz;
            if ((dx * dx + dz * dz) > maxDistanceSq) {
                const chunk = this.chunks.get(key);
                if (chunk) {
                    this.chunkArchive.set(key, chunk.cloneData());
                }
                this.chunks.delete(key);
                this.disposeChunkMesh(key);
                this.meshBuildQueued.delete(key);
            }
        }
    }

    refreshMesh(cx: number, cz: number) {
        const key = `${cx},${cz}`;
        const chunk = this.chunks.get(key);
        if (!chunk) return;

        this.disposeChunkMesh(key);
        const group = new THREE.Group();
        const registry: Record<number, number[]> = {};

        // Fluid geometry buffers
        const waterPositions: number[] = [];
        const waterNormals: number[] = [];
        const waterUvs: number[] = [];

        const lavaPositions: number[] = [];
        const lavaNormals: number[] = [];
        const lavaUvs: number[] = [];

        for (let x = 0; x < CONFIG.CHUNK_SIZE; x++) {
            for (let y = 0; y < CONFIG.CHUNK_HEIGHT; y++) {
                for (let z = 0; z < CONFIG.CHUNK_SIZE; z++) {
                    const id = chunk.getBlock(x, y, z);
                    if (id === BLOCK_ID.AIR) continue;

                    const wx = cx * CONFIG.CHUNK_SIZE + x;
                    const wz = cz * CONFIG.CHUNK_SIZE + z;

                    if (id === BLOCK_ID.WATER) {
                        this.appendFluidGeometry(wx, y, wz, id, waterPositions, waterNormals, waterUvs);
                        continue;
                    }

                    if (id === BLOCK_ID.LAVA) {
                        this.appendFluidGeometry(wx, y, wz, id, lavaPositions, lavaNormals, lavaUvs);
                        continue;
                    }

                    const isPlant = (id === BLOCK_ID.TALL_GRASS || id === BLOCK_ID.FLOWER_RED || id === BLOCK_ID.FLOWER_YELLOW);

                    if (isPlant || this.isBlockExposed(wx, y, wz, id)) {
                        if (!registry[id]) registry[id] = [];
                        registry[id].push(wx + 0.5, y + 0.5, wz + 0.5);
                    }
                }
            }
        }

        // Build fluid meshes
        if (waterPositions.length > 0) {
            const geom = new THREE.BufferGeometry();
            geom.setAttribute('position', new THREE.Float32BufferAttribute(waterPositions, 3));
            geom.setAttribute('normal', new THREE.Float32BufferAttribute(waterNormals, 3));
            geom.setAttribute('uv', new THREE.Float32BufferAttribute(waterUvs, 2));
            const waterMesh = new THREE.Mesh(geom, this.materials[BLOCK_ID.WATER]);
            waterMesh.userData.blockId = BLOCK_ID.WATER;
            group.add(waterMesh);
        }

        if (lavaPositions.length > 0) {
            const geom = new THREE.BufferGeometry();
            geom.setAttribute('position', new THREE.Float32BufferAttribute(lavaPositions, 3));
            geom.setAttribute('normal', new THREE.Float32BufferAttribute(lavaNormals, 3));
            geom.setAttribute('uv', new THREE.Float32BufferAttribute(lavaUvs, 2));
            const lavaMesh = new THREE.Mesh(geom, this.materials[BLOCK_ID.LAVA]);
            lavaMesh.userData.blockId = BLOCK_ID.LAVA;
            group.add(lavaMesh);
        }

        // Build instanced meshes for solid blocks and foliage
        for (const [idStr, positions] of Object.entries(registry)) {
            const id = Number(idStr);
            const count = Math.floor(positions.length / 3);
            if (count === 0) continue;

            const isPlant = (id === BLOCK_ID.TALL_GRASS || id === BLOCK_ID.FLOWER_RED || id === BLOCK_ID.FLOWER_YELLOW);
            const geom = isPlant ? this.foliageCrossGeometry : this.unitGeometry;
            const imesh = new THREE.InstancedMesh(geom, this.materials[id], count);
            imesh.userData.blockId = id;
            if (!isPlant) {
                imesh.castShadow = false;
                imesh.receiveShadow = true;
            }

            for (let i = 0, p = 0; i < count; i++, p += 3) {
                const posY = isPlant ? positions[p + 1] - 0.5 : positions[p + 1];
                this.dummy.position.set(positions[p], posY, positions[p + 2]);
                this.dummy.rotation.set(0, 0, 0);
                this.dummy.updateMatrix();
                imesh.setMatrixAt(i, this.dummy.matrix);
            }
            imesh.instanceMatrix.needsUpdate = true;
            this.addRaycastMesh(imesh);
            group.add(imesh);
        }

        this.scene.add(group);
        this.meshes.set(key, group);
        chunk.isDirty = false;
    }

    appendFluidGeometry(
        wx: number, y: number, wz: number, id: number,
        positions: number[], normals: number[], uvs: number[]
    ) {
        const topH = id === BLOCK_ID.WATER ? 0.88 : 0.85;
        const topY = y + topH;
        const botY = y;

        // Top face: only if above is not the same fluid
        const above = this.getVoxel(wx, y + 1, wz);
        if (above !== id) {
            positions.push(
                wx, topY, wz,
                wx, topY, wz + 1,
                wx + 1, topY, wz + 1,

                wx, topY, wz,
                wx + 1, topY, wz + 1,
                wx + 1, topY, wz
            );
            for (let k = 0; k < 6; k++) normals.push(0, 1, 0);
            uvs.push(0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0);
        }

        // Bottom face: only if below is AIR
        const below = this.getVoxel(wx, y - 1, wz);
        if (below === BLOCK_ID.AIR) {
            positions.push(
                wx, botY, wz + 1,
                wx, botY, wz,
                wx + 1, botY, wz,

                wx, botY, wz + 1,
                wx + 1, botY, wz,
                wx + 1, botY, wz + 1
            );
            for (let k = 0; k < 6; k++) normals.push(0, -1, 0);
            uvs.push(0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0);
        }

        // Side faces: only if adjacent block is NOT fluid and NOT solid
        const isExposedToSide = (nx: number, ny: number, nz: number) => {
            const nId = this.getVoxel(nx, ny, nz);
            if (nId === id) return false;
            const def = BLOCK_DEFS[nId];
            return !def || !def.solid;
        };

        // West (-X)
        if (isExposedToSide(wx - 1, y, wz)) {
            positions.push(
                wx, botY, wz,
                wx, botY, wz + 1,
                wx, topY, wz + 1,

                wx, botY, wz,
                wx, topY, wz + 1,
                wx, topY, wz
            );
            for (let k = 0; k < 6; k++) normals.push(-1, 0, 0);
            uvs.push(0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1);
        }

        // East (+X)
        if (isExposedToSide(wx + 1, y, wz)) {
            positions.push(
                wx + 1, botY, wz + 1,
                wx + 1, botY, wz,
                wx + 1, topY, wz,

                wx + 1, botY, wz + 1,
                wx + 1, topY, wz,
                wx + 1, topY, wz + 1
            );
            for (let k = 0; k < 6; k++) normals.push(1, 0, 0);
            uvs.push(0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1);
        }

        // North (-Z)
        if (isExposedToSide(wx, y, wz - 1)) {
            positions.push(
                wx + 1, botY, wz,
                wx, botY, wz,
                wx, topY, wz,

                wx + 1, botY, wz,
                wx, topY, wz,
                wx + 1, topY, wz
            );
            for (let k = 0; k < 6; k++) normals.push(0, 0, -1);
            uvs.push(0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1);
        }

        // South (+Z)
        if (isExposedToSide(wx, y, wz + 1)) {
            positions.push(
                wx, botY, wz + 1,
                wx + 1, botY, wz + 1,
                wx + 1, topY, wz + 1,

                wx, botY, wz + 1,
                wx + 1, topY, wz + 1,
                wx, topY, wz + 1
            );
            for (let k = 0; k < 6; k++) normals.push(0, 0, 1);
            uvs.push(0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1);
        }
    }

    isBlockExposed(x: number, y: number, z: number, selfId: number): boolean {
        const neighbors = [
            [ 1, 0, 0],
            [-1, 0, 0],
            [ 0, 1, 0],
            [ 0,-1, 0],
            [ 0, 0, 1],
            [ 0, 0,-1]
        ];
        for (const [dx, dy, dz] of neighbors) {
            const neighborId = this.getVoxel(x + dx, y + dy, z + dz);
            if (neighborId === BLOCK_ID.AIR) return true;
            const neighborDef = BLOCK_DEFS[neighborId];
            if (!neighborDef) return true;
            if (neighborDef.transparent && neighborId !== selfId) return true;
            const isNeighborLeaves = (neighborId === BLOCK_ID.LEAVES || neighborId === BLOCK_ID.CHERRY_LEAVES || neighborId === BLOCK_ID.RED_LEAVES);
            const isSelfLeaves = (selfId === BLOCK_ID.LEAVES || selfId === BLOCK_ID.CHERRY_LEAVES || selfId === BLOCK_ID.RED_LEAVES);
            if (isNeighborLeaves && !isSelfLeaves) return true;
        }
        return false;
    }

    buildPortalAt(wx: number, wz: number, axis = 'x'): { x: number; y: number; z: number } {
        const baseY = Math.max(6, this.findSurfaceY(wx, wz));
        return { x: wx + 0.5, y: baseY + 1.15, z: wz + 1.5 };
    }

    consumeChestLoot(wx: number, wy: number, wz: number): any[] {
        const key = `${wx},${wy},${wz}`;
        const loot = this.chestLoot.get(key);
        if (loot) this.chestLoot.delete(key);
        return loot || [];
    }

    getActiveFriendlySpawns(): any[] {
        const active: any[] = [];
        for (const [key, spawns] of this.villageSpawns) {
            if (this.chunks.has(key)) active.push(...spawns);
        }
        return active;
    }

    serializePersistentState(): any {
        return {
            version: 1,
            chunks: {},
            villageCenters: Array.from(this.villageCenters),
            ruinCenters: Array.from(this.ruinCenters),
            overworldStructureCenters: Array.from(this.overworldStructureCenters),
            netherStructureCenters: Array.from(this.netherStructureCenters),
            villageSpawns: {},
            biomeSpawns: {},
            chestLoot: {}
        };
    }

    deserializePersistentState(snapshot: any): boolean {
        return true;
    }
}
