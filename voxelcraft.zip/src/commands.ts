import { BLOCK_ID, RESOURCE_DEFS, getBlockIdForResourceId } from './constants';

/* ==============================================================
   MINECRAFT COMMANDS SYSTEM
   Full Minecraft syntax and parsing:
   /gamemode <creative|survival|hardcore|spectator>
   /summon <villager|iron_golem|zombie|skeleton|creeper|spider|enderman|cow|pig|sheep|chicken> [x y z]
   /time <set|add|query> <day|night|noon|midnight|[ticks]>
   /give <item> [amount]
   /clear [item]
   /tp <x> <y> <z> | /tp spawn
   /kill [player|mobs]
   /weather <clear|rain|thunder>
   /seed
   /locate <village|mineshaft|stronghold|biome>
   /say <message>
   /tell <player> <message>
   /me <action>
   /difficulty <peaceful|easy|normal|hard>
   /fly
   /help [command]
   ============================================================== */

export interface CommandContext {
    app: any;
    survival: any;
    inventory: any;
    player: any;
    world: any;
}

export const COMMAND_LIST = [
    { cmd: '/gamemode', syntax: '/gamemode <survival|creative|hardcore|spectator>', desc: 'Sets player game mode' },
    { cmd: '/summon', syntax: '/summon <villager|iron_golem|zombie|skeleton|creeper|spider|enderman|cow|pig|sheep|chicken> [x y z]', desc: 'Summons mob entity' },
    { cmd: '/give', syntax: '/give <item> [amount]', desc: 'Gives items or blocks to player' },
    { cmd: '/time', syntax: '/time <set|add> <day|night|noon|midnight|[ticks]>', desc: 'Changes world time' },
    { cmd: '/tp', syntax: '/tp <x> <y> <z> | /tp spawn', desc: 'Teleports the player' },
    { cmd: '/weather', syntax: '/weather <clear|rain|thunder>', desc: 'Sets world weather condition' },
    { cmd: '/locate', syntax: '/locate <village|mineshaft|stronghold|biome>', desc: 'Locates nearest structure or village' },
    { cmd: '/clear', syntax: '/clear', desc: 'Clears items from inventory' },
    { cmd: '/fly', syntax: '/fly', desc: 'Toggles flight mode in Creative' },
    { cmd: '/seed', syntax: '/seed', desc: 'Displays current world seed' },
    { cmd: '/say', syntax: '/say <message>', desc: 'Broadcasts a message to all players' },
    { cmd: '/tell', syntax: '/tell <player> <message>', desc: 'Sends a private whisper message' },
    { cmd: '/me', syntax: '/me <action>', desc: 'Displays an action in chat' },
    { cmd: '/difficulty', syntax: '/difficulty <peaceful|easy|normal|hard>', desc: 'Sets the game difficulty' },
    { cmd: '/durability', syntax: '/durability [amount]', desc: 'Sets or checks held tool durability' },
    { cmd: '/repair', syntax: '/repair', desc: 'Repairs held tool to max durability' },
    { cmd: '/kill', syntax: '/kill', desc: 'Defeats the player' },
    { cmd: '/help', syntax: '/help [command]', desc: 'Shows list of available commands' }
];

export function getCommandSuggestions(input: string): { cmd: string; syntax: string; desc: string }[] {
    const trimmed = input.trim().toLowerCase();
    if (!trimmed.startsWith('/')) return [];
    const firstWord = trimmed.split(/\s+/)[0];
    return COMMAND_LIST.filter(c => c.cmd.startsWith(firstWord) || firstWord === '/');
}

export function executeCommand(cmdLine: string, ctx: CommandContext): { success: boolean; message: string } {
    const raw = cmdLine.trim();
    if (!raw.startsWith('/')) {
        return { success: false, message: 'Commands must start with /' };
    }

    const parts = raw.slice(1).trim().split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const args = parts.slice(1);

    switch (cmd) {
        case 'gamemode':
        case 'gm':
        case 'gmc':
        case 'gms':
        case 'gmh':
        case 'gmsp': {
            let mode = '';
            if (cmd === 'gmc') mode = 'creative';
            else if (cmd === 'gms') mode = 'survival';
            else if (cmd === 'gmh') mode = 'hardcore';
            else if (cmd === 'gmsp') mode = 'spectator';
            else {
                const target = (args[0] || '').toLowerCase();
                if (target === 'c' || target === '1' || target === 'creative') mode = 'creative';
                else if (target === 's' || target === '0' || target === 'survival') mode = 'survival';
                else if (target === 'h' || target === '2' || target === 'hardcore') mode = 'hardcore';
                else if (target === 'sp' || target === '3' || target === 'spectator') mode = 'spectator';
                else {
                    return { success: false, message: 'Usage: /gamemode <creative|survival|hardcore|spectator>' };
                }
            }

            if (mode === 'creative') {
                ctx.survival.setGameMode('Creative');
                ctx.inventory.setCreativeMode(true);
                ctx.player.isFlying = false;
                ctx.app.logChat('Set own game mode to Creative Mode', 'system');
                return { success: true, message: 'Set own game mode to Creative Mode' };
            } else if (mode === 'hardcore') {
                ctx.survival.setGameMode('Hardcore');
                ctx.inventory.setCreativeMode(false);
                ctx.player.isFlying = false;
                ctx.app.logChat('Set own game mode to Hardcore Mode (1 life, locked on Hard)', 'system');
                return { success: true, message: 'Set own game mode to Hardcore Mode' };
            } else if (mode === 'spectator') {
                ctx.survival.setGameMode('Creative');
                ctx.inventory.setCreativeMode(true);
                ctx.player.isFlying = true;
                ctx.app.logChat('Set own game mode to Spectator Mode', 'system');
                return { success: true, message: 'Set own game mode to Spectator Mode' };
            } else {
                ctx.survival.setGameMode('Survival');
                ctx.inventory.setCreativeMode(false);
                ctx.player.isFlying = false;
                ctx.app.logChat('Set own game mode to Survival Mode', 'system');
                return { success: true, message: 'Set own game mode to Survival Mode' };
            }
        }

        case 'summon': {
            if (args.length < 1) {
                return { success: false, message: 'Usage: /summon <mob_name> [x y z]' };
            }
            const mobType = args[0].toLowerCase().replace(/^minecraft:/, '');
            let x = ctx.player.camera.position.x;
            let y = ctx.player.camera.position.y - 1.62;
            let z = ctx.player.camera.position.z;

            // Optional coordinates
            if (args.length >= 4) {
                const px = parseFloat(args[1]);
                const py = parseFloat(args[2]);
                const pz = parseFloat(args[3]);
                if (!isNaN(px)) x = px;
                if (!isNaN(py)) y = py;
                if (!isNaN(pz)) z = pz;
            } else {
                // Spawn 3 blocks in front of player
                const dir = new THREE.Vector3();
                ctx.player.camera.getWorldDirection(dir);
                x += dir.x * 3;
                z += dir.z * 3;
                y = ctx.world.findSurfaceY(Math.floor(x), Math.floor(z)) + 1;
            }

            const friendlyMobs = ['villager', 'iron_golem', 'cow', 'pig', 'sheep', 'chicken'];
            const hostileMobs = ['zombie', 'skeleton', 'creeper', 'spider', 'enderman'];

            if (friendlyMobs.includes(mobType)) {
                ctx.app.friendlies?.createFriendly(mobType, x, y, z);
                const msg = `Summoned new ${mobType.replace(/_/g, ' ')} at ${x.toFixed(1)}, ${y.toFixed(1)}, ${z.toFixed(1)}`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else if (hostileMobs.includes(mobType)) {
                ctx.app.hostiles?.createHostile(mobType, x, y, z);
                const msg = `Summoned new ${mobType.replace(/_/g, ' ')} at ${x.toFixed(1)}, ${y.toFixed(1)}, ${z.toFixed(1)}`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else {
                return { success: false, message: `Unknown mob: ${mobType}. Valid: ${[...friendlyMobs, ...hostileMobs].join(', ')}` };
            }
        }

        case 'time': {
            const sub = (args[0] || '').toLowerCase();
            if (sub === 'set') {
                const val = (args[1] || '').toLowerCase();
                let time = 1000;
                if (val === 'day') time = 1000;
                else if (val === 'noon') time = 6000;
                else if (val === 'sunset') time = 12000;
                else if (val === 'night') time = 13000;
                else if (val === 'midnight') time = 18000;
                else if (val === 'sunrise') time = 23000;
                else {
                    const num = parseInt(val, 10);
                    if (!isNaN(num)) time = Math.max(0, num % 24000);
                    else return { success: false, message: 'Usage: /time set <day|night|noon|midnight|[0-24000]>' };
                }

                if (ctx.app && ctx.app.dayNightCycle) {
                    ctx.app.dayNightCycle.setTime(time);
                }
                const msg = `Set the time to ${time}`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else if (sub === 'add') {
                const num = parseInt(args[1] || '0', 10);
                if (isNaN(num)) return { success: false, message: 'Usage: /time add <ticks>' };
                if (ctx.app && ctx.app.dayNightCycle) {
                    ctx.app.dayNightCycle.addTime(num);
                }
                const msg = `Added ${num} to the time`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else if (sub === 'query') {
                const cur = ctx.app?.dayNightCycle?.timeOfDay ?? 1000;
                const msg = `The time is ${Math.round(cur)}`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else {
                return { success: false, message: 'Usage: /time <set|add|query> <day|night|noon|midnight|[ticks]>' };
            }
        }

        case 'give': {
            if (args.length < 1) {
                return { success: false, message: 'Usage: /give <item_name> [amount]' };
            }
            const itemQuery = args[0].toLowerCase().replace(/^minecraft:/, '');
            const count = Math.min(640, Math.max(1, parseInt(args[1] || '64', 10) || 64));

            // Check BLOCK_ID
            let matchedBlockId: number | null = null;
            for (const [key, val] of Object.entries(BLOCK_ID)) {
                if (typeof val === 'number') {
                    if (key.toLowerCase() === itemQuery || key.toLowerCase().replace(/_/g, '') === itemQuery.replace(/_/g, '')) {
                        matchedBlockId = val;
                        break;
                    }
                }
            }

            if (matchedBlockId === null) {
                const aliasBlock = getBlockIdForResourceId(itemQuery);
                if (aliasBlock !== null) matchedBlockId = aliasBlock;
            }

            // Check resources
            let matchedResource: string | null = null;
            for (const rId of Object.keys(RESOURCE_DEFS)) {
                if (rId.toLowerCase() === itemQuery || rId.toLowerCase().replace(/_/g, '') === itemQuery.replace(/_/g, '')) {
                    matchedResource = rId;
                    break;
                }
            }

            if (matchedBlockId !== null) {
                ctx.inventory.addBlock(matchedBlockId, count);
                const blockKey = Object.keys(BLOCK_ID).find(k => (BLOCK_ID as any)[k] === matchedBlockId) || 'Block';
                const msg = `Gave ${count} [${blockKey.replace(/_/g, ' ')}] to Player`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else if (matchedResource !== null) {
                ctx.inventory.addResource(matchedResource, count);
                const def = RESOURCE_DEFS[matchedResource];
                const msg = `Gave ${count} [${def ? def.label : matchedResource}] to Player`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else {
                return { success: false, message: `Unknown item: ${args[0]}. Type /help for items.` };
            }
        }

        case 'clear': {
            ctx.inventory.clearAll();
            ctx.app.logChat('Cleared the inventory of Player', 'system');
            return { success: true, message: 'Cleared the inventory of Player' };
        }

        case 'durability': {
            if (args.length === 0) {
                const info = ctx.app.toolDurability?.getHeldToolDurability();
                if (!info) return { success: false, message: 'You are not holding a tool with durability.' };
                return { success: true, message: `Held tool (${info.label}) durability: ${info.current}/${info.max}` };
            }
            const amount = parseInt(args[0], 10);
            if (isNaN(amount) || amount < 0) {
                return { success: false, message: 'Usage: /durability [amount]' };
            }
            const ok = ctx.app.toolDurability?.setHeldToolDurability(amount);
            if (!ok) return { success: false, message: 'You are not holding a tool with durability.' };
            const msg = `Set held tool durability to ${amount}`;
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'repair': {
            const ok = ctx.app.toolDurability?.repairHeldTool();
            if (!ok) return { success: false, message: 'You are not holding a tool with durability.' };
            const msg = 'Repaired held tool to full durability';
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'tp':
        case 'teleport': {
            if (args.length === 1 && args[0].toLowerCase() === 'spawn') {
                const spawn = ctx.world.findSafeSpawnSurface(0, 0);
                ctx.player.camera.position.set(spawn.x + 0.5, spawn.y + 2.62, spawn.z + 0.5);
                ctx.player.velocity.set(0, 0, 0);
                const msg = `Teleported Player to Spawn (${Math.round(spawn.x)}, ${Math.round(spawn.y)}, ${Math.round(spawn.z)})`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else if (args.length >= 3) {
                const x = parseFloat(args[0]);
                const y = parseFloat(args[1]);
                const z = parseFloat(args[2]);
                if (isNaN(x) || isNaN(y) || isNaN(z)) {
                    return { success: false, message: 'Usage: /tp <x> <y> <z>' };
                }
                ctx.player.camera.position.set(x, y + 1.62, z);
                ctx.player.velocity.set(0, 0, 0);
                const msg = `Teleported Player to ${x.toFixed(1)}, ${y.toFixed(1)}, ${z.toFixed(1)}`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else {
                return { success: false, message: 'Usage: /tp <x> <y> <z> or /tp spawn' };
            }
        }

        case 'kill': {
            if (args.length > 0 && args[0].toLowerCase() === '@e') {
                ctx.app.hostiles?.clear();
                ctx.app.logChat('Killed all hostile entities', 'system');
                return { success: true, message: 'Killed all hostile entities' };
            }
            if (ctx.survival) {
                ctx.survival.damage(9999);
            }
            ctx.app.logChat('Player fell out of the world', 'system');
            return { success: true, message: 'Player killed' };
        }

        case 'weather': {
            const w = (args[0] || 'clear').toLowerCase();
            if (ctx.app && ctx.app.weatherKernel) {
                if (w === 'rain') ctx.app.weatherKernel.setWeather('rain');
                else if (w === 'thunder') ctx.app.weatherKernel.setWeather('thunder');
                else ctx.app.weatherKernel.setWeather('clear');
            }
            const msg = `Set weather to ${w}`;
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'seed': {
            const seed = ctx.world?.synthesizer?.seed ?? 42;
            const msg = `Seed: [${seed}]`;
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'locate': {
            const target = (args[0] || 'village').toLowerCase();
            if (target === 'village') {
                const vx = Math.round(ctx.player.camera.position.x / 64) * 64 + 32;
                const vz = Math.round(ctx.player.camera.position.z / 64) * 64 + 32;
                const vy = ctx.world.findSurfaceY(vx, vz);
                const msg = `The nearest [Village] is at [${vx}, ${vy}, ${vz}] (${Math.round(Math.hypot(vx - ctx.player.camera.position.x, vz - ctx.player.camera.position.z))} blocks away)`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            } else {
                const msg = `Located structure [${target}] at [${Math.round(ctx.player.camera.position.x + 80)}, ~, ${Math.round(ctx.player.camera.position.z + 80)}]`;
                ctx.app.logChat(msg, 'system');
                return { success: true, message: msg };
            }
        }

        case 'say': {
            const message = args.join(' ');
            if (!message) return { success: false, message: 'Usage: /say <message>' };
            const formatted = `[Server] ${message}`;
            ctx.app.pushChatLine('Server', message, 'command');
            return { success: true, message: formatted };
        }

        case 'tell':
        case 'msg':
        case 'w': {
            if (args.length < 2) return { success: false, message: 'Usage: /tell <player> <message>' };
            const targetPlayer = args[0];
            const message = args.slice(1).join(' ');
            ctx.app.pushChatLine('You -> ' + targetPlayer, message, 'system');
            return { success: true, message: `Whispered to ${targetPlayer}` };
        }

        case 'me': {
            const action = args.join(' ');
            if (!action) return { success: false, message: 'Usage: /me <action>' };
            const pName = ctx.app?.accountManager?.getEffectiveUsername?.() || 'Player';
            ctx.app.pushChatLine('* ' + pName, action, 'system');
            return { success: true, message: `* ${pName} ${action}` };
        }

        case 'difficulty': {
            const diff = (args[0] || 'normal').toLowerCase();
            const msg = `Set difficulty to ${diff}`;
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'fly': {
            if (!ctx.survival.isCreative()) {
                return { success: false, message: 'Flying is only allowed in Creative mode (/gamemode creative)' };
            }
            ctx.player.isFlying = !ctx.player.isFlying;
            ctx.player.velocity.set(0, 0, 0);
            const msg = ctx.player.isFlying ? 'Flying enabled (Space ascend, Shift descend)' : 'Flying disabled';
            ctx.app.logChat(msg, 'system');
            return { success: true, message: msg };
        }

        case 'help': {
            const lines = [
                '§6=== Minecraft Commands ===',
                '§e/gamemode <survival|creative|hardcore|spectator> §7- Switch game mode',
                '§e/summon <villager|iron_golem|zombie|skeleton|creeper|spider|enderman> §7- Spawn mob',
                '§e/time set <day|night|noon|midnight|[ticks]> §7- Set time of day',
                '§e/give <item> [count] §7- Give blocks or items (e.g. /give diamond 64)',
                '§e/tp <x> <y> <z> or /tp spawn §7- Teleport player',
                '§e/locate <village|mineshaft|biome> §7- Find nearest structure',
                '§e/say <message> §7- Broadcast server message',
                '§e/clear §7- Empty inventory',
                '§e/fly §7- Toggle flight mode',
                '§e/weather <clear|rain|thunder> §7- Set weather',
                '§e/seed §7- Show world seed',
                '§e/kill §7- Defeat player or /kill @e'
            ];
            lines.forEach(l => ctx.app.logChat(l, 'system'));
            return { success: true, message: 'Help displayed in chat log.' };
        }

        default:
            return { success: false, message: `Unknown command: /${cmd}. Type /help for list of commands.` };
    }
}
import * as THREE from 'three';
