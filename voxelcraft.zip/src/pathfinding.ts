import * as THREE from 'three';
import { BLOCK_ID, BLOCK_DEFS } from './constants';
import { VoxelWorld } from './world';

/**
 * Checks if a voxel coordinate is solid and collidable
 */
export function isVoxelSolid(world: VoxelWorld, x: number, y: number, z: number): boolean {
    if (y < 0 || y >= 256) return false;
    const bId = world.getVoxel(x, y, z);
    if (bId === BLOCK_ID.AIR || bId === BLOCK_ID.WATER || bId === BLOCK_ID.LAVA) return false;
    if (bId === BLOCK_ID.TALL_GRASS || bId === BLOCK_ID.FLOWER_RED || bId === BLOCK_ID.FLOWER_YELLOW) return false;
    const def = BLOCK_DEFS[bId];
    return !!(def && def.solid);
}

/**
 * Fast 3D voxel line-of-sight raycast between two points
 */
export function hasLineOfSight(world: VoxelWorld, from: THREE.Vector3, to: THREE.Vector3): boolean {
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const dz = to.z - from.z;
    const dist = Math.hypot(dx, dy, dz);
    if (dist < 0.3) return true;

    // Sample voxels along the ray at 0.35 block intervals
    const steps = Math.max(1, Math.ceil(dist * 2.8));
    const stepX = dx / steps;
    const stepY = dy / steps;
    const stepZ = dz / steps;

    let cx = from.x;
    let cy = from.y;
    let cz = from.z;

    for (let i = 1; i < steps; i++) {
        cx += stepX;
        cy += stepY;
        cz += stepZ;
        const bx = Math.floor(cx);
        const by = Math.floor(cy);
        const bz = Math.floor(cz);
        if (isVoxelSolid(world, bx, by, bz)) {
            return false;
        }
    }
    return true;
}

export interface PathNode {
    x: number;
    y: number;
    z: number;
    g: number;
    h: number;
    f: number;
    parent?: PathNode;
}

export interface PathfindingOptions {
    maxDistance?: number;
    canClimb?: boolean;
    mobHeight?: number;
    maxNodes?: number;
}

/**
 * 3D Voxel A* Pathfinding for hostile and friendly mobs
 * Navigates obstacles, hills, 1-block steps, drops, and walls (for spiders)
 */
export function findMobPath(
    world: VoxelWorld,
    start: THREE.Vector3,
    goal: THREE.Vector3,
    options: PathfindingOptions = {}
): THREE.Vector3[] {
    const maxDist = options.maxDistance || 24;
    const canClimb = !!options.canClimb;
    const mobHeight = options.mobHeight || 2;
    const maxNodes = options.maxNodes || 140;

    const sx = Math.floor(start.x);
    const sy = Math.floor(start.y);
    const sz = Math.floor(start.z);

    const gx = Math.floor(goal.x);
    const gy = Math.floor(goal.y);
    const gz = Math.floor(goal.z);

    const directDist = Math.hypot(gx - sx, gy - sy, gz - sz);
    if (directDist > maxDist) {
        return [];
    }

    // Direct line of sight optimization:
    // If unobstructed and elevation difference is small, direct approach is optimal
    const eyeStart = new THREE.Vector3(start.x, start.y + 0.8, start.z);
    const eyeGoal = new THREE.Vector3(goal.x, goal.y + 0.8, goal.z);
    if (hasLineOfSight(world, eyeStart, eyeGoal) && Math.abs(goal.y - start.y) <= 1.4) {
        return [new THREE.Vector3(goal.x, goal.y, goal.z)];
    }

    const startNode: PathNode = {
        x: sx,
        y: sy,
        z: sz,
        g: 0,
        h: Math.hypot(gx - sx, (gy - sy) * 1.4, gz - sz),
        f: Math.hypot(gx - sx, (gy - sy) * 1.4, gz - sz)
    };

    const openList: PathNode[] = [startNode];
    const openMap = new Map<string, PathNode>();
    const closedSet = new Set<string>();

    const makeKey = (x: number, y: number, z: number) => `${x},${y},${z}`;
    openMap.set(makeKey(sx, sy, sz), startNode);

    let closestNode: PathNode = startNode;
    let closestH = startNode.h;

    const DIRS = [
        { dx: 1, dz: 0 },
        { dx: -1, dz: 0 },
        { dx: 0, dz: 1 },
        { dx: 0, dz: -1 }
    ];

    let iterations = 0;

    while (openList.length > 0 && iterations < maxNodes) {
        iterations++;

        // Pop lowest f cost node
        let bestIdx = 0;
        for (let i = 1; i < openList.length; i++) {
            if (openList[i].f < openList[bestIdx].f) {
                bestIdx = i;
            }
        }
        const current = openList.splice(bestIdx, 1)[0];
        const curKey = makeKey(current.x, current.y, current.z);
        openMap.delete(curKey);
        closedSet.add(curKey);

        // Update closest reachable node towards target
        if (current.h < closestH) {
            closestH = current.h;
            closestNode = current;
        }

        // Check if goal reached (or adjacent)
        const dGoal = Math.hypot(current.x - gx, current.z - gz);
        if (dGoal <= 1.1 && Math.abs(current.y - gy) <= 1.5) {
            closestNode = current;
            break;
        }

        // Explore neighbor moves
        for (const dir of DIRS) {
            const nx = current.x + dir.dx;
            const nz = current.z + dir.dz;
            let ny = current.y;
            let moveCost = 1.0;

            const footSolid = isVoxelSolid(world, nx, ny, nz);
            const headSolid = isVoxelSolid(world, nx, ny + 1, nz);

            if (!footSolid) {
                // Ground level is open: test if stepping flat or stepping down
                const groundSolid = isVoxelSolid(world, nx, ny - 1, nz);
                if (groundSolid) {
                    // Flat walk: requires headroom
                    if (!headSolid && (mobHeight <= 1 || !isVoxelSolid(world, nx, ny + 2, nz))) {
                        ny = current.y;
                        moveCost = 1.0;
                    } else {
                        continue;
                    }
                } else {
                    // Safe drop down 1, 2, or 3 blocks
                    let foundGround = false;
                    for (let drop = 1; drop <= 3; drop++) {
                        const checkY = current.y - drop;
                        if (checkY < 1) break;
                        const blockUnder = world.getVoxel(nx, checkY - 1, nz);
                        if (blockUnder === BLOCK_ID.LAVA) break; // Avoid lava
                        if (isVoxelSolid(world, nx, checkY - 1, nz)) {
                            // Check clearance at drop point
                            let dropClear = true;
                            for (let h = 0; h < mobHeight; h++) {
                                if (isVoxelSolid(world, nx, checkY + h, nz)) {
                                    dropClear = false;
                                    break;
                                }
                            }
                            if (dropClear) {
                                ny = checkY;
                                moveCost = 1.0 + drop * 0.35;
                                foundGround = true;
                                break;
                            }
                        }
                    }
                    if (!foundGround) continue;
                }
            } else {
                // Foot block is solid: Can we step up 1 block?
                const step1Passable = !isVoxelSolid(world, nx, ny + 1, nz);
                const step2Passable = !isVoxelSolid(world, nx, ny + 2, nz);
                const currentHeadroom = !isVoxelSolid(world, current.x, current.y + 2, current.z);

                if (step1Passable && step2Passable && currentHeadroom) {
                    // 1-block step up
                    ny = current.y + 1;
                    moveCost = 1.35;
                } else if (canClimb) {
                    // Spider vertical wall climbing:
                    // Spider can scale up the wall if top is reachable!
                    let climbY = current.y + 1;
                    let foundTop = false;
                    for (let c = 1; c <= 6; c++) {
                        const testY = current.y + c;
                        if (!isVoxelSolid(world, nx, testY, nz) && !isVoxelSolid(world, nx, testY + 1, nz)) {
                            climbY = testY;
                            foundTop = true;
                            break;
                        }
                    }
                    if (foundTop) {
                        ny = climbY;
                        moveCost = 1.5 + (climbY - current.y) * 0.4;
                    } else {
                        // Climb up current column against the wall
                        ny = current.y + 1;
                        moveCost = 1.5;
                    }
                } else {
                    continue;
                }
            }

            const nKey = makeKey(nx, ny, nz);
            if (closedSet.has(nKey)) continue;

            const gCost = current.g + moveCost;
            const hCost = Math.hypot(gx - nx, (gy - ny) * 1.4, gz - nz);
            const fCost = gCost + hCost;

            const existing = openMap.get(nKey);
            if (existing) {
                if (gCost < existing.g) {
                    existing.g = gCost;
                    existing.f = fCost;
                    existing.parent = current;
                }
            } else {
                const neighborNode: PathNode = {
                    x: nx,
                    y: ny,
                    z: nz,
                    g: gCost,
                    h: hCost,
                    f: fCost,
                    parent: current
                };
                openList.push(neighborNode);
                openMap.set(nKey, neighborNode);
            }
        }
    }

    // Reconstruct path backwards from closest reached node to start
    const path: THREE.Vector3[] = [];
    let curr: PathNode | undefined = closestNode;
    while (curr && curr.parent) {
        path.unshift(new THREE.Vector3(curr.x + 0.5, curr.y, curr.z + 0.5));
        curr = curr.parent;
    }

    // Path smoothing: prune unnecessary intermediate zig-zags
    if (path.length > 2) {
        const smoothed: THREE.Vector3[] = [path[0]];
        let anchor = path[0];
        for (let i = 2; i < path.length; i++) {
            const candidate = path[i];
            const startCheck = new THREE.Vector3(anchor.x, anchor.y + 0.5, anchor.z);
            const endCheck = new THREE.Vector3(candidate.x, candidate.y + 0.5, candidate.z);
            if (hasLineOfSight(world, startCheck, endCheck) && Math.abs(candidate.y - anchor.y) <= 1.1) {
                // Can skip intermediate point
                continue;
            } else {
                smoothed.push(path[i - 1]);
                anchor = path[i - 1];
            }
        }
        smoothed.push(path[path.length - 1]);
        return smoothed;
    }

    return path;
}
