import * as THREE from 'three';
import {
    CONFIG,
    BLOCK_ID,
    BLOCK_DEFS,
    RESOURCE_ITEM,
    RESOURCE_DEFS,
    CRAFTING_RECIPES,
    PLAYER_SKINS,
    getSkinDefById,
    normalizeSkinPayload,
    getCustomSkinState,
    getBlockIdForResourceId,
    HOTBAR_PLACEABLE_BLOCKS,
    CREATIVE_BLOCK_INVENTORY,
    isDurabilityTool,
    getToolMaxDurability
} from './constants';
import { MathKernel, VoxelWorld } from './world';
import { getItemTexture } from './itemTextures';

export const CREATIVE_TABS = {
    building: [
        BLOCK_ID.STONE, BLOCK_ID.COBBLESTONE, BLOCK_ID.MOSSY_COBBLESTONE, BLOCK_ID.BRICKS,
        BLOCK_ID.PLANKS, BLOCK_ID.WOOD, BLOCK_ID.LOG, BLOCK_ID.GLASS, BLOCK_ID.OBSIDIAN,
        BLOCK_ID.BEDROCK, BLOCK_ID.NETHERRACK, BLOCK_ID.CLAY, BLOCK_ID.SNOW
    ].map((id) => ({ kind: 'block' as const, id })),
    natural: [
        BLOCK_ID.GRASS, BLOCK_ID.DIRT, BLOCK_ID.SAND, BLOCK_ID.GRAVEL, BLOCK_ID.LOG,
        BLOCK_ID.LEAVES, BLOCK_ID.CHERRY_LEAVES, BLOCK_ID.RED_LEAVES, BLOCK_ID.CACTUS,
        BLOCK_ID.BAMBOO, BLOCK_ID.TALL_GRASS, BLOCK_ID.FLOWER_RED, BLOCK_ID.FLOWER_YELLOW,
        BLOCK_ID.SOUL_SAND, BLOCK_ID.GLOWSTONE, BLOCK_ID.MUSHROOM_CAP
    ].map((id) => ({ kind: 'block' as const, id })),
    ores: [
        ...[
            BLOCK_ID.COAL_ORE, BLOCK_ID.IRON_ORE, BLOCK_ID.LAPIS_ORE, BLOCK_ID.REDSTONE_ORE,
            BLOCK_ID.GOLD_ORE, BLOCK_ID.DIAMOND_ORE, BLOCK_ID.EMERALD_ORE, BLOCK_ID.RUBY_ORE,
            BLOCK_ID.NETHER_QUARTZ_ORE
        ].map((id) => ({ kind: 'block' as const, id })),
        ...[
            RESOURCE_ITEM.COAL, RESOURCE_ITEM.RAW_IRON, RESOURCE_ITEM.LAPIS, RESOURCE_ITEM.REDSTONE,
            RESOURCE_ITEM.RAW_GOLD, RESOURCE_ITEM.DIAMOND, RESOURCE_ITEM.EMERALD, RESOURCE_ITEM.RUBY
        ].map((id) => ({ kind: 'resource' as const, id }))
    ],
    tools: [
        RESOURCE_ITEM.WIND_CHARGE, RESOURCE_ITEM.MACE, RESOURCE_ITEM.DIAMOND_MACE,
        RESOURCE_ITEM.SPEAR, RESOURCE_ITEM.DIAMOND_SPEAR, RESOURCE_ITEM.TRIDENT,
        RESOURCE_ITEM.NETHERITE_SWORD, RESOURCE_ITEM.BREEZE_ROD, RESOURCE_ITEM.HEAVY_CORE,
        RESOURCE_ITEM.DIAMOND_SWORD, RESOURCE_ITEM.RUBY_SWORD, RESOURCE_ITEM.IRON_SWORD, RESOURCE_ITEM.GOLD_SWORD,
        RESOURCE_ITEM.DIAMOND_PICKAXE, RESOURCE_ITEM.RUBY_PICKAXE, RESOURCE_ITEM.IRON_PICKAXE, RESOURCE_ITEM.GOLD_PICKAXE,
        RESOURCE_ITEM.DIAMOND_AXE, RESOURCE_ITEM.RUBY_AXE, RESOURCE_ITEM.IRON_AXE, RESOURCE_ITEM.GOLD_AXE,
        RESOURCE_ITEM.DIAMOND_SHOVEL, RESOURCE_ITEM.RUBY_SHOVEL, RESOURCE_ITEM.IRON_SHOVEL, RESOURCE_ITEM.GOLD_SHOVEL,
        RESOURCE_ITEM.DIAMOND_HELMET, RESOURCE_ITEM.DIAMOND_CHESTPLATE, RESOURCE_ITEM.DIAMOND_LEGGINGS, RESOURCE_ITEM.DIAMOND_BOOTS,
        RESOURCE_ITEM.RUBY_HELMET, RESOURCE_ITEM.RUBY_CHESTPLATE, RESOURCE_ITEM.RUBY_LEGGINGS, RESOURCE_ITEM.RUBY_BOOTS,
        RESOURCE_ITEM.IRON_HELMET, RESOURCE_ITEM.IRON_CHESTPLATE, RESOURCE_ITEM.IRON_LEGGINGS, RESOURCE_ITEM.IRON_BOOTS,
        RESOURCE_ITEM.GOLD_HELMET, RESOURCE_ITEM.GOLD_CHESTPLATE, RESOURCE_ITEM.GOLD_LEGGINGS, RESOURCE_ITEM.GOLD_BOOTS,
        RESOURCE_ITEM.LEATHER_HELMET, RESOURCE_ITEM.LEATHER_CHESTPLATE, RESOURCE_ITEM.LEATHER_LEGGINGS, RESOURCE_ITEM.LEATHER_BOOTS
    ].map((id) => ({ kind: 'resource' as const, id })),
    food: [
        { kind: 'resource' as const, id: RESOURCE_ITEM.APPLE },
        { kind: 'resource' as const, id: RESOURCE_ITEM.BREAD },
        { kind: 'resource' as const, id: RESOURCE_ITEM.STICK },
        { kind: 'block' as const, id: BLOCK_ID.CHEST }
    ]
};

export type ArmorSlotType = 'helmet' | 'chestplate' | 'leggings' | 'boots';

export interface EquippedArmor {
    helmet: string | null;
    chestplate: string | null;
    leggings: string | null;
    boots: string | null;
}

export class InventorySystem {
    hotbar: Array<{ kind: 'block' | 'resource'; id: any; durability?: number; maxDurability?: number } | null>;
    selected: number;
    blockCounts: Map<number, number>;
    resourceCounts: Map<string, number>;
    creativeMode: boolean;
    fullCatalogInSurvival: boolean;
    onChange: (() => void) | null;
    expandedVisible: boolean;
    survival: SurvivalSystem | null;
    panel: HTMLElement | null;
    grid: HTMLElement | null;
    selectedNameEl: HTMLElement | null;
    creativeTab: 'building' | 'natural' | 'ores' | 'tools' | 'food' | 'search' = 'building';
    searchQuery = '';
    mainInventory: Array<{ kind: 'block' | 'resource'; id: any; count: number; durability?: number; maxDurability?: number } | null> = new Array(27).fill(null);
    crafting2x2: Array<{ kind: 'block' | 'resource'; id: any; count: number } | null> = new Array(4).fill(null);
    crafting2x2Output: { kind: 'block' | 'resource'; id: any; count: number } | null = null;
    uiEventsBound = false;
    armor: EquippedArmor = {
        helmet: null,
        chestplate: null,
        leggings: null,
        boots: null
    };

    constructor() {
        this.hotbar = new Array(9).fill(null);
        this.selected = 0;
        this.blockCounts = new Map();
        this.resourceCounts = new Map();
        this.creativeMode = false;
        this.fullCatalogInSurvival = true;
        this.onChange = null;
        this.expandedVisible = false;
        this.survival = null;
        this.panel = document.getElementById('inventory-panel');
        this.grid = document.getElementById('inventory-grid');
        this.selectedNameEl = document.getElementById('selected-item-name');
        this.setupUIEvents();
        this.render();
    }

    setupUIEvents() {
        if (this.uiEventsBound) return;
        this.uiEventsBound = true;

        // Creative Tabs
        const tabBtns = document.querySelectorAll('.creative-tab');
        tabBtns.forEach((btn) => {
            btn.addEventListener('click', () => {
                const tab = btn.getAttribute('data-tab') as any;
                if (!tab) return;
                this.creativeTab = tab;
                tabBtns.forEach((b) => b.classList.remove('active'));
                btn.classList.add('active');

                const searchInput = document.getElementById('inventory-search') as HTMLInputElement;
                if (tab !== 'search' && searchInput) {
                    searchInput.value = '';
                    this.searchQuery = '';
                } else if (tab === 'search' && searchInput) {
                    searchInput.focus();
                }
                this.renderExpanded();
            });
        });

        // Search icon button in header
        const searchIconBtn = document.getElementById('inventory-search-icon-btn');
        searchIconBtn?.addEventListener('click', () => {
            this.creativeTab = 'search';
            tabBtns.forEach((b) => {
                if (b.getAttribute('data-tab') === 'search') b.classList.add('active');
                else b.classList.remove('active');
            });
            const searchInput = document.getElementById('inventory-search') as HTMLInputElement;
            searchInput?.focus();
            this.renderExpanded();
        });

        // Search Input
        const searchInput = document.getElementById('inventory-search') as HTMLInputElement;
        searchInput?.addEventListener('input', () => {
            this.searchQuery = searchInput.value;
            if (this.searchQuery.trim().length > 0 && this.creativeTab !== 'search') {
                this.creativeTab = 'search';
                tabBtns.forEach((b) => {
                    if (b.getAttribute('data-tab') === 'search') b.classList.add('active');
                    else b.classList.remove('active');
                });
            }
            this.renderExpanded();
        });

        // Clear Search
        const searchClear = document.getElementById('inventory-search-clear');
        searchClear?.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            this.searchQuery = '';
            this.renderExpanded();
        });

        // Close button
        const closeBtn = document.getElementById('inventory-close-btn');
        closeBtn?.addEventListener('click', () => {
            this.hideExpanded();
            (window as any).app?.player?.controls?.lock();
        });
    }

    setSurvivalSystem(survival: SurvivalSystem) {
        this.survival = survival;
    }

    setOnChange(cb: () => void) {
        this.onChange = cb;
    }

    isExpandedVisible() {
        return this.expandedVisible;
    }

    toggleExpanded() {
        if (this.expandedVisible) this.hideExpanded();
        else this.showExpanded();
    }

    showExpanded() {
        this.expandedVisible = true;
        if (this.panel) this.panel.style.display = 'flex';
        this.renderExpanded();
    }

    hideExpanded() {
        this.expandedVisible = false;
        if (this.panel) this.panel.style.display = 'none';
    }

    clearAll() {
        this.hotbar = new Array(9).fill(null);
        this.mainInventory = new Array(27).fill(null);
        this.selected = 0;
        this.blockCounts.clear();
        this.resourceCounts.clear();
        this.hideExpanded();
        this.triggerChange();
    }

    triggerChange() {
        this.render();
        if (this.onChange) this.onChange();
    }

    isCreativeMode() {
        return this.creativeMode;
    }

    isInventoryOpen() {
        return this.expandedVisible;
    }

    setCreativeMode(enabled: boolean) {
        this.creativeMode = Boolean(enabled);
        if (this.creativeMode) {
            this.populateCreativeHotbarDefaults();
        } else {
            // User constraint: "do not give any item to the player in survival and hardcore mode. give unlimited items to the player in creative mode."
            this.hotbar = new Array(9).fill(null);
            this.mainInventory = new Array(27).fill(null);
            this.blockCounts.clear();
            this.resourceCounts.clear();
        }
        this.triggerChange();
    }

    populateCreativeHotbarDefaults() {
        for (let i = 0; i < this.hotbar.length; i++) {
            const blockId = HOTBAR_PLACEABLE_BLOCKS[i];
            if (blockId != null) {
                this.hotbar[i] = { kind: 'block', id: blockId };
            }
        }
        // Slot 8 (index 7): Wind Charge for immediate use and testing!
        this.hotbar[7] = { kind: 'resource', id: RESOURCE_ITEM.WIND_CHARGE };
        // Slot 9 (index 8): Heavy Mace for pairing with wind jump!
        this.hotbar[8] = { kind: 'resource', id: RESOURCE_ITEM.MACE };
    }

    getBlockCount(id: number): number {
        if (this.creativeMode) return 999;
        return this.blockCounts.get(id) || 0;
    }

    getResourceCount(id: string): number {
        if (this.creativeMode) return 999;
        return this.resourceCounts.get(id) || 0;
    }

    getCount(kind: 'block' | 'resource', id: any): number {
        if (kind === 'block') return this.getBlockCount(id);
        const count = this.getResourceCount(id);
        if (count > 0) return count;
        const mappedBlockId = getBlockIdForResourceId(id);
        if (mappedBlockId !== null) return this.getBlockCount(mappedBlockId);
        return count;
    }

    setCount(kind: 'block' | 'resource', id: any, value: number) {
        const map = (kind === 'block' ? this.blockCounts : this.resourceCounts) as Map<any, number>;
        if (value <= 0) map.delete(id);
        else map.set(id, value);
    }

    addBlock(id: number, count = 1) {
        if (!BLOCK_DEFS[id] || id === BLOCK_ID.AIR) return;
        this.setCount('block', id, this.getBlockCount(id) + count);
        this.ensureHotbarEntry({ kind: 'block', id });
        this.triggerChange();
    }

    addResource(id: string, count = 1) {
        if (!RESOURCE_DEFS[id]) return;
        this.setCount('resource', id, this.getResourceCount(id) + count);
        const isTool = isDurabilityTool(id);
        const maxDur = isTool ? getToolMaxDurability(id) : undefined;
        this.ensureHotbarEntry({
            kind: 'resource',
            id,
            durability: maxDur,
            maxDurability: maxDur
        });
        this.triggerChange();
    }

    addDrop(blockId: number) {
        this.addBlock(blockId, 1);
    }

    getArmorType(itemId: any): ArmorSlotType | null {
        if (typeof itemId !== 'string') return null;
        if (itemId.endsWith('_helmet') || itemId.includes('helmet')) return 'helmet';
        if (itemId.endsWith('_chestplate') || itemId.includes('chestplate')) return 'chestplate';
        if (itemId.endsWith('_leggings') || itemId.includes('leggings')) return 'leggings';
        if (itemId.endsWith('_boots') || itemId.includes('boots')) return 'boots';
        return null;
    }

    equipArmorPiece(pieceId: string): boolean {
        const slot = this.getArmorType(pieceId);
        if (!slot) return false;

        const oldPiece = this.armor[slot];
        this.armor[slot] = pieceId;

        if (oldPiece && !this.creativeMode) {
            this.addResource(oldPiece, 1);
        }

        this.survival?.recalculateArmor();
        const app = (window as any).app;
        app?.player?.updateArmorVisuals?.(this.armor);
        app?.audio?.playTone?.(320, 240, 0.12);

        const def = (RESOURCE_DEFS as any)[pieceId];
        app?.showHelpTipFor?.(`Equipped ${def?.label || pieceId} (+${def?.armor || 0} Armor)`, 2200);

        this.renderExpanded();
        this.render();
        return true;
    }

    unequipArmorPiece(slot: ArmorSlotType): boolean {
        const pieceId = this.armor[slot];
        if (!pieceId) return false;

        this.armor[slot] = null;
        if (!this.creativeMode) {
            this.addResource(pieceId, 1);
        }

        this.survival?.recalculateArmor();
        const app = (window as any).app;
        app?.player?.updateArmorVisuals?.(this.armor);
        app?.audio?.playTone?.(240, 180, 0.1);

        const def = (RESOURCE_DEFS as any)[pieceId];
        app?.showHelpTipFor?.(`Unequipped ${def?.label || pieceId}`, 1800);

        this.renderExpanded();
        this.render();
        return true;
    }

    equipArmorFromHand(pieceId: string): boolean {
        const slot = this.getArmorType(pieceId);
        if (!slot) return false;

        const oldPiece = this.armor[slot];
        if (!this.creativeMode) {
            this.consumeSelectedBlock();
        }

        this.armor[slot] = pieceId;

        if (oldPiece && !this.creativeMode) {
            if (this.hotbar[this.selected] === null) {
                this.hotbar[this.selected] = { kind: 'resource', id: oldPiece };
            } else {
                this.addResource(oldPiece, 1);
            }
        }

        this.survival?.recalculateArmor();
        const app = (window as any).app;
        app?.player?.updateArmorVisuals?.(this.armor);
        app?.audio?.playTone?.(320, 240, 0.12);

        const def = (RESOURCE_DEFS as any)[pieceId];
        app?.showHelpTipFor?.(`Equipped ${def?.label || pieceId} (+${def?.armor || 0} Armor)`, 2500);

        this.renderExpanded();
        this.render();
        return true;
    }

    ensureHotbarEntry(entry: { kind: 'block' | 'resource'; id: any; durability?: number; maxDurability?: number }) {
        const exists = this.hotbar.find((s) => s && s.kind === entry.kind && s.id === entry.id);
        if (exists) {
            if (entry.kind === 'resource' && isDurabilityTool(entry.id)) {
                if (exists.maxDurability === undefined) exists.maxDurability = getToolMaxDurability(entry.id);
                if (exists.durability === undefined) exists.durability = exists.maxDurability;
            }
            return;
        }
        const firstEmpty = this.hotbar.findIndex((s) => s === null);
        if (firstEmpty !== -1) {
            if (entry.kind === 'resource' && isDurabilityTool(entry.id)) {
                entry.maxDurability = entry.maxDurability || getToolMaxDurability(entry.id);
                entry.durability = entry.durability ?? entry.maxDurability;
            }
            this.hotbar[firstEmpty] = entry;
        }
    }

    selectSlot(idx: number) {
        this.selected = MathKernel.clamp(idx, 0, this.hotbar.length - 1);
        this.render();
        this.updateSelectedName();
    }

    getSelected(): { kind: 'block' | 'resource'; id: any } | null {
        return this.getSelectedEntry();
    }

    getSelectedEntry(): { kind: 'block' | 'resource'; id: any } | null {
        const slot = this.hotbar[this.selected];
        if (!slot) return null;
        if (this.getCount(slot.kind, slot.id) <= 0) return null;
        return slot;
    }

    getSelectedBlockId(): number | null {
        const entry = this.getSelectedEntry();
        if (!entry) return null;
        if (entry.kind === 'block') return entry.id;
        return getBlockIdForResourceId(entry.id);
    }

    consumeSelectedEntry() {
        const entry = this.getSelectedEntry();
        if (!entry) return null;
        if (this.creativeMode) return { kind: entry.kind, id: entry.id, count: 1 };

        const now = this.getCount(entry.kind, entry.id) - 1;
        this.setCount(entry.kind, entry.id, now);
        if (now <= 0) this.hotbar[this.selected] = null;
        this.triggerChange();
        return { kind: entry.kind, id: entry.id, count: 1 };
    }

    consumeSelectedBlock(): boolean {
        return this.consumeSelectedEntry() !== null;
    }

    hasIngredients(recipe: any): boolean {
        if (this.creativeMode) return true;
        for (const req of recipe.in) {
            if (this.getCount(req.kind, req.id) < req.count) return false;
        }
        return true;
    }

    consumeIngredients(recipe: any) {
        if (this.creativeMode) return;
        for (const req of recipe.in) {
            this.setCount(req.kind, req.id, this.getCount(req.kind, req.id) - req.count);
        }
    }

    grantOutput(output: any) {
        if (output.kind === 'block') this.addBlock(output.id, output.count);
        else this.addResource(output.id, output.count);
    }

    getEntryLabel(slot: { kind: 'block' | 'resource'; id: any } | null): string {
        if (!slot) return '';
        if (slot.kind === 'block') {
            const key = Object.keys(BLOCK_ID).find((k) => (BLOCK_ID as any)[k] === slot.id) || 'BLOCK';
            return key.replace(/_/g, ' ');
        }
        return RESOURCE_DEFS[slot.id]?.label || slot.id;
    }

    getEntryColor(slot: { kind: 'block' | 'resource'; id: any } | null): string {
        if (!slot) return '#666';
        if (slot.kind === 'block') {
            const def = BLOCK_DEFS[slot.id];
            return def ? `#${def.color.toString(16).padStart(6, '0')}` : '#666';
        }
        return RESOURCE_DEFS[slot.id]?.color || '#bdbdbd';
    }

    updateSelectedName(entry = this.getSelectedEntry()) {
        if (!this.selectedNameEl) this.selectedNameEl = document.getElementById('selected-item-name');
        if (!this.selectedNameEl) return;
        if (!entry) {
            this.selectedNameEl.innerText = 'EMPTY SLOT';
            this.selectedNameEl.style.opacity = '0.75';
            return;
        }
        let label = this.getEntryLabel(entry);
        if (entry.kind === 'resource' && isDurabilityTool(entry.id)) {
            const cur = (entry as any).durability ?? (entry as any).maxDurability ?? getToolMaxDurability(entry.id);
            const max = (entry as any).maxDurability ?? getToolMaxDurability(entry.id);
            label += ` (${cur}/${max})`;
        }
        this.selectedNameEl.innerText = label;
        this.selectedNameEl.style.opacity = '1';
    }

    renderDurabilityBar(slotDiv: HTMLElement, slot: { kind: 'block' | 'resource'; id: any; durability?: number; maxDurability?: number } | null): boolean {
        if (!slot || slot.kind !== 'resource' || !isDurabilityTool(slot.id)) return false;

        if (slot.maxDurability === undefined) {
            slot.maxDurability = getToolMaxDurability(slot.id);
        }
        if (slot.durability === undefined) {
            slot.durability = slot.maxDurability;
        }

        const ratio = Math.max(0, Math.min(1, slot.durability / slot.maxDurability));
        const pct = ratio * 100;

        let barColor = '#2ecc71'; // Green (> 60%)
        if (ratio <= 0.25) {
            barColor = '#e74c3c'; // Red (<= 25%)
        } else if (ratio <= 0.60) {
            barColor = '#f39c12'; // Amber/Orange (25% - 60%)
        }

        const durTrack = document.createElement('div');
        durTrack.className = 'durability-bar-track';
        const durFill = document.createElement('div');
        durFill.className = 'durability-bar-fill';
        durFill.style.width = `${pct}%`;
        durFill.style.backgroundColor = barColor;
        durTrack.appendChild(durFill);
        slotDiv.appendChild(durTrack);

        slotDiv.title = `${this.getEntryLabel(slot)} (${slot.durability}/${slot.maxDurability})`;
        return true;
    }

    render() {
        const bar = document.getElementById('inventory-bar');
        if (!bar) return;
        bar.innerHTML = '';
        for (let i = 0; i < 9; i++) {
            const slot = this.hotbar[i];
            const slotDiv = document.createElement('div');
            slotDiv.className = `inv-slot ${i === this.selected ? 'selected' : ''}`;
            slotDiv.style.cursor = 'pointer';
            slotDiv.addEventListener('click', () => this.selectSlot(i));

            if (slot && this.getCount(slot.kind, slot.id) > 0) {
                const icon = document.createElement('div');
                icon.className = 'slot-icon';
                const tex = getItemTexture(slot);
                if (tex) {
                    icon.style.backgroundImage = `url(${tex})`;
                    icon.style.backgroundSize = 'contain';
                    icon.style.backgroundRepeat = 'no-repeat';
                    icon.style.backgroundPosition = 'center';
                    icon.style.imageRendering = 'pixelated';
                } else {
                    icon.style.background = this.getEntryColor(slot);
                }
                slotDiv.appendChild(icon);

                const hasBar = this.renderDurabilityBar(slotDiv, slot);
                if (!hasBar) {
                    const count = document.createElement('div');
                    count.className = 'slot-count';
                    count.innerText = this.creativeMode ? 'INF' : `${this.getCount(slot.kind, slot.id)}`;
                    slotDiv.appendChild(count);
                    slotDiv.title = this.getEntryLabel(slot);
                }
            } else {
                const empty = document.createElement('div');
                empty.className = 'slot-empty';
                empty.innerText = `${i + 1}`;
                slotDiv.appendChild(empty);
            }
            bar.appendChild(slotDiv);
        }
        this.renderExpanded();
    }

    renderExpanded() {
        const grid = this.grid || document.getElementById('inventory-grid');
        if (!grid) return;
        grid.innerHTML = '';

        const panelTitle = document.getElementById('inventory-title');
        const tabsBar = document.getElementById('creative-tabs-bar');
        const searchRow = document.getElementById('inventory-search-row');
        const craftingSection = document.getElementById('survival-crafting-section');
        const hotbarGrid = document.getElementById('inventory-hotbar-grid');

        if (this.creativeMode) {
            if (panelTitle) panelTitle.innerText = 'CREATIVE INVENTORY';
            if (tabsBar) tabsBar.style.display = 'flex';
            if (searchRow) searchRow.style.display = 'flex';
            if (craftingSection) craftingSection.style.display = 'none';

            // Select items according to tab or search
            let itemsToDisplay: Array<{ kind: 'block' | 'resource'; id: any }> = [];
            const isSearch = this.creativeTab === 'search' || this.searchQuery.trim().length > 0;

            if (isSearch) {
                const allItems: Array<{ kind: 'block' | 'resource'; id: any }> = [];
                CREATIVE_BLOCK_INVENTORY.forEach((id) => allItems.push({ kind: 'block', id }));
                Object.keys(RESOURCE_DEFS).forEach((id) => allItems.push({ kind: 'resource', id }));

                const q = this.searchQuery.trim().toLowerCase();
                itemsToDisplay = q ? allItems.filter((item) => this.getEntryLabel(item).toLowerCase().includes(q)) : allItems;
            } else {
                itemsToDisplay = (CREATIVE_TABS as any)[this.creativeTab] || [];
            }

            itemsToDisplay.forEach((item) => {
                const slotDiv = document.createElement('div');
                slotDiv.className = 'inv-slot inventory-slot';
                slotDiv.style.cursor = 'pointer';

                const icon = document.createElement('div');
                icon.className = 'slot-icon';
                const tex = getItemTexture(item);
                if (tex) {
                    icon.style.backgroundImage = `url(${tex})`;
                    icon.style.backgroundSize = 'contain';
                    icon.style.backgroundRepeat = 'no-repeat';
                    icon.style.backgroundPosition = 'center';
                    icon.style.imageRendering = 'pixelated';
                } else {
                    icon.style.background = this.getEntryColor(item);
                }
                slotDiv.appendChild(icon);

                slotDiv.title = this.getEntryLabel(item);
                slotDiv.addEventListener('click', () => {
                    this.hotbar[this.selected] = item;
                    this.render();
                    this.updateSelectedName(item);
                });
                grid.appendChild(slotDiv);
            });

            // Render In-Window Hotbar
            if (hotbarGrid) {
                hotbarGrid.innerHTML = '';
                for (let i = 0; i < 9; i++) {
                    const hSlot = this.hotbar[i];
                    const hDiv = document.createElement('div');
                    hDiv.className = `inv-slot ${i === this.selected ? 'selected' : ''}`;
                    hDiv.style.cursor = 'pointer';
                    hDiv.addEventListener('click', () => {
                        this.selectSlot(i);
                        this.renderExpanded();
                    });

                    if (hSlot) {
                        const icon = document.createElement('div');
                        icon.className = 'slot-icon';
                        const tex = getItemTexture(hSlot);
                        if (tex) {
                            icon.style.backgroundImage = `url(${tex})`;
                            icon.style.backgroundSize = 'contain';
                            icon.style.backgroundRepeat = 'no-repeat';
                            icon.style.backgroundPosition = 'center';
                            icon.style.imageRendering = 'pixelated';
                        } else {
                            icon.style.background = this.getEntryColor(hSlot);
                        }
                        hDiv.appendChild(icon);

                        const count = document.createElement('div');
                        count.className = 'slot-count';
                        count.innerText = 'INF';
                        hDiv.appendChild(count);
                        hDiv.title = this.getEntryLabel(hSlot);
                    } else {
                        const empty = document.createElement('div');
                        empty.className = 'slot-empty';
                        empty.innerText = `${i + 1}`;
                        hDiv.appendChild(empty);
                    }
                    hotbarGrid.appendChild(hDiv);
                }

                // Trash / Delete slot button
                const trashSlot = document.createElement('div');
                trashSlot.className = 'inv-slot';
                trashSlot.style.cursor = 'pointer';
                trashSlot.style.border = '2px dashed #e74c3c';
                trashSlot.title = 'Clear selected slot';
                const trashIcon = document.createElement('div');
                trashIcon.innerText = '🗑️';
                trashIcon.style.fontSize = '16px';
                trashIcon.style.display = 'flex';
                trashIcon.style.alignItems = 'center';
                trashIcon.style.justifyContent = 'center';
                trashIcon.style.width = '100%';
                trashIcon.style.height = '100%';
                trashSlot.appendChild(trashIcon);
                trashSlot.addEventListener('click', () => {
                    this.hotbar[this.selected] = null;
                    this.render();
                });
                hotbarGrid.appendChild(trashSlot);
            }

        } else {
            // Survival / Hardcore Mode
            const modeName = this.survival?.isHardcore() ? 'HARDCORE INVENTORY' : 'SURVIVAL INVENTORY';
            if (panelTitle) panelTitle.innerText = modeName;
            if (tabsBar) tabsBar.style.display = 'none';
            if (searchRow) searchRow.style.display = 'none';

            // Populate Armor slots and Crafting header in Survival Section
            if (craftingSection) {
                craftingSection.style.display = 'flex';
                craftingSection.innerHTML = '';

                // Left: 4 Armor Slots
                const armorBox = document.createElement('div');
                armorBox.className = 'survival-armor-box';
                armorBox.style.display = 'flex';
                armorBox.style.gap = '6px';
                armorBox.style.alignItems = 'center';

                const armorSlots: Array<{ type: ArmorSlotType; icon: string; name: string }> = [
                    { type: 'helmet', icon: '⛑️', name: 'Helmet' },
                    { type: 'chestplate', icon: '🦺', name: 'Chestplate' },
                    { type: 'leggings', icon: '👖', name: 'Leggings' },
                    { type: 'boots', icon: '🥾', name: 'Boots' }
                ];

                armorSlots.forEach((slotInfo) => {
                    const slotDiv = document.createElement('div');
                    slotDiv.className = 'inventory-armor-slot';
                    const equippedId = this.armor[slotInfo.type];

                    if (equippedId) {
                        const icon = document.createElement('div');
                        icon.className = 'slot-icon';
                        const tex = getItemTexture({ kind: 'resource', id: equippedId });
                        if (tex) {
                            icon.style.backgroundImage = `url(${tex})`;
                            icon.style.backgroundSize = 'contain';
                            icon.style.backgroundRepeat = 'no-repeat';
                            icon.style.backgroundPosition = 'center';
                            icon.style.imageRendering = 'pixelated';
                        }
                        slotDiv.appendChild(icon);
                        const def = (RESOURCE_DEFS as any)[equippedId];
                        slotDiv.title = `${def?.label || equippedId} (+${def?.armor || 0} Armor) - Click to unequip`;
                        slotDiv.addEventListener('click', () => {
                            this.unequipArmorPiece(slotInfo.type);
                        });
                    } else {
                        const empty = document.createElement('div');
                        empty.className = 'slot-empty';
                        empty.innerText = slotInfo.icon;
                        empty.style.fontSize = '18px';
                        empty.style.opacity = '0.55';
                        slotDiv.appendChild(empty);
                        slotDiv.title = `${slotInfo.name} Slot - Hold armor in hand & click to equip, or right-click in world`;

                        slotDiv.addEventListener('click', () => {
                            const cur = this.hotbar[this.selected];
                            if (cur && cur.kind === 'resource' && this.getArmorType(cur.id) === slotInfo.type) {
                                this.equipArmorFromHand(cur.id);
                            }
                        });
                    }
                    armorBox.appendChild(slotDiv);
                });
                craftingSection.appendChild(armorBox);

                // Center: Character Status preview badge
                const statusBox = document.createElement('div');
                statusBox.style.display = 'flex';
                statusBox.style.flexDirection = 'column';
                statusBox.style.alignItems = 'center';
                statusBox.style.justifyContent = 'center';
                statusBox.style.padding = '0 10px';
                const pts = this.survival?.armorPoints || 0;
                statusBox.innerHTML = `
                    <div style="font-size:11px; font-weight:bold; color:#f0f0f0; text-shadow:1px 1px #000;">ARMOR DEFENSE</div>
                    <div style="font-size:13px; font-weight:bold; color:#72b6ff; text-shadow:1px 1px #000;">🛡️ ${pts} / 20 pts</div>
                    <div style="font-size:9px; color:#e0e0e0;">-${Math.round(pts * 4)}% damage taken</div>
                `;
                craftingSection.appendChild(statusBox);

                // Right: 3x3 Crafting Table & Recipes Shortcut
                const craftBox = document.createElement('div');
                craftBox.className = 'survival-craft-box';
                craftBox.innerHTML = `
                    <div style="display:flex; flex-direction:column; align-items:center; gap:3px;">
                        <span style="font-size:10px; font-weight:bold; color:#eee;">CRAFTING</span>
                        <button id="btn-open-craft-table" class="menu-small-btn" style="padding:4px 8px; font-size:10px; background:#4a4a4a; color:#fff; border:1px solid #777; cursor:pointer;" title="Open 3x3 Crafting Table (Key: C)">3x3 TABLE</button>
                    </div>
                `;
                const openTableBtn = craftBox.querySelector('#btn-open-craft-table');
                openTableBtn?.addEventListener('click', () => {
                    this.hideExpanded();
                    const overlay = document.getElementById('mc-craft-overlay');
                    if (overlay) {
                        overlay.classList.add('open');
                        (window as any).app?.player?.controls?.unlock();
                    }
                });
                craftingSection.appendChild(craftBox);
            }

            // Render 27 main inventory slots in grid
            for (let i = 0; i < 27; i++) {
                const slotItem = this.mainInventory[i];
                const slotDiv = document.createElement('div');
                slotDiv.className = 'inv-slot inventory-slot';
                slotDiv.style.cursor = 'pointer';

                if (slotItem && slotItem.count > 0) {
                    const icon = document.createElement('div');
                    icon.className = 'slot-icon';
                    const tex = getItemTexture(slotItem);
                    if (tex) {
                        icon.style.backgroundImage = `url(${tex})`;
                        icon.style.backgroundSize = 'contain';
                        icon.style.backgroundRepeat = 'no-repeat';
                        icon.style.backgroundPosition = 'center';
                        icon.style.imageRendering = 'pixelated';
                    }
                    slotDiv.appendChild(icon);

                    const hasBar = this.renderDurabilityBar(slotDiv, slotItem);
                    if (!hasBar) {
                        const count = document.createElement('div');
                        count.className = 'slot-count';
                        count.innerText = `${slotItem.count}`;
                        slotDiv.appendChild(count);
                        slotDiv.title = this.getEntryLabel(slotItem);
                    }
                }

                // Right click or Shift-click to equip armor piece immediately
                slotDiv.addEventListener('contextmenu', (e) => {
                    e.preventDefault();
                    if (slotItem && slotItem.kind === 'resource') {
                        const armorType = this.getArmorType(slotItem.id);
                        if (armorType) {
                            this.equipArmorPiece(slotItem.id);
                            slotItem.count--;
                            if (slotItem.count <= 0) this.mainInventory[i] = null;
                            this.renderExpanded();
                            return;
                        }
                    }
                });

                // Click to swap with currently selected hotbar slot, or Shift-click to equip
                slotDiv.addEventListener('click', (e) => {
                    if (e.shiftKey && slotItem && slotItem.kind === 'resource') {
                        const armorType = this.getArmorType(slotItem.id);
                        if (armorType) {
                            this.equipArmorPiece(slotItem.id);
                            slotItem.count--;
                            if (slotItem.count <= 0) this.mainInventory[i] = null;
                            this.renderExpanded();
                            return;
                        }
                    }

                    const currentHotbar = this.hotbar[this.selected];
                    const currentHotbarCount = currentHotbar ? this.getCount(currentHotbar.kind, currentHotbar.id) : 0;

                    const tempInv = this.mainInventory[i];
                    this.mainInventory[i] = currentHotbar ? {
                        kind: currentHotbar.kind,
                        id: currentHotbar.id,
                        count: currentHotbarCount,
                        durability: currentHotbar.durability,
                        maxDurability: currentHotbar.maxDurability
                    } : null;

                    if (tempInv) {
                        this.hotbar[this.selected] = {
                            kind: tempInv.kind,
                            id: tempInv.id,
                            durability: tempInv.durability,
                            maxDurability: tempInv.maxDurability
                        };
                        this.setCount(tempInv.kind, tempInv.id, tempInv.count);
                    } else {
                        this.hotbar[this.selected] = null;
                    }
                    this.render();
                });

                grid.appendChild(slotDiv);
            }

            // Render In-Window Hotbar
            if (hotbarGrid) {
                hotbarGrid.innerHTML = '';
                for (let i = 0; i < 9; i++) {
                    const hSlot = this.hotbar[i];
                    const hDiv = document.createElement('div');
                    hDiv.className = `inv-slot ${i === this.selected ? 'selected' : ''}`;
                    hDiv.style.cursor = 'pointer';
                    hDiv.addEventListener('click', () => {
                        this.selectSlot(i);
                        this.renderExpanded();
                    });

                    if (hSlot && this.getCount(hSlot.kind, hSlot.id) > 0) {
                        const icon = document.createElement('div');
                        icon.className = 'slot-icon';
                        const tex = getItemTexture(hSlot);
                        if (tex) {
                            icon.style.backgroundImage = `url(${tex})`;
                            icon.style.backgroundSize = 'contain';
                            icon.style.backgroundRepeat = 'no-repeat';
                            icon.style.backgroundPosition = 'center';
                            icon.style.imageRendering = 'pixelated';
                        }
                        hDiv.appendChild(icon);

                        const hasBar = this.renderDurabilityBar(hDiv, hSlot);
                        if (!hasBar) {
                            const count = document.createElement('div');
                            count.className = 'slot-count';
                            count.innerText = `${this.getCount(hSlot.kind, hSlot.id)}`;
                            hDiv.appendChild(count);
                            hDiv.title = this.getEntryLabel(hSlot);
                        }
                    } else {
                        const empty = document.createElement('div');
                        empty.className = 'slot-empty';
                        empty.innerText = `${i + 1}`;
                        hDiv.appendChild(empty);
                    }
                    hotbarGrid.appendChild(hDiv);
                }
            }
        }
    }

    getPersistentState() {
        return {
            selected: this.selected,
            hotbar: this.hotbar.map((slot) => (slot ? { kind: slot.kind, id: slot.id } : null)),
            blockCounts: Array.from(this.blockCounts.entries()),
            resourceCounts: Array.from(this.resourceCounts.entries())
        };
    }

    loadPersistentState(snapshot: any): boolean {
        if (!snapshot) return false;
        this.selected = snapshot.selected || 0;
        this.render();
        return true;
    }
}

export class SurvivalSystem {
    maxHealth = 20;
    maxHunger = 20;
    health = 20;
    hunger = 20;
    gameMode = 'Survival';
    armorPoints = 0;
    equipped: Record<string, string | null> = { helmet: null, chestplate: null, leggings: null, boots: null };
    inventory: InventorySystem | null = null;
    damageCooldown = 0;
    healTimer = 0;
    starveTimer = 0;
    difficulty = 'normal';
    masterVolume = 100;

    constructor() {
        this.updateBars();
    }

    setInventorySystem(inv: InventorySystem) {
        this.inventory = inv;
    }

    setGameMode(mode: string) {
        this.gameMode = mode;
        if (this.gameMode === 'Creative') {
            this.health = this.maxHealth;
            this.hunger = this.maxHunger;
        }
        this.updateBars();
    }

    isCreative() {
        return this.gameMode === 'Creative';
    }

    isHardcore() {
        return this.gameMode === 'Hardcore';
    }

    resetForRespawn() {
        this.health = this.maxHealth;
        this.hunger = this.maxHunger;
        this.healTimer = 0;
        this.starveTimer = 0;
        this.updateBars();
    }

    updateBars() {
        const statusBars = document.getElementById('status-bars');
        if (statusBars) {
            statusBars.style.display = this.isCreative() ? 'none' : 'flex';
        }
        const heartsContainer = document.getElementById('health-hearts');
        if (heartsContainer) {
            heartsContainer.innerHTML = '';
            for (let i = 0; i < 10; i++) {
                const h = document.createElement('div');
                h.className = 'heart';
                const heartHp = (i + 1) * 2;
                let fill = '0%';
                if (this.health >= heartHp) {
                    fill = '100%';
                } else if (this.health >= heartHp - 1) {
                    fill = '50%';
                }
                h.style.setProperty('--fill', fill);
                heartsContainer.appendChild(h);
            }
        }
        const hungerFill = document.getElementById('hunger-fill');
        if (hungerFill) {
            const hungerPct = Math.max(0, Math.min(100, (this.hunger / this.maxHunger) * 100));
            hungerFill.style.width = `${hungerPct}%`;
        }
        const armorFill = document.getElementById('armor-fill');
        if (armorFill) {
            armorFill.style.width = `${Math.min(100, (this.armorPoints / 20) * 100)}%`;
        }
    }

    damage(amount: number) {
        if (this.isCreative() || this.damageCooldown > 0) return;
        // Minecraft authentic armor reduction formula: 4% damage reduction per armor point, up to 80%
        const reduction = Math.min(0.80, this.armorPoints * 0.04);
        const finalDamage = Math.max(0.5, amount * (1 - reduction));
        this.health = Math.max(0, this.health - finalDamage);
        this.damageCooldown = 0.4;
        const hurtOverlay = document.getElementById('hurt-overlay');
        if (hurtOverlay) {
            hurtOverlay.classList.remove('flash');
            void hurtOverlay.offsetWidth;
            hurtOverlay.classList.add('flash');
        }
        this.updateBars();
    }

    heal(amount: number) {
        if (this.isCreative()) return;
        this.health = Math.min(this.maxHealth, this.health + amount);
        this.updateBars();
    }

    addHunger(delta: number) {
        if (this.isCreative()) return;
        this.hunger = MathKernel.clamp(this.hunger + delta, 0, this.maxHunger);
        this.updateBars();
    }

    eat(hungerPoints = 4) {
        if (this.isCreative()) return;
        this.addHunger(hungerPoints);
    }

    onMineAction() { this.addHunger(-0.008); }
    onJumpAction() { this.addHunger(-0.02); }

    recalculateArmor() {
        let total = 0;
        const armor = this.inventory?.armor || (window as any).app?.inventory?.armor || this.equipped;
        if (armor) {
            for (const piece of Object.values(armor)) {
                if (piece && typeof piece === 'string') {
                    const def = (RESOURCE_DEFS as any)[piece];
                    if (def && typeof def.armor === 'number') {
                        total += def.armor;
                    }
                }
            }
        }
        this.armorPoints = Math.min(20, total);
        this.updateBars();
    }

    update(dt: number, isMoving: boolean, isSprinting: boolean) {
        if (this.isCreative()) return;
        this.damageCooldown = Math.max(0, this.damageCooldown - dt);

        // Minecraft authentic Natural Regeneration:
        // When hunger bar is full (20) or high (>= 18), heal hearts!
        if (this.health < this.maxHealth) {
            if (this.hunger >= 20) {
                // Fast natural regeneration when hunger is full: heals 1 HP (0.5 heart) every 1.0 second
                this.healTimer += dt;
                if (this.healTimer >= 1.0) {
                    this.healTimer = 0;
                    this.heal(1);
                    this.hunger = Math.max(0, this.hunger - 0.2);
                    this.updateBars();
                }
            } else if (this.hunger >= 18) {
                // Standard natural regeneration: heals 1 HP every 2.5 seconds
                this.healTimer += dt;
                if (this.healTimer >= 2.5) {
                    this.healTimer = 0;
                    this.heal(1);
                    this.hunger = Math.max(0, this.hunger - 0.35);
                    this.updateBars();
                }
            } else {
                this.healTimer = 0;
            }
        } else {
            this.healTimer = 0;
        }

        // Slight activity exhaustion
        if (isSprinting) {
            this.addHunger(-0.06 * dt);
        } else if (isMoving) {
            this.addHunger(-0.012 * dt);
        }

        // Starvation damage when hunger is completely empty (0)
        if (this.hunger <= 0) {
            this.starveTimer += dt;
            if (this.starveTimer >= 4.0) {
                this.starveTimer = 0;
                if (this.health > 1 || this.isHardcore()) {
                    this.damage(1);
                }
            }
        } else {
            this.starveTimer = 0;
        }
    }

    getPersistentState() {
        return {
            health: this.health,
            hunger: this.hunger,
            gameMode: this.gameMode
        };
    }

    loadPersistentState(snapshot: any) {
        if (!snapshot) return;
        this.health = snapshot.health ?? 20;
        this.hunger = snapshot.hunger ?? 20;
        this.gameMode = snapshot.gameMode || 'Survival';
        this.updateBars();
    }
}

export class CraftingSystem {
    inventory: InventorySystem;
    survival: SurvivalSystem;
    panel: HTMLElement | null;
    list: HTMLElement | null;
    visible = false;

    constructor(inventory: InventorySystem, survival: SurvivalSystem) {
        this.inventory = inventory;
        this.survival = survival;
        this.panel = document.getElementById('crafting-panel');
        this.list = document.getElementById('crafting-list');
        this.render();
    }

    toggle() {
        this.visible = !this.visible;
        if (this.panel) this.panel.style.display = this.visible ? 'flex' : 'none';
        this.render();
    }

    hide() {
        this.visible = false;
        if (this.panel) this.panel.style.display = 'none';
    }

    craft(recipe: any) {
        if (!this.inventory.hasIngredients(recipe)) return;
        this.inventory.consumeIngredients(recipe);
        this.inventory.grantOutput(recipe.output);
        this.inventory.triggerChange();
        this.render();
    }

    render() {
        if (!this.list) return;
        this.list.innerHTML = '';
        CRAFTING_RECIPES.forEach((recipe) => {
            const canCraft = this.inventory.hasIngredients(recipe);
            const row = document.createElement('div');
            row.className = 'craft-row';

            const text = document.createElement('div');
            text.innerText = recipe.label;
            row.appendChild(text);

            const btn = document.createElement('button');
            btn.innerText = 'Craft';
            btn.disabled = !canCraft;
            btn.onclick = () => this.craft(recipe);
            row.appendChild(btn);

            this.list!.appendChild(row);
        });
    }
}

export class DroppedItemManager {
    scene: THREE.Scene;
    world: VoxelWorld;
    inventory: InventorySystem;
    audio: any;
    items: Array<{
        entry: { kind: 'block' | 'resource'; id: any; count?: number };
        mesh: THREE.Object3D;
        vel: THREE.Vector3;
        pickupDelay: number;
        age: number;
        life: number;
        onGround: boolean;
        baseY: number;
    }> = [];

    constructor(scene: THREE.Scene, world: VoxelWorld, inventory: InventorySystem, audio: any = null) {
        this.scene = scene;
        this.world = world;
        this.inventory = inventory;
        this.audio = audio;
    }

    getCount() { return this.items.length; }

    spawn(entry: { kind: 'block' | 'resource'; id: any; count?: number }, position: THREE.Vector3, velocity?: THREE.Vector3, pickupDelay = 0.4) {
        let mesh: THREE.Object3D;

        if (entry.kind === 'block') {
            const blockMat = this.world.materials[entry.id];
            const geo = new THREE.BoxGeometry(0.26, 0.26, 0.26);
            if (blockMat) {
                mesh = new THREE.Mesh(geo, blockMat);
            } else {
                const def = BLOCK_DEFS[entry.id];
                mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ color: def ? def.color : 0x888888 }));
            }
        } else {
            const texUrl = getItemTexture(entry);
            if (texUrl) {
                const tex = new THREE.TextureLoader().load(texUrl);
                tex.magFilter = THREE.NearestFilter;
                tex.minFilter = THREE.NearestFilter;
                const mat = new THREE.MeshLambertMaterial({
                    map: tex,
                    transparent: true,
                    alphaTest: 0.15,
                    side: THREE.DoubleSide
                });
                const geo = new THREE.PlaneGeometry(0.32, 0.32);
                mesh = new THREE.Mesh(geo, mat);
            } else {
                const geo = new THREE.BoxGeometry(0.2, 0.2, 0.2);
                mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ color: 0xd0a860 }));
            }
        }

        mesh.position.copy(position);
        this.scene.add(mesh);

        const vel = velocity ? velocity.clone() : new THREE.Vector3(
            (Math.random() - 0.5) * 2.0,
            2.8 + Math.random() * 1.5,
            (Math.random() - 0.5) * 2.0
        );

        this.items.push({
            entry,
            mesh,
            vel,
            pickupDelay,
            age: 0,
            life: 300,
            onGround: false,
            baseY: position.y
        });
    }

    update(dt: number, playerPos: THREE.Vector3) {
        for (let i = this.items.length - 1; i >= 0; i--) {
            const item = this.items[i];
            item.age += dt;
            item.pickupDelay = Math.max(0, item.pickupDelay - dt);
            item.life -= dt;

            // Rotation animation
            item.mesh.rotation.y += dt * 2.5;

            // Physics simulation
            if (!item.onGround) {
                item.vel.y += CONFIG.WORLD_GRAVITY * 60 * dt;
                item.vel.x *= 0.97;
                item.vel.z *= 0.97;

                const nextX = item.mesh.position.x + item.vel.x * dt;
                const nextY = item.mesh.position.y + item.vel.y * dt;
                const nextZ = item.mesh.position.z + item.vel.z * dt;

                // Collision with terrain
                const blockBelow = this.world.getVoxel(Math.floor(nextX), Math.floor(nextY - 0.13), Math.floor(nextZ));
                const blockDef = BLOCK_DEFS[blockBelow];

                if (blockDef && blockDef.solid) {
                    item.mesh.position.x = nextX;
                    item.mesh.position.z = nextZ;
                    item.mesh.position.y = Math.floor(nextY - 0.13) + 1.0 + 0.14;
                    item.baseY = item.mesh.position.y;
                    item.vel.set(0, 0, 0);
                    item.onGround = true;
                } else if (blockBelow === BLOCK_ID.WATER) {
                    // Floating in water
                    item.mesh.position.x = nextX;
                    item.mesh.position.z = nextZ;
                    item.vel.y = Math.sin(item.age * 3.0) * 0.3;
                    item.mesh.position.y += item.vel.y * dt;
                } else {
                    item.mesh.position.set(nextX, nextY, nextZ);
                }
            } else {
                // Check if ground beneath was mined away
                const checkBlock = this.world.getVoxel(
                    Math.floor(item.mesh.position.x),
                    Math.floor(item.baseY - 0.2),
                    Math.floor(item.mesh.position.z)
                );
                if (!BLOCK_DEFS[checkBlock]?.solid) {
                    item.onGround = false;
                } else {
                    // Gentle vertical bobbing when resting on block
                    item.mesh.position.y = item.baseY + Math.sin(item.age * 3.8) * 0.045;
                }
            }

            // Magnetic attraction to player & inventory pickup
            const distSq = item.mesh.position.distanceToSquared(playerPos);
            if (item.pickupDelay <= 0) {
                if (distSq < 6.25 && distSq >= 1.44) {
                    const attractDir = new THREE.Vector3().subVectors(playerPos, item.mesh.position).normalize();
                    item.mesh.position.addScaledVector(attractDir, 5.2 * dt);
                }

                if (distSq < 1.44) {
                    const count = item.entry.count || 1;
                    if (item.entry.kind === 'block') {
                        this.inventory.addBlock(item.entry.id, count);
                    } else {
                        this.inventory.addResource(item.entry.id, count);
                    }

                    if (this.audio?.playPop) {
                        this.audio.playPop();
                    } else if (this.audio?.playTone) {
                        this.audio.playTone(650, 920, 0.06);
                    }

                    this.scene.remove(item.mesh);
                    this.items.splice(i, 1);
                    continue;
                }
            }

            if (item.life <= 0 || item.mesh.position.y < -90) {
                this.scene.remove(item.mesh);
                this.items.splice(i, 1);
            }
        }
    }

    getPersistentState() { return []; }
    loadPersistentState(snapshot: any) {}
}

export class OnlineSessionManager {
    scene: THREE.Scene;
    world: VoxelWorld;
    connected = false;
    peerMap = new Map();
    username = 'Player';
    statusCb: any = null;

    constructor(scene: THREE.Scene, world: VoxelWorld) {
        this.scene = scene;
        this.world = world;
    }

    isActive() { return this.connected; }
    setStatus(msg: string) { if (this.statusCb) this.statusCb(msg); }
    setChatHandler(cb: any) {}
    setLocalAppearance(name: string, skin: string, custom: any = null) { this.username = name; }
    sanitizeName(name: string) { return name || 'Player'; }
    sanitizeCode(code: string) { return code || ''; }
    async connect(code: string, username: string, cb: any) { this.connected = true; return true; }
    async disconnect() { this.connected = false; }
    update(dt: number) {}
    getPeerRaycastTargets() { return []; }
    applyDamageToPeerFromHit(hit: any, dmg: number) { return false; }
    sendLocalState(cam: any, hp: number, item: any) {}
    sendBlockChange(x: number, y: number, z: number, id: number) {}
    sendChatMessage(text: string, kind = 'chat') { return true; }
    broadcastAppearance() {}
}
