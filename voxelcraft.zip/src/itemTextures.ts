import { BLOCK_ID, BLOCK_DEFS } from './constants';
import { createMinecraftBlockCanvas } from './minecraftTextures';

/* ==============================================================
   ITEM & BLOCK TEXTURE GENERATOR
   Renders pixel-perfect 16x16 and 32x32 isometric textures for
   every block and resource item in the game so they appear
   identical to their in-world appearance in inventory slots.
   ============================================================== */

const textureCache = new Map<string, string>();

function hash(x: number, y: number, seed = 1): number {
    const s = Math.sin(x * 127.1 + y * 311.7 + seed * 51.3) * 43758.5453;
    return s - Math.floor(s);
}

function clamp(v: number, min = 0, max = 255): number {
    return Math.max(min, Math.min(max, Math.round(v)));
}

// Generate a 16x16 canvas texture for a specific block face using authentic Minecraft textures
function renderBlockFace(blockId: number, face: 'top' | 'side' | 'bottom'): HTMLCanvasElement {
    return createMinecraftBlockCanvas(blockId, face);
}

function _legacyRenderBlockFace(blockId: number, face: 'top' | 'side' | 'bottom'): HTMLCanvasElement {
    const canvas = document.createElement('canvas');
    canvas.width = 16;
    canvas.height = 16;
    const ctx = canvas.getContext('2d')!;
    const px = (x: number, y: number, r: number, g: number, b: number, a = 255) => {
        ctx.fillStyle = `rgba(${r},${g},${b},${(a / 255).toFixed(3)})`;
        ctx.fillRect(x, y, 1, 1);
    };

    const def = BLOCK_DEFS[blockId];
    const baseColor = def ? def.color : 0x888888;
    const baseR = (baseColor >> 16) & 255;
    const baseG = (baseColor >> 8) & 255;
    const baseB = baseColor & 255;

    // Specific block face designs
    if (blockId === BLOCK_ID.GRASS) {
        if (face === 'top') {
            const grassCols = [
                [124, 189, 52], [116, 178, 48], [132, 202, 58], [108, 168, 42],
                [138, 210, 64], [100, 156, 36], [126, 192, 54], [112, 172, 44]
            ];
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const c = grassCols[Math.floor(hash(x, y, 12) * grassCols.length)];
                px(x, y, c[0], c[1], c[2]);
            }
        } else if (face === 'side') {
            const overhang = [3, 4, 3, 2, 4, 5, 4, 3, 3, 4, 5, 3, 2, 4, 5, 3];
            const dirtCols = [
                [134, 96, 67], [121, 85, 58], [147, 106, 75],
                [112, 78, 52], [140, 100, 70], [128, 90, 62]
            ];
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const depth = overhang[x % 16];
                if (y < depth) {
                    const s = 0.9 + hash(x, y, 4) * 0.2;
                    px(x, y, clamp(124 * s), clamp(189 * s), clamp(52 * s));
                } else if (y === depth) {
                    px(x, y, 82, 56, 36);
                } else {
                    const c = dirtCols[Math.floor(hash(x, y, 8) * dirtCols.length)];
                    px(x, y, c[0], c[1], c[2]);
                }
            }
        } else {
            // Dirt bottom
            return renderBlockFace(BLOCK_ID.DIRT, 'side');
        }
    } else if (blockId === BLOCK_ID.DIRT) {
        const dirtCols = [
            [134, 96, 67], [121, 85, 58], [147, 106, 75],
            [112, 78, 52], [140, 100, 70], [128, 90, 62], [105, 72, 48]
        ];
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const c = dirtCols[Math.floor(hash(x, y, 5) * dirtCols.length)];
            px(x, y, c[0], c[1], c[2]);
        }
    } else if (blockId === BLOCK_ID.STONE) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 3);
            let b = 125;
            if (h > 0.82) b = 138;
            else if (h > 0.65) b = 131;
            else if (h < 0.18) b = 112;
            else if (h < 0.35) b = 119;
            px(x, y, b, b, b);
        }
    } else if (blockId === BLOCK_ID.COBBLESTONE || blockId === BLOCK_ID.MOSSY_COBBLESTONE) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const isMortar = (
                (y % 4 === 0 && (x % 6 !== 2 && x % 6 !== 3)) ||
                (x % 5 === 0 && (y % 4 !== 1)) ||
                ((x + y * 2) % 11 === 0 && (x % 3 === 0))
            );
            const isBevel = !isMortar && ((y % 4 === 1) || (x % 5 === 1));
            const h = hash(x, y, 7);
            if (isMortar) {
                px(x, y, 64, 64, 64);
            } else {
                let b = isBevel ? 140 + Math.floor(h * 12) : 115 + Math.floor(h * 16);
                if (blockId === BLOCK_ID.MOSSY_COBBLESTONE && hash(x * 3, y * 3, 9) > 0.58) {
                    px(x, y, 62, 118, 48);
                } else {
                    px(x, y, b, b, b);
                }
            }
        }
    } else if (blockId === BLOCK_ID.LOG) {
        if (face === 'top' || face === 'bottom') {
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const dx = x - 7.5;
                const dy = y - 7.5;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist > 6.6) {
                    px(x, y, 56, 40, 24);
                } else if (dist > 5.5) {
                    px(x, y, 178, 148, 98);
                } else {
                    const ring = Math.floor(dist * 1.5) % 2 === 0;
                    const s = ring ? 0.90 : 1.08;
                    px(x, y, clamp(162 * s), clamp(130 * s), clamp(84 * s));
                }
            }
        } else {
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const furrow = (x === 1 || x === 6 || x === 11 || (x === 14 && y % 4 !== 0));
                if (furrow) {
                    px(x, y, 54, 38, 22);
                } else {
                    const plate = (x % 5 === 2 || x % 5 === 3);
                    const s = 0.88 + hash(x, y, 2) * 0.24;
                    const r = plate ? 122 * s : 98 * s;
                    const g = plate ? 92 * s : 72 * s;
                    const b = plate ? 54 * s : 40 * s;
                    px(x, y, clamp(r), clamp(g), clamp(b));
                }
            }
        }
    } else if (blockId === BLOCK_ID.PLANKS || blockId === BLOCK_ID.WOOD) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const seam = y % 4 === 0;
            const h = hash(x, y, 15);
            if (seam) px(x, y, 115, 80, 36);
            else if (h > 0.78) px(x, y, 168, 126, 68);
            else if (h < 0.22) px(x, y, 138, 102, 52);
            else px(x, y, 154, 114, 60);
        }
    } else if (blockId === BLOCK_ID.BRICKS) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const row = Math.floor(y / 4);
            const isHorizMortar = y % 4 === 0;
            const offset = (row % 2 === 0) ? 0 : 4;
            const isVertMortar = (x + offset) % 8 === 0;
            if (isHorizMortar || isVertMortar) {
                px(x, y, 215, 210, 205);
            } else {
                const s = 0.85 + hash(x, y, 22) * 0.3;
                px(x, y, clamp(165 * s), clamp(75 * s), clamp(62 * s));
            }
        }
    } else if (blockId === BLOCK_ID.GLASS) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const border = (x === 0 || x === 15 || y === 0 || y === 15);
            const glare = (x === y && x >= 2 && x <= 4) || (x === y && x >= 11 && x <= 13);
            if (border) px(x, y, 200, 235, 250, 230);
            else if (glare) px(x, y, 255, 255, 255, 210);
            else px(x, y, 180, 220, 240, 60);
        }
    } else if (blockId === BLOCK_ID.CHEST) {
        if (face === 'top') {
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const border = (x === 0 || x === 15 || y === 0 || y === 15);
                if (border) px(x, y, 40, 25, 10);
                else px(x, y, 160, 105, 45);
            }
        } else {
            for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
                const border = (x === 0 || x === 15 || y === 0 || y === 15 || y === 6);
                const isLatch = (x >= 7 && x <= 8 && y >= 5 && y <= 8);
                if (isLatch) {
                    px(x, y, 230, 210, 70);
                } else if (border) {
                    px(x, y, 40, 25, 10);
                } else {
                    px(x, y, 160, 105, 45);
                }
            }
        }
    } else if (blockId === BLOCK_ID.BEDROCK) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 44);
            const b = h > 0.8 ? 85 : h > 0.4 ? 48 : 22;
            px(x, y, b, b, b);
        }
    } else if (blockId === BLOCK_ID.OBSIDIAN) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 99);
            const purp = h > 0.7 ? 35 : h > 0.4 ? 20 : 10;
            px(x, y, purp + 15, purp, purp + 35);
        }
    } else if (blockId === BLOCK_ID.SAND) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const wave = Math.sin((x + y * 0.5) * 0.8) * 8;
            const h = hash(x, y, 31);
            px(x, y, clamp(225 + wave + (h - 0.5) * 14), clamp(214 + wave + (h - 0.5) * 14), clamp(156 + wave));
        }
    } else if (blockId === BLOCK_ID.GRAVEL) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 51);
            const b = clamp(130 + (h - 0.5) * 40);
            px(x, y, b, b - 4, b - 6);
        }
    } else if (blockId === BLOCK_ID.LEAVES || blockId === BLOCK_ID.CHERRY_LEAVES || blockId === BLOCK_ID.RED_LEAVES) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 77);
            const cluster = (x % 3 === 0 && y % 3 === 0) || (x % 4 === 2 && y % 4 === 2);
            if (blockId === BLOCK_ID.CHERRY_LEAVES) {
                if (cluster) px(x, y, 200, 115, 145);
                else if (h > 0.70) px(x, y, 255, 205, 222);
                else px(x, y, 235, 160, 185);
            } else if (blockId === BLOCK_ID.RED_LEAVES) {
                if (cluster) px(x, y, 145, 22, 18);
                else if (h > 0.74) px(x, y, 225, 62, 38);
                else px(x, y, 195, 42, 28);
            } else {
                if (cluster) px(x, y, 32, 70, 18);
                else if (h > 0.74) px(x, y, 102, 186, 46);
                else px(x, y, 76, 150, 36);
            }
        }
    } else if (
        blockId === BLOCK_ID.COAL_ORE || blockId === BLOCK_ID.IRON_ORE ||
        blockId === BLOCK_ID.GOLD_ORE || blockId === BLOCK_ID.LAPIS_ORE ||
        blockId === BLOCK_ID.REDSTONE_ORE || blockId === BLOCK_ID.DIAMOND_ORE ||
        blockId === BLOCK_ID.EMERALD_ORE || blockId === BLOCK_ID.RUBY_ORE ||
        blockId === BLOCK_ID.NETHER_QUARTZ_ORE
    ) {
        // Base stone
        const isNether = blockId === BLOCK_ID.NETHER_QUARTZ_ORE;
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            if (isNether) {
                const s = 0.85 + hash(x, y, 11) * 0.3;
                px(x, y, clamp(120 * s), clamp(45 * s), clamp(40 * s));
            } else {
                const h = hash(x, y, 3);
                let b = h > 0.82 ? 138 : h > 0.65 ? 131 : h < 0.18 ? 112 : 122;
                px(x, y, b, b, b);
            }
        }
        const oreColors: Record<number, number[]> = {
            [BLOCK_ID.COAL_ORE]: [34, 32, 30],
            [BLOCK_ID.IRON_ORE]: [216, 172, 142],
            [BLOCK_ID.GOLD_ORE]: [250, 224, 70],
            [BLOCK_ID.LAPIS_ORE]: [48, 80, 215],
            [BLOCK_ID.REDSTONE_ORE]: [225, 36, 36],
            [BLOCK_ID.DIAMOND_ORE]: [72, 235, 228],
            [BLOCK_ID.EMERALD_ORE]: [32, 215, 95],
            [BLOCK_ID.RUBY_ORE]: [225, 42, 115],
            [BLOCK_ID.NETHER_QUARTZ_ORE]: [235, 230, 225],
        };
        const col = oreColors[blockId] || [200, 200, 200];
        const veins = [[3, 3], [12, 3], [3, 12], [12, 12], [7, 7], [4, 9], [10, 6]];
        for (const [vx, vy] of veins) {
            for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
                const nx = vx + dx, ny = vy + dy;
                if (nx >= 0 && nx < 16 && ny >= 0 && ny < 16 && hash(nx + vx * 7, ny + vy * 5, 88) > 0.35) {
                    const s = 0.9 + hash(nx, ny, 19) * 0.2;
                    px(nx, ny, clamp(col[0] * s), clamp(col[1] * s), clamp(col[2] * s));
                }
            }
        }
    } else if (blockId === BLOCK_ID.NETHERRACK) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const s = 0.85 + hash(x, y, 61) * 0.3;
            px(x, y, clamp(120 * s), clamp(45 * s), clamp(40 * s));
        }
    } else if (blockId === BLOCK_ID.SOUL_SAND) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const s = 0.85 + hash(x, y, 62) * 0.3;
            px(x, y, clamp(85 * s), clamp(62 * s), clamp(48 * s));
        }
    } else if (blockId === BLOCK_ID.GLOWSTONE) {
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const h = hash(x, y, 63);
            const s = 0.8 + h * 0.4;
            px(x, y, clamp(225 * s), clamp(185 * s), clamp(95 * s));
        }
    } else {
        // Fallback realistic mottled block face
        for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) {
            const s = 0.88 + hash(x, y, blockId) * 0.24;
            px(x, y, clamp(baseR * s), clamp(baseG * s), clamp(baseB * s));
        }
    }

    return canvas;
}

// Render an authentic Minecraft 3D isometric block preview (32x32)
function renderIsometricBlock(blockId: number): string {
    const size = 32;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    // Non-cube cross items (Flowers, tall grass, bamboo) are rendered flat
    if (
        blockId === BLOCK_ID.FLOWER_RED || blockId === BLOCK_ID.FLOWER_YELLOW ||
        blockId === BLOCK_ID.TALL_GRASS || blockId === BLOCK_ID.BAMBOO
    ) {
        return renderFlatPlant(blockId);
    }

    const topFace = renderBlockFace(blockId, 'top');
    const sideFace = renderBlockFace(blockId, 'side');

    const topCtx = topFace.getContext('2d')!;
    const sideCtx = sideFace.getContext('2d')!;
    const topData = topCtx.getImageData(0, 0, 16, 16).data;
    const sideData = sideCtx.getImageData(0, 0, 16, 16).data;

    // Draw isometric 3D cube with top face, left face, right face
    // Top face: rhombus at center top
    // Left face: side face shaded 0.72x
    // Right face: side face shaded 0.86x

    // Isometric projection mapping:
    // Cube origin (center): (16, 16)
    // Axes:
    // Right axis: +X -> (cos(30°), sin(30°)) = (0.866, 0.5)
    // Left axis:  +Z -> (-cos(30°), sin(30°)) = (-0.866, 0.5)
    // Up axis:    -Y -> (0, -1)

    // Render using 16x16 sampling on 3 faces:
    // 1. Top face (Y = 1):
    for (let tz = 0; tz < 16; tz++) {
        for (let tx = 0; tx < 16; tx++) {
            const idx = (tz * 16 + tx) * 4;
            const r = topData[idx];
            const g = topData[idx + 1];
            const b = topData[idx + 2];
            const a = topData[idx + 3] / 255;
            if (a <= 0.05) continue;

            // Diamond coordinates
            const px = 16 + (tx - tz) * 0.86;
            const py = 4 + (tx + tz) * 0.44;

            ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
            ctx.fillRect(Math.floor(px), Math.floor(py), 2, 2);
        }
    }

    // 2. Left face (X = 0):
    for (let ty = 0; ty < 16; ty++) {
        for (let tz = 0; tz < 16; tz++) {
            const idx = (ty * 16 + tz) * 4;
            // Shaded 0.72x
            const r = Math.round(sideData[idx] * 0.72);
            const g = Math.round(sideData[idx + 1] * 0.72);
            const b = Math.round(sideData[idx + 2] * 0.72);
            const a = sideData[idx + 3] / 255;
            if (a <= 0.05) continue;

            const px = 2.5 + tz * 0.86;
            const py = 11 + tz * 0.44 + ty * 0.95;

            ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
            ctx.fillRect(Math.floor(px), Math.floor(py), 2, 2);
        }
    }

    // 3. Right face (Z = 16):
    for (let ty = 0; ty < 16; ty++) {
        for (let tx = 0; tx < 16; tx++) {
            const idx = (ty * 16 + tx) * 4;
            // Shaded 0.86x
            const r = Math.round(sideData[idx] * 0.86);
            const g = Math.round(sideData[idx + 1] * 0.86);
            const b = Math.round(sideData[idx + 2] * 0.86);
            const a = sideData[idx + 3] / 255;
            if (a <= 0.05) continue;

            const px = 15.5 + tx * 0.86;
            const py = 18 - tx * 0.44 + ty * 0.95;

            ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
            ctx.fillRect(Math.floor(px), Math.floor(py), 2, 2);
        }
    }

    return canvas.toDataURL('image/png');
}

// Flat plant sprite for inventory
function renderFlatPlant(blockId: number): string {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;
    const baseCanvas = createMinecraftBlockCanvas(blockId, 'default');
    ctx.drawImage(baseCanvas, 0, 0, 32, 32);
    return canvas.toDataURL('image/png');
}

// Render authentic Minecraft 16x16 pixel-art tool or item sprite
function renderItemSprite(id: string): string {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext('2d')!;

    const px = (x: number, y: number, r: number, g: number, b: number, a = 255) => {
        ctx.fillStyle = `rgba(${r},${g},${b},${(a / 255).toFixed(3)})`;
        ctx.fillRect(x * 2, y * 2, 2, 2);
    };

    const isSword = id.includes('sword');
    const isPickaxe = id.includes('pickaxe');
    const isAxe = id.includes('axe');
    const isShovel = id.includes('shovel');
    const isHelmet = id.includes('helmet');
    const isChestplate = id.includes('chestplate');
    const isLeggings = id.includes('leggings');
    const isBoots = id.includes('boots');
    const isMace = id.includes('mace');
    const isSpear = id.includes('spear');
    const isTrident = id.includes('trident');

    // Material palette colors
    let matCol: number[] = [180, 180, 180];
    let matHighlight: number[] = [230, 230, 230];
    let matShadow: number[] = [120, 120, 120];

    if (id.includes('diamond')) {
        matCol = [72, 235, 228];
        matHighlight = [160, 255, 250];
        matShadow = [30, 160, 160];
    } else if (id.includes('gold')) {
        matCol = [248, 222, 68];
        matHighlight = [255, 245, 140];
        matShadow = [185, 140, 25];
    } else if (id.includes('netherite')) {
        matCol = [62, 54, 62];
        matHighlight = [98, 88, 98];
        matShadow = [35, 30, 35];
    } else if (id.includes('iron') || isMace) {
        matCol = [200, 202, 208];
        matHighlight = [245, 245, 250];
        matShadow = [125, 125, 130];
    } else if (id.includes('ruby')) {
        matCol = [225, 42, 115];
        matHighlight = [255, 120, 170];
        matShadow = [150, 20, 70];
    } else if (id.includes('wood')) {
        matCol = [150, 110, 60];
        matHighlight = [185, 140, 85];
        matShadow = [100, 70, 35];
    } else if (id.includes('leather')) {
        matCol = [160, 101, 60];
        matHighlight = [190, 130, 85];
        matShadow = [115, 65, 35];
    }

    if (isMace) {
        // Minecraft 1.21 Heavy Mace: Breeze rod handle with heavy metal cube head
        // Handle:
        for (let i = 2; i <= 8; i++) {
            px(i, 15 - i, 160, 175, 220);
            px(i, 16 - i, 110, 120, 175);
        }
        // Heavy Core / Mace head: 6x6 pixel block in top-right
        for (let x = 8; x <= 14; x++) {
            for (let y = 1; y <= 7; y++) {
                px(x, y, matCol[0], matCol[1], matCol[2]);
            }
        }
        // Highlight top and left edges
        for (let x = 8; x <= 14; x++) px(x, 1, matHighlight[0], matHighlight[1], matHighlight[2]);
        for (let y = 1; y <= 7; y++) px(8, y, matHighlight[0], matHighlight[1], matHighlight[2]);
        // Shadow bottom and right edges
        for (let x = 8; x <= 14; x++) px(x, 7, matShadow[0], matShadow[1], matShadow[2]);
        for (let y = 1; y <= 7; y++) px(14, y, matShadow[0], matShadow[1], matShadow[2]);
        // Flange cross in center:
        px(11, 4, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(10, 4, matShadow[0], matShadow[1], matShadow[2]);
        px(12, 4, matShadow[0], matShadow[1], matShadow[2]);
        px(11, 3, matShadow[0], matShadow[1], matShadow[2]);
        px(11, 5, matShadow[0], matShadow[1], matShadow[2]);
    } else if (isSpear || isTrident) {
        // Long shaft:
        for (let i = 1; i <= 12; i++) {
            const hColor = isTrident ? [50, 135, 145] : [135, 95, 50];
            px(i, 15 - i, hColor[0], hColor[1], hColor[2]);
        }
        if (isTrident) {
            // Prismarine cyan trident head
            const tCol = [65, 185, 180];
            const tHi = [160, 255, 245];
            const tSha = [25, 120, 115];
            // Center prong
            px(12, 3, tCol[0], tCol[1], tCol[2]);
            px(13, 2, tHi[0], tHi[1], tHi[2]);
            px(14, 1, tHi[0], tHi[1], tHi[2]);
            // Left prong
            px(9, 3, tCol[0], tCol[1], tCol[2]);
            px(10, 2, tHi[0], tHi[1], tHi[2]);
            px(11, 1, tHi[0], tHi[1], tHi[2]);
            // Right prong
            px(13, 5, tCol[0], tCol[1], tCol[2]);
            px(14, 4, tHi[0], tHi[1], tHi[2]);
            px(15, 3, tHi[0], tHi[1], tHi[2]);
            // Cross bar
            px(10, 5, tSha[0], tSha[1], tSha[2]);
            px(11, 4, tCol[0], tCol[1], tCol[2]);
            px(12, 4, tCol[0], tCol[1], tCol[2]);
        } else {
            // Pointed Spearhead
            px(11, 4, matShadow[0], matShadow[1], matShadow[2]);
            px(12, 3, matCol[0], matCol[1], matCol[2]);
            px(13, 2, matCol[0], matCol[1], matCol[2]);
            px(14, 1, matHighlight[0], matHighlight[1], matHighlight[2]);
            px(12, 4, matCol[0], matCol[1], matCol[2]);
            px(13, 3, matHighlight[0], matHighlight[1], matHighlight[2]);
            px(10, 6, matShadow[0], matShadow[1], matShadow[2]);
            px(11, 5, matHighlight[0], matHighlight[1], matHighlight[2]);
        }
    } else if (isSword) {
        // Iconic Minecraft 45-degree diagonal sword
        // Handle: (3, 12), (4, 11)
        px(2, 13, 115, 80, 45);
        px(3, 12, 140, 100, 55);
        px(4, 11, 140, 100, 55);
        // Guard:
        px(4, 10, matShadow[0], matShadow[1], matShadow[2]);
        px(5, 10, matCol[0], matCol[1], matCol[2]);
        px(3, 11, matShadow[0], matShadow[1], matShadow[2]);
        px(5, 9, matCol[0], matCol[1], matCol[2]);
        px(6, 10, matCol[0], matCol[1], matCol[2]);
        // Blade:
        for (let i = 0; i < 7; i++) {
            const x = 5 + i;
            const y = 9 - i;
            px(x, y, matCol[0], matCol[1], matCol[2]);
            px(x + 1, y, matHighlight[0], matHighlight[1], matHighlight[2]);
            px(x, y + 1, matShadow[0], matShadow[1], matShadow[2]);
        }
        px(12, 2, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(13, 2, matCol[0], matCol[1], matCol[2]);
    } else if (isPickaxe) {
        // Diagonal stick handle
        for (let i = 2; i <= 10; i++) {
            px(i, 15 - i, 140, 100, 55);
        }
        // Curved pickaxe head:
        const pickHead = [
            [5, 4], [6, 3], [7, 3], [8, 3], [9, 3], [10, 4], [11, 5], [12, 6], [13, 7]
        ];
        for (const [x, y] of pickHead) {
            px(x, y, matCol[0], matCol[1], matCol[2]);
            px(x, y - 1, matHighlight[0], matHighlight[1], matHighlight[2]);
            px(x, y + 1, matShadow[0], matShadow[1], matShadow[2]);
        }
    } else if (isAxe) {
        for (let i = 2; i <= 11; i++) {
            px(i, 15 - i, 140, 100, 55);
        }
        // Axe blade block
        for (let x = 8; x <= 13; x++) {
            for (let y = 2; y <= 7; y++) {
                if ((x === 8 && y >= 6) || (x === 13 && y >= 6)) continue;
                px(x, y, matCol[0], matCol[1], matCol[2]);
            }
        }
        px(13, 3, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(13, 4, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(13, 5, matHighlight[0], matHighlight[1], matHighlight[2]);
    } else if (isShovel) {
        for (let i = 2; i <= 9; i++) {
            px(i, 15 - i, 140, 100, 55);
        }
        // Spade head
        const head = [
            [10, 5], [11, 4], [12, 3], [11, 3], [12, 4], [10, 4]
        ];
        for (const [x, y] of head) {
            px(x, y, matCol[0], matCol[1], matCol[2]);
            px(x + 1, y, matHighlight[0], matHighlight[1], matHighlight[2]);
        }
    } else if (isHelmet) {
        for (let x = 4; x <= 11; x++) for (let y = 3; y <= 5; y++) px(x, y, matCol[0], matCol[1], matCol[2]);
        for (let y = 6; y <= 11; y++) {
            px(4, y, matCol[0], matCol[1], matCol[2]);
            px(5, y, matCol[0], matCol[1], matCol[2]);
            px(10, y, matCol[0], matCol[1], matCol[2]);
            px(11, y, matCol[0], matCol[1], matCol[2]);
        }
        px(7, 3, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(8, 3, matHighlight[0], matHighlight[1], matHighlight[2]);
    } else if (isChestplate) {
        for (let x = 3; x <= 12; x++) for (let y = 5; y <= 12; y++) {
            if (y === 5 && (x >= 6 && x <= 9)) continue;
            px(x, y, matCol[0], matCol[1], matCol[2]);
        }
        px(4, 5, matHighlight[0], matHighlight[1], matHighlight[2]);
        px(11, 5, matHighlight[0], matHighlight[1], matHighlight[2]);
    } else if (isLeggings) {
        for (let x = 4; x <= 11; x++) px(x, 4, matCol[0], matCol[1], matCol[2]);
        for (let y = 5; y <= 13; y++) {
            px(4, y, matCol[0], matCol[1], matCol[2]);
            px(5, y, matCol[0], matCol[1], matCol[2]);
            px(6, y, matCol[0], matCol[1], matCol[2]);
            px(9, y, matCol[0], matCol[1], matCol[2]);
            px(10, y, matCol[0], matCol[1], matCol[2]);
            px(11, y, matCol[0], matCol[1], matCol[2]);
        }
    } else if (isBoots) {
        for (let y = 6; y <= 12; y++) {
            px(4, y, matCol[0], matCol[1], matCol[2]);
            px(5, y, matCol[0], matCol[1], matCol[2]);
            px(10, y, matCol[0], matCol[1], matCol[2]);
            px(11, y, matCol[0], matCol[1], matCol[2]);
        }
        px(3, 11, matCol[0], matCol[1], matCol[2]);
        px(3, 12, matCol[0], matCol[1], matCol[2]);
        px(9, 11, matCol[0], matCol[1], matCol[2]);
        px(9, 12, matCol[0], matCol[1], matCol[2]);
    } else if (id === 'apple') {
        px(7, 2, 85, 55, 30);
        px(8, 1, 60, 160, 40);
        for (let y = 3; y <= 12; y++) for (let x = 4; x <= 11; x++) {
            if ((y === 3 || y === 12) && (x === 4 || x === 11)) continue;
            px(x, y, 215, 35, 35);
        }
        px(5, 4, 255, 100, 100);
    } else if (id === 'bread') {
        for (let x = 3; x <= 12; x++) for (let y = 6; y <= 10; y++) {
            if ((x === 3 || x === 12) && (y === 6 || y === 10)) continue;
            px(x, y, 195, 135, 65);
        }
        px(5, 7, 230, 185, 115);
        px(8, 7, 230, 185, 115);
        px(10, 7, 230, 185, 115);
    } else if (id === 'stick') {
        for (let i = 2; i <= 13; i++) {
            px(i, 15 - i, 140, 100, 50);
            px(i, 16 - i, 110, 75, 35);
        }
    } else if (id === 'diamond') {
        const gem = [
            [0, 1, 1, 1, 0],
            [1, 2, 2, 2, 1],
            [1, 2, 3, 2, 1],
            [0, 1, 2, 1, 0],
            [0, 0, 1, 0, 0]
        ];
        for (let y = 0; y < 5; y++) for (let x = 0; x < 5; x++) {
            const t = gem[y][x];
            const gx = 5 + x * 1.2, gy = 5 + y * 1.2;
            if (t === 1) px(gx, gy, 35, 180, 180);
            else if (t === 2) px(gx, gy, 72, 235, 228);
            else if (t === 3) px(gx, gy, 180, 255, 250);
        }
    } else if (id === 'emerald') {
        for (let y = 4; y <= 11; y++) for (let x = 5; x <= 10; x++) {
            px(x, y, 35, 205, 85);
        }
        px(6, 5, 140, 255, 175);
    } else if (id === 'ruby') {
        for (let y = 4; y <= 11; y++) for (let x = 5; x <= 10; x++) {
            px(x, y, 225, 42, 115);
        }
        px(6, 5, 255, 150, 195);
    } else if (id === 'coal') {
        for (let y = 5; y <= 11; y++) for (let x = 5; x <= 11; x++) {
            if (Math.abs(x - 8) + Math.abs(y - 8) > 4) continue;
            px(x, y, 32, 30, 28);
        }
        px(7, 7, 65, 65, 65);
    } else if (id === 'iron_ingot' || id === 'raw_iron') {
        for (let y = 6; y <= 10; y++) for (let x = 4; x <= 12; x++) {
            px(x, y, 205, 210, 215);
        }
        px(5, 7, 245, 250, 255);
    } else if (id === 'gold_ingot' || id === 'raw_gold') {
        for (let y = 6; y <= 10; y++) for (let x = 4; x <= 12; x++) {
            px(x, y, 245, 215, 60);
        }
        px(5, 7, 255, 245, 130);
    } else if (id.includes('meat') || id.includes('beef') || id.includes('porkchop') || id.includes('mutton') || id.includes('chicken')) {
        for (let y = 5; y <= 11; y++) for (let x = 4; x <= 12; x++) {
            if ((x === 4 || x === 12) && (y === 5 || y === 11)) continue;
            px(x, y, 195, 70, 70);
        }
        px(6, 6, 235, 120, 120);
        px(10, 10, 240, 235, 225); // bone bit
    } else if (id === 'wheat') {
        for (let y = 3; y <= 13; y++) {
            px(8, y, 225, 195, 80);
            if (y % 2 === 0) {
                px(7, y, 240, 215, 100);
                px(9, y, 210, 175, 65);
            }
        }
    } else if (id === 'heavy_core') {
        for (let y = 4; y <= 11; y++) for (let x = 4; x <= 11; x++) {
            px(x, y, 75, 78, 88);
        }
        for (let x = 4; x <= 11; x++) px(x, 4, 115, 120, 135);
        for (let y = 4; y <= 11; y++) px(4, y, 115, 120, 135);
        px(7, 7, 140, 150, 175);
        px(8, 7, 140, 150, 175);
        px(7, 8, 140, 150, 175);
        px(8, 8, 140, 150, 175);
    } else if (id === 'breeze_rod') {
        for (let i = 2; i <= 13; i++) {
            px(i, 15 - i, 160, 185, 235);
            px(i, 16 - i, 120, 145, 205);
        }
        px(7, 8, 210, 230, 255);
        px(8, 7, 210, 230, 255);
    } else if (id === 'wind_charge') {
        // Authentic Minecraft 1.21 Wind Charge: swirling airy cyan breeze sphere with white gust core
        const windSphere = [
            [0, 0, 1, 1, 1, 1, 0, 0],
            [0, 1, 2, 2, 3, 2, 1, 0],
            [1, 2, 3, 3, 3, 2, 2, 1],
            [1, 3, 3, 4, 4, 3, 2, 1],
            [1, 2, 3, 4, 4, 3, 3, 1],
            [1, 2, 2, 3, 3, 3, 2, 1],
            [0, 1, 2, 2, 3, 2, 1, 0],
            [0, 0, 1, 1, 1, 1, 0, 0]
        ];
        for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
            const v = windSphere[y][x];
            if (v === 0) continue;
            const gx = 4 + x;
            const gy = 4 + y;
            if (v === 1) px(gx, gy, 140, 215, 245, 210);
            else if (v === 2) px(gx, gy, 180, 238, 255, 240);
            else if (v === 3) px(gx, gy, 222, 250, 255, 255);
            else if (v === 4) px(gx, gy, 255, 255, 255, 255);
        }
        // Swirling wind tail swirls
        px(3, 5, 175, 230, 255, 190);
        px(2, 6, 175, 230, 255, 150);
        px(12, 10, 175, 230, 255, 190);
        px(13, 9, 175, 230, 255, 150);
        px(5, 12, 175, 230, 255, 170);
        px(10, 3, 175, 230, 255, 170);
    } else {
        // Fallback clean item gem
        for (let y = 5; y <= 11; y++) for (let x = 5; x <= 11; x++) {
            px(x, y, 160, 160, 160);
        }
    }

    return canvas.toDataURL('image/png');
}

/**
 * Public accessor that returns an authentic texture Data URL for any block or item.
 * Results are cached in memory for instant, non-blocking rendering.
 */
export function getItemTexture(entry: { kind: 'block' | 'resource'; id: any } | null): string {
    if (!entry) return '';
    const key = `${entry.kind}:${entry.id}`;
    if (textureCache.has(key)) {
        return textureCache.get(key)!;
    }

    let url = '';
    if (entry.kind === 'block') {
        url = renderIsometricBlock(Number(entry.id));
    } else {
        url = renderItemSprite(String(entry.id));
    }

    textureCache.set(key, url);
    return url;
}
