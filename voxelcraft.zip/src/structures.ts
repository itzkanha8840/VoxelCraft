import { CONFIG, BLOCK_ID, RESOURCE_DEFS } from './constants';
import { VoxelWorld, MathKernel } from './world';

export interface LootItem {
    kind: 'block' | 'resource';
    id: any;
    count: number;
}

export class StructureGenerator {
    static getVillageLoot(): LootItem[] {
        const table: LootItem[] = [
            { kind: 'resource', id: 'bread', count: 3 + Math.floor(Math.random() * 4) },
            { kind: 'resource', id: 'apple', count: 2 + Math.floor(Math.random() * 3) },
            { kind: 'resource', id: 'iron_ingot', count: 1 + Math.floor(Math.random() * 4) },
            { kind: 'resource', id: 'emerald', count: 1 + Math.floor(Math.random() * 3) },
            { kind: 'resource', id: 'iron_sword', count: 1 },
            { kind: 'block', id: BLOCK_ID.LOG, count: 8 },
            { kind: 'resource', id: 'torch', count: 4 }
        ];
        return table.sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 3));
    }

    static getDesertTempleLoot(): LootItem[] {
        const table: LootItem[] = [
            { kind: 'resource', id: 'diamond', count: 1 + Math.floor(Math.random() * 2) },
            { kind: 'resource', id: 'emerald', count: 2 + Math.floor(Math.random() * 4) },
            { kind: 'resource', id: 'gold_ingot', count: 3 + Math.floor(Math.random() * 5) },
            { kind: 'resource', id: 'iron_ingot', count: 4 + Math.floor(Math.random() * 6) },
            { kind: 'resource', id: 'golden_apple', count: 1 },
            { kind: 'resource', id: 'gunpowder', count: 4 + Math.floor(Math.random() * 5) },
            { kind: 'resource', id: 'bone', count: 5 + Math.floor(Math.random() * 6) }
        ];
        return table.sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 3));
    }

    static getRuinedPortalLoot(): LootItem[] {
        const table: LootItem[] = [
            { kind: 'resource', id: 'golden_sword', count: 1 },
            { kind: 'resource', id: 'golden_pickaxe', count: 1 },
            { kind: 'resource', id: 'golden_apple', count: 1 },
            { kind: 'resource', id: 'gold_nugget', count: 8 + Math.floor(Math.random() * 12) },
            { kind: 'block', id: BLOCK_ID.OBSIDIAN, count: 2 + Math.floor(Math.random() * 3) },
            { kind: 'resource', id: 'iron_ingot', count: 2 + Math.floor(Math.random() * 3) },
            { kind: 'resource', id: 'flint_and_steel', count: 1 }
        ];
        return table.sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 2));
    }

    static getDungeonLoot(): LootItem[] {
        const table: LootItem[] = [
            { kind: 'resource', id: 'saddle', count: 1 },
            { kind: 'resource', id: 'golden_apple', count: 1 },
            { kind: 'resource', id: 'iron_ingot', count: 2 + Math.floor(Math.random() * 4) },
            { kind: 'resource', id: 'bread', count: 2 + Math.floor(Math.random() * 3) },
            { kind: 'resource', id: 'string', count: 3 + Math.floor(Math.random() * 5) },
            { kind: 'resource', id: 'redstone', count: 4 + Math.floor(Math.random() * 6) }
        ];
        return table.sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 3));
    }

    /**
     * Builds a classic Minecraft Plains Villager House (Cobblestone foundation, wood walls, roof, glass, door, chest)
     */
    static buildPlainsHouse(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const width = 5;
        const depth = 5;
        const height = 4;

        // Foundation & floor
        for (let x = 0; x < width; x++) {
            for (let z = 0; z < depth; z++) {
                // Ground support down
                for (let dy = -2; dy <= 0; dy++) {
                    world.setVoxelRaw(startX + x, startY + dy, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
                }
            }
        }

        // Walls & Corners
        for (let y = 1; y <= height; y++) {
            for (let x = 0; x < width; x++) {
                for (let z = 0; z < depth; z++) {
                    const isEdgeX = x === 0 || x === width - 1;
                    const isEdgeZ = z === 0 || z === depth - 1;
                    if (!isEdgeX && !isEdgeZ) {
                        // Interior air
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.AIR, dirtyChunks);
                        continue;
                    }

                    // Corner pillars are Logs
                    if (isEdgeX && isEdgeZ) {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.LOG, dirtyChunks);
                    } else {
                        // Walls are Planks
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.PLANKS, dirtyChunks);
                    }
                }
            }
        }

        // Doorway (Front: x=2, z=0)
        world.setVoxelRaw(startX + 2, startY + 1, startZ, BLOCK_ID.AIR, dirtyChunks);
        world.setVoxelRaw(startX + 2, startY + 2, startZ, BLOCK_ID.AIR, dirtyChunks);

        // Windows (Glass)
        world.setVoxelRaw(startX, startY + 2, startZ + 2, BLOCK_ID.GLASS, dirtyChunks);
        world.setVoxelRaw(startX + width - 1, startY + 2, startZ + 2, BLOCK_ID.GLASS, dirtyChunks);
        world.setVoxelRaw(startX + 2, startY + 2, startZ + depth - 1, BLOCK_ID.GLASS, dirtyChunks);

        // Roof (Planks & Cobble trim)
        for (let x = -1; x <= width; x++) {
            for (let z = -1; z <= depth; z++) {
                world.setVoxelRaw(startX + x, startY + height + 1, startZ + z, BLOCK_ID.PLANKS, dirtyChunks);
            }
        }

        // Interior furnishings: Crafting table (represented as log/plank) and Chest with loot!
        const chestX = startX + 1;
        const chestY = startY + 1;
        const chestZ = startZ + 3;
        world.setVoxelRaw(chestX, chestY, chestZ, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${chestX},${chestY},${chestZ}`, this.getVillageLoot());

        // Interior torch / light
        world.setVoxelRaw(startX + 2, startY + 3, startZ + 2, BLOCK_ID.GLOWSTONE, dirtyChunks);
    }

    /**
     * Builds a Village Well (Cobblestone rim, water inside, posts and cobblestone roof)
     */
    static buildVillageWell(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const size = 4;
        // Deep well shaft down
        for (let y = -4; y <= 0; y++) {
            for (let x = 0; x < size; x++) {
                for (let z = 0; z < size; z++) {
                    const isEdge = x === 0 || x === size - 1 || z === 0 || z === size - 1;
                    if (isEdge) {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
                    } else {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.WATER, dirtyChunks);
                    }
                }
            }
        }

        // Top rim
        for (let x = 0; x < size; x++) {
            for (let z = 0; z < size; z++) {
                const isEdge = x === 0 || x === size - 1 || z === 0 || z === size - 1;
                if (isEdge) {
                    world.setVoxelRaw(startX + x, startY + 1, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
                }
            }
        }

        // Corner posts
        const corners = [[0, 0], [size - 1, 0], [0, size - 1], [size - 1, size - 1]];
        for (const [cx, cz] of corners) {
            world.setVoxelRaw(startX + cx, startY + 2, startZ + cz, BLOCK_ID.LOG, dirtyChunks);
            world.setVoxelRaw(startX + cx, startY + 3, startZ + cz, BLOCK_ID.LOG, dirtyChunks);
        }

        // Well roof
        for (let x = 0; x < size; x++) {
            for (let z = 0; z < size; z++) {
                world.setVoxelRaw(startX + x, startY + 4, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
            }
        }
    }

    /**
     * Builds a Blacksmith Workshop (Lava trough, cobblestone pillars, chest with rich weapons/tools)
     */
    static buildBlacksmith(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const w = 7;
        const d = 6;
        // Cobblestone foundation
        for (let x = 0; x < w; x++) {
            for (let z = 0; z < d; z++) {
                for (let dy = -1; dy <= 0; dy++) {
                    world.setVoxelRaw(startX + x, startY + dy, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
                }
            }
        }

        // Enclosed rear room (x: 2..6, z: 2..5)
        for (let y = 1; y <= 3; y++) {
            for (let x = 2; x < w; x++) {
                for (let z = 2; z < d; z++) {
                    const isEdge = x === 2 || x === w - 1 || z === 2 || z === d - 1;
                    if (isEdge) {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.PLANKS, dirtyChunks);
                    } else {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.AIR, dirtyChunks);
                    }
                }
            }
        }

        // Front porch pillars
        world.setVoxelRaw(startX, startY + 1, startZ, BLOCK_ID.LOG, dirtyChunks);
        world.setVoxelRaw(startX, startY + 2, startZ, BLOCK_ID.LOG, dirtyChunks);
        world.setVoxelRaw(startX, startY + 3, startZ, BLOCK_ID.LOG, dirtyChunks);

        world.setVoxelRaw(startX + 3, startY + 1, startZ, BLOCK_ID.LOG, dirtyChunks);
        world.setVoxelRaw(startX + 3, startY + 2, startZ, BLOCK_ID.LOG, dirtyChunks);
        world.setVoxelRaw(startX + 3, startY + 3, startZ, BLOCK_ID.LOG, dirtyChunks);

        // Lava basin
        world.setVoxelRaw(startX + 1, startY + 1, startZ + 1, BLOCK_ID.COBBLESTONE, dirtyChunks);
        world.setVoxelRaw(startX + 1, startY + 1, startZ + 2, BLOCK_ID.COBBLESTONE, dirtyChunks);
        world.setVoxelRaw(startX + 1, startY + 1, startZ + 1, BLOCK_ID.LAVA, dirtyChunks);

        // Stone roof over all
        for (let x = 0; x < w; x++) {
            for (let z = 0; z < d; z++) {
                world.setVoxelRaw(startX + x, startY + 4, startZ + z, BLOCK_ID.COBBLESTONE, dirtyChunks);
            }
        }

        // Doorway into inner room
        world.setVoxelRaw(startX + 3, startY + 1, startZ + 2, BLOCK_ID.AIR, dirtyChunks);
        world.setVoxelRaw(startX + 3, startY + 2, startZ + 2, BLOCK_ID.AIR, dirtyChunks);

        // Blacksmith chest!
        const chestX = startX + 5;
        const chestY = startY + 1;
        const chestZ = startZ + 4;
        world.setVoxelRaw(chestX, chestY, chestZ, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${chestX},${chestY},${chestZ}`, [
            { kind: 'resource', id: 'iron_sword', count: 1 },
            { kind: 'resource', id: 'iron_pickaxe', count: 1 },
            { kind: 'resource', id: 'iron_ingot', count: 5 },
            { kind: 'resource', id: 'gold_ingot', count: 3 },
            { kind: 'resource', id: 'bread', count: 4 },
            { kind: 'block', id: BLOCK_ID.OBSIDIAN, count: 4 }
        ]);
    }

    /**
     * Builds a full authentic Minecraft Desert Temple (Stepped Sandstone Pyramid with Twin Towers and secret TNT/Chest Vault)
     */
    static buildDesertTemple(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const size = 15;
        const height = 9;

        // Clear and level base
        for (let x = 0; x < size; x++) {
            for (let z = 0; z < size; z++) {
                for (let dy = -2; dy <= 0; dy++) {
                    world.setVoxelRaw(startX + x, startY + dy, startZ + z, BLOCK_ID.SAND, dirtyChunks);
                }
            }
        }

        // Stepped pyramid walls
        for (let step = 0; step < 6; step++) {
            const min = step;
            const max = size - 1 - step;
            const y = startY + 1 + step;
            for (let x = min; x <= max; x++) {
                for (let z = min; z <= max; z++) {
                    const isEdge = x === min || x === max || z === min || z === max;
                    if (isEdge) {
                        world.setVoxelRaw(startX + x, y, startZ + z, BLOCK_ID.SAND, dirtyChunks);
                    } else {
                        world.setVoxelRaw(startX + x, y, startZ + z, BLOCK_ID.AIR, dirtyChunks);
                    }
                }
            }
        }

        // Two front towers
        const towerH = 10;
        const towerCorners = [
            { x: 0, z: 0 },
            { x: size - 4, z: 0 }
        ];

        for (const tc of towerCorners) {
            for (let y = 1; y <= towerH; y++) {
                for (let dx = 0; dx < 4; dx++) {
                    for (let dz = 0; dz < 4; dz++) {
                        const isEdge = dx === 0 || dx === 3 || dz === 0 || dz === 3;
                        const block = isEdge ? BLOCK_ID.SAND : BLOCK_ID.AIR;
                        world.setVoxelRaw(startX + tc.x + dx, startY + y, startZ + tc.z + dz, block, dirtyChunks);
                    }
                }
            }
            // Tower tops decorative trim
            for (let dx = 0; dx < 4; dx++) {
                for (let dz = 0; dz < 4; dz++) {
                    world.setVoxelRaw(startX + tc.x + dx, startY + towerH + 1, startZ + tc.z + dz, BLOCK_ID.SAND, dirtyChunks);
                }
            }
        }

        // Temple front entrance in between towers (x: 6..8, z: 0)
        for (let ex = 6; ex <= 8; ex++) {
            world.setVoxelRaw(startX + ex, startY + 1, startZ, BLOCK_ID.AIR, dirtyChunks);
            world.setVoxelRaw(startX + ex, startY + 2, startZ, BLOCK_ID.AIR, dirtyChunks);
        }

        // Blue terracotta center emblem on the floor
        const cx = startX + 7;
        const cz = startZ + 7;
        world.setVoxelRaw(cx, startY, cz, BLOCK_ID.CLAY, dirtyChunks);

        // Secret Chamber deep under center!
        const vaultY = startY - 7;
        for (let dx = -3; dx <= 3; dx++) {
            for (let dz = -3; dz <= 3; dz++) {
                for (let dy = 0; dy <= 5; dy++) {
                    const isWall = dx === -3 || dx === 3 || dz === -3 || dz === 3 || dy === 0 || dy === 5;
                    world.setVoxelRaw(cx + dx, vaultY + dy, cz + dz, isWall ? BLOCK_ID.SAND : BLOCK_ID.AIR, dirtyChunks);
                }
            }
        }

        // 4 Treasure Chests in the 4 corners of the secret chamber!
        const chestOffsets = [[-2, -2], [2, -2], [-2, 2], [2, 2]];
        for (const [ox, oz] of chestOffsets) {
            const chX = cx + ox;
            const chY = vaultY + 1;
            const chZ = cz + oz;
            world.setVoxelRaw(chX, chY, chZ, BLOCK_ID.CHEST, dirtyChunks);
            world.chestLoot.set(`${chX},${chY},${chZ}`, this.getDesertTempleLoot());
        }
    }

    /**
     * Builds a Ruined Portal with obsidian, crying obsidian, netherrack, gold block, and a loot chest
     */
    static buildRuinedPortal(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        // Portal base netherrack island
        for (let dx = -2; dx <= 4; dx++) {
            for (let dz = -2; dz <= 3; dz++) {
                world.setVoxelRaw(startX + dx, startY, startZ + dz, (dx + dz) % 2 === 0 ? BLOCK_ID.NETHERRACK : BLOCK_ID.GRAVEL, dirtyChunks);
            }
        }

        // Obsidian Portal Frame (4 wide, 5 high)
        const frame = [
            [0, 1, BLOCK_ID.OBSIDIAN], [1, 1, BLOCK_ID.OBSIDIAN], [2, 1, BLOCK_ID.OBSIDIAN], [3, 1, BLOCK_ID.OBSIDIAN],
            [0, 2, BLOCK_ID.OBSIDIAN], [3, 2, BLOCK_ID.OBSIDIAN],
            [0, 3, BLOCK_ID.OBSIDIAN], [3, 3, BLOCK_ID.OBSIDIAN],
            [0, 4, BLOCK_ID.OBSIDIAN], [3, 4, BLOCK_ID.OBSIDIAN],
            [0, 5, BLOCK_ID.OBSIDIAN], [1, 5, BLOCK_ID.OBSIDIAN], [2, 5, BLOCK_ID.OBSIDIAN], [3, 5, BLOCK_ID.OBSIDIAN]
        ];

        for (const [fx, fy, id] of frame) {
            // Some blocks are missing in ruined portal!
            if ((fx === 1 && fy === 5) || (fx === 3 && fy === 3)) {
                world.setVoxelRaw(startX + fx, startY + fy, startZ, BLOCK_ID.AIR, dirtyChunks);
            } else {
                world.setVoxelRaw(startX + fx, startY + fy, startZ, id, dirtyChunks);
            }
        }

        // Gold block & Lava pool
        world.setVoxelRaw(startX - 1, startY + 1, startZ - 1, BLOCK_ID.GOLD_ORE, dirtyChunks);
        world.setVoxelRaw(startX + 2, startY, startZ + 1, BLOCK_ID.LAVA, dirtyChunks);

        // Ruined Portal Chest
        const chestX = startX + 4;
        const chestY = startY + 1;
        const chestZ = startZ;
        world.setVoxelRaw(chestX, chestY, chestZ, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${chestX},${chestY},${chestZ}`, this.getRuinedPortalLoot());
    }

    /**
     * Builds an Underground Dungeon with cobblestone, mossy cobblestone, spawner cage and 2 loot chests
     */
    static buildDungeon(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const w = 7;
        const d = 7;
        const h = 4;

        for (let x = 0; x < w; x++) {
            for (let z = 0; z < d; z++) {
                for (let y = 0; y <= h; y++) {
                    const isBorder = x === 0 || x === w - 1 || z === 0 || z === d - 1 || y === 0 || y === h;
                    if (isBorder) {
                        const block = Math.random() > 0.4 ? BLOCK_ID.MOSSY_COBBLESTONE : BLOCK_ID.COBBLESTONE;
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, block, dirtyChunks);
                    } else {
                        world.setVoxelRaw(startX + x, startY + y, startZ + z, BLOCK_ID.AIR, dirtyChunks);
                    }
                }
            }
        }

        // 2 Chests along the walls
        const ch1X = startX + 1;
        const ch1Y = startY + 1;
        const ch1Z = startZ + 3;
        world.setVoxelRaw(ch1X, ch1Y, ch1Z, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${ch1X},${ch1Y},${ch1Z}`, this.getDungeonLoot());

        const ch2X = startX + 5;
        const ch2Y = startY + 1;
        const ch2Z = startZ + 3;
        world.setVoxelRaw(ch2X, ch2Y, ch2Z, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${ch2X},${ch2Y},${ch2Z}`, this.getDungeonLoot());
    }

    /**
     * Builds a Swamp Witch Hut on stilts
     */
    static buildWitchHut(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        const size = 5;
        const stiltHeight = 3;
        const corners = [[0, 0], [size - 1, 0], [0, size - 1], [size - 1, size - 1]];

        // 4 Stilts
        for (const [cx, cz] of corners) {
            for (let y = 0; y <= stiltHeight; y++) {
                world.setVoxelRaw(startX + cx, startY + y, startZ + cz, BLOCK_ID.LOG, dirtyChunks);
            }
        }

        // Platform
        const floorY = startY + stiltHeight;
        for (let x = 0; x < size; x++) {
            for (let z = 0; z < size; z++) {
                world.setVoxelRaw(startX + x, floorY, startZ + z, BLOCK_ID.PLANKS, dirtyChunks);
            }
        }

        // Walls
        for (let y = 1; y <= 3; y++) {
            for (let x = 0; x < size; x++) {
                for (let z = 0; z < size; z++) {
                    const isEdge = x === 0 || x === size - 1 || z === 0 || z === size - 1;
                    if (isEdge) {
                        world.setVoxelRaw(startX + x, floorY + y, startZ + z, BLOCK_ID.PLANKS, dirtyChunks);
                    } else {
                        world.setVoxelRaw(startX + x, floorY + y, startZ + z, BLOCK_ID.AIR, dirtyChunks);
                    }
                }
            }
        }

        // Doorway
        world.setVoxelRaw(startX + 2, floorY + 1, startZ, BLOCK_ID.AIR, dirtyChunks);
        world.setVoxelRaw(startX + 2, floorY + 2, startZ, BLOCK_ID.AIR, dirtyChunks);

        // Roof
        for (let x = -1; x <= size; x++) {
            for (let z = -1; z <= size; z++) {
                world.setVoxelRaw(startX + x, floorY + 4, startZ + z, BLOCK_ID.LOG, dirtyChunks);
            }
        }

        // Chest with potion ingredients!
        const chestX = startX + 1;
        const chestY = floorY + 1;
        const chestZ = startZ + 3;
        world.setVoxelRaw(chestX, chestY, chestZ, BLOCK_ID.CHEST, dirtyChunks);
        world.chestLoot.set(`${chestX},${chestY},${chestZ}`, [
            { kind: 'resource', id: 'redstone', count: 4 },
            { kind: 'resource', id: 'gunpowder', count: 3 },
            { kind: 'resource', id: 'apple', count: 2 },
            { kind: 'resource', id: 'glass', count: 3 }
        ]);
    }

    /**
     * Builds a Village Settlement: Central Well, 2-3 Houses, Blacksmith, and connecting dirt paths
     */
    static buildVillage(world: VoxelWorld, startX: number, startY: number, startZ: number, dirtyChunks?: Set<string>) {
        // Central Well
        this.buildVillageWell(world, startX, startY, startZ, dirtyChunks);

        // Paths leading out from well
        for (let i = -10; i <= 15; i++) {
            // East-West Path
            const px1 = startX + i;
            const pz1 = startZ + 1;
            const py1 = world.findSurfaceY(px1, pz1);
            world.setVoxelRaw(px1, py1, pz1, BLOCK_ID.DIRT, dirtyChunks);
            world.setVoxelRaw(px1, py1, pz1 + 1, BLOCK_ID.GRAVEL, dirtyChunks);

            // North-South Path
            const px2 = startX + 1;
            const pz2 = startZ + i;
            const py2 = world.findSurfaceY(px2, pz2);
            world.setVoxelRaw(px2, py2, pz2, BLOCK_ID.DIRT, dirtyChunks);
            world.setVoxelRaw(px2 + 1, py2, pz2, BLOCK_ID.GRAVEL, dirtyChunks);
        }

        // House 1 (North-East)
        const h1X = startX + 8;
        const h1Z = startZ + 4;
        const h1Y = world.findSurfaceY(h1X + 2, h1Z + 2);
        this.buildPlainsHouse(world, h1X, h1Y, h1Z, dirtyChunks);

        // House 2 (South-West)
        const h2X = startX - 9;
        const h2Z = startZ - 8;
        const h2Y = world.findSurfaceY(h2X + 2, h2Z + 2);
        this.buildPlainsHouse(world, h2X, h2Y, h2Z, dirtyChunks);

        // Blacksmith (North-West)
        const bsX = startX - 10;
        const bsZ = startZ + 6;
        const bsY = world.findSurfaceY(bsX + 3, bsZ + 3);
        this.buildBlacksmith(world, bsX, bsY, bsZ, dirtyChunks);

        // Spawn authentic villagers and an Iron Golem in the generated village!
        const app = (window as any).app;
        if (app && app.friendlyMobManager) {
            app.friendlyMobManager.createFriendly('villager', startX + 2, startY + 2, startZ + 2);
            app.friendlyMobManager.createFriendly('villager', h1X + 2, h1Y + 2, h1Z + 2);
            app.friendlyMobManager.createFriendly('villager', bsX + 3, bsY + 2, bsZ + 3);
            app.friendlyMobManager.createFriendly('iron_golem', startX + 5, startY + 2, startZ - 2);
        } else {
            const key = `${startX},${startZ}`;
            world.villageCenters.add(key);
            world.villageSpawns.set(key, [
                { type: 'villager', x: startX + 2, y: startY + 2, z: startZ + 2 },
                { type: 'villager', x: h1X + 2, y: h1Y + 2, z: h1Z + 2 },
                { type: 'villager', x: bsX + 3, y: bsY + 2, z: bsZ + 3 },
                { type: 'iron_golem', x: startX + 5, y: startY + 2, z: startZ - 2 }
            ]);
        }
    }
}
