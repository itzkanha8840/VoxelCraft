import * as THREE from 'three';
import { CONFIG, BLOCK_ID, BLOCK_DEFS, RESOURCE_DEFS } from './constants';
import { MathKernel, VoxelWorld } from './world';

export class CloudGenerator {
    scene: THREE.Scene;
    clouds: THREE.Mesh[] = [];
    cloudMat: THREE.MeshLambertMaterial;
    speedMultiplier = 1;
    cloudRange = 560;

    constructor(scene: THREE.Scene) {
        this.scene = scene;
        this.cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, transparent: true, opacity: 0.92 });
        for (let i = 0; i < 36; i++) {
            const geo = new THREE.BoxGeometry(24 + Math.random() * 28, 3.6, 20 + Math.random() * 24);
            const mesh = new THREE.Mesh(geo, this.cloudMat);
            mesh.position.set(
                (Math.random() - 0.5) * this.cloudRange,
                104,
                (Math.random() - 0.5) * this.cloudRange
            );
            this.scene.add(mesh);
            this.clouds.push(mesh);
        }
    }

    setCloudColor(color: THREE.Color) {
        this.cloudMat.color.copy(color);
    }

    update(dt: number) {
        const wrap = this.cloudRange * 0.5;
        this.clouds.forEach((c) => {
            c.position.x += dt * 1.2 * this.speedMultiplier;
            if (c.position.x > wrap) c.position.x = -wrap;
        });
    }
}

export class ParticleKernel {
    scene: THREE.Scene;
    particles: THREE.Mesh[] = [];
    maxParticles = 320;

    // Shared geometry pool for peak 60+ FPS performance without garbage churn
    private cubeGeoBreak = new THREE.BoxGeometry(0.11, 0.11, 0.11);
    private cubeGeoHit = new THREE.BoxGeometry(0.065, 0.065, 0.065);
    private cubeGeoStep = new THREE.BoxGeometry(0.08, 0.08, 0.08);
    private cubeGeoDust = new THREE.BoxGeometry(0.14, 0.14, 0.14);
    private dropletGeo = new THREE.BoxGeometry(0.06, 0.08, 0.06);

    // Cached materials by color and opacity to avoid shader re-compilation
    private matCache: Map<string, THREE.MeshBasicMaterial> = new Map();

    constructor(scene: THREE.Scene) {
        this.scene = scene;
    }

    private getMaterial(color: number, transparent = false, opacity = 1.0): THREE.MeshBasicMaterial {
        const key = `${color}_${transparent ? 1 : 0}_${Math.round(opacity * 100)}`;
        let mat = this.matCache.get(key);
        if (!mat) {
            mat = new THREE.MeshBasicMaterial({
                color,
                transparent,
                opacity,
                depthWrite: !transparent
            });
            this.matCache.set(key, mat);
        }
        return mat;
    }

    /**
     * Authentic Minecraft block color palettes for particles
     */
    getBlockColors(blockId: number): number[] {
        switch (blockId) {
            case BLOCK_ID.GRASS:
                return [0x59942a, 0x497b22, 0x6ea534, 0x866043, 0x5a3d24];
            case BLOCK_ID.DIRT:
            case BLOCK_ID.CLAY:
                return [0x866043, 0x6e4a2f, 0x583921, 0x482d18];
            case BLOCK_ID.STONE:
                return [0x7f7f7f, 0x8e8e8e, 0x696969, 0x5a5a5a, 0x9b9b9b];
            case BLOCK_ID.COBBLESTONE:
                return [0x6a6a6a, 0x848484, 0x505050, 0x989898];
            case BLOCK_ID.MOSSY_COBBLESTONE:
                return [0x6a6a6a, 0x597d3a, 0x46652c, 0x848484];
            case BLOCK_ID.STONE_BRICKS:
                return [0x757575, 0x5a5a5a, 0x888888, 0x636363];
            case BLOCK_ID.SAND:
                return [0xdbd3a0, 0xe5dcab, 0xc5ba86, 0xb8ad78];
            case BLOCK_ID.SOUL_SAND:
                return [0x544033, 0x433226, 0x35271e];
            case BLOCK_ID.GRAVEL:
                return [0x807a75, 0x696460, 0x9c9792, 0x56524f];
            case BLOCK_ID.WOOD:
            case BLOCK_ID.LOG:
                return [0x6d5332, 0x544026, 0xa58557, 0x7c5d38];
            case BLOCK_ID.PLANKS:
            case BLOCK_ID.CRAFTING_TABLE:
            case BLOCK_ID.CHEST:
                return [0xa68553, 0x8f6f40, 0xbd9862, 0x745831];
            case BLOCK_ID.BOOKSHELF:
                return [0x8f6f40, 0xa32d2d, 0x2d5ca3, 0x2da348, 0xbd9862];
            case BLOCK_ID.LEAVES:
                return [0x336821, 0x447e28, 0x245016, 0x529432];
            case BLOCK_ID.CHERRY_LEAVES:
                return [0xf5a3b8, 0xffb8cd, 0xdf8198, 0xffccd8];
            case BLOCK_ID.RED_LEAVES:
                return [0xb23428, 0x8f261c, 0xd54a3e, 0x6e1b12];
            case BLOCK_ID.GLASS:
                return [0xd9f3f8, 0xc4e9f2, 0xffffff, 0xb0e0ec];
            case BLOCK_ID.BEDROCK:
                return [0x1c1c1c, 0x333333, 0x141414, 0x272727];
            case BLOCK_ID.BRICKS:
                return [0x964b38, 0xaf533c, 0x743526, 0xd0c0b8];
            case BLOCK_ID.COAL_ORE:
                return [0x7f7f7f, 0x222222, 0x353535, 0x696969];
            case BLOCK_ID.IRON_ORE:
                return [0x7f7f7f, 0xd8af93, 0xcaa085, 0x696969];
            case BLOCK_ID.GOLD_ORE:
                return [0x7f7f7f, 0xfcee4b, 0xe5d038, 0x696969];
            case BLOCK_ID.DIAMOND_ORE:
                return [0x7f7f7f, 0x4dedf0, 0x2ec5c8, 0x696969];
            case BLOCK_ID.REDSTONE_ORE:
                return [0x7f7f7f, 0xff2222, 0xcc1111, 0x696969];
            case BLOCK_ID.EMERALD_ORE:
                return [0x7f7f7f, 0x17dd62, 0x0fa848, 0x696969];
            case BLOCK_ID.LAPIS_ORE:
                return [0x7f7f7f, 0x1b4594, 0x285eb8, 0x696969];
            case BLOCK_ID.RUBY_ORE:
                return [0x7f7f7f, 0xeb2b53, 0xc71f42, 0x696969];
            case BLOCK_ID.NETHERRACK:
                return [0x652626, 0x7d2f2f, 0x481818, 0x351212];
            case BLOCK_ID.NETHER_QUARTZ_ORE:
                return [0x652626, 0xeee8e0, 0xddd5cb, 0x481818];
            case BLOCK_ID.GLOWSTONE:
                return [0xffd768, 0xeea835, 0xfff0aa, 0xd48f24];
            case BLOCK_ID.OBSIDIAN:
                return [0x19102c, 0x120a22, 0x2b1c4b, 0x0c0618];
            case BLOCK_ID.SNOW:
                return [0xffffff, 0xeef5fc, 0xd8e8f8, 0xc5dcf4];
            case BLOCK_ID.CACTUS:
                return [0x3e6822, 0x51852d, 0x2e4f18];
            case BLOCK_ID.TALL_GRASS:
                return [0x59942a, 0x497b22, 0x6ea534];
            case BLOCK_ID.FLOWER_RED:
                return [0xdd2222, 0xbb1111, 0x3d7022];
            case BLOCK_ID.FLOWER_YELLOW:
                return [0xffdd22, 0xeecc11, 0x3d7022];
            case BLOCK_ID.BAMBOO:
                return [0x5e9b28, 0x7ab83c, 0x48791c];
            case BLOCK_ID.FURNACE:
                return [0x5a5a5a, 0x757575, 0x3d3d3d];
            case BLOCK_ID.TNT:
                return [0xdb3226, 0xffffff, 0x222222];
            case BLOCK_ID.PUMPKIN:
            case BLOCK_ID.JACK_O_LANTERN:
                return [0xdf7218, 0xffdd44, 0xbd5a0f, 0x5a8824];
            case BLOCK_ID.HAY_BALE:
                return [0xc8aa32, 0xaa8c24, 0x8a3020];
            default:
                return [0x7f7f7f, 0x8e8e8e, 0x696969];
        }
    }

    /**
     * Material category for block physics & particle behavior
     */
    getMaterialType(blockId: number): 'grass' | 'sand' | 'stone' | 'dirt' | 'wood' | 'snow' | 'glass' | 'foliage' | 'other' {
        switch (blockId) {
            case BLOCK_ID.GRASS:
            case BLOCK_ID.TALL_GRASS:
            case BLOCK_ID.FLOWER_RED:
            case BLOCK_ID.FLOWER_YELLOW:
                return 'grass';
            case BLOCK_ID.SAND:
            case BLOCK_ID.SOUL_SAND:
                return 'sand';
            case BLOCK_ID.STONE:
            case BLOCK_ID.COBBLESTONE:
            case BLOCK_ID.MOSSY_COBBLESTONE:
            case BLOCK_ID.BEDROCK:
            case BLOCK_ID.STONE_BRICKS:
            case BLOCK_ID.BRICKS:
            case BLOCK_ID.FURNACE:
            case BLOCK_ID.OBSIDIAN:
            case BLOCK_ID.COAL_ORE:
            case BLOCK_ID.IRON_ORE:
            case BLOCK_ID.GOLD_ORE:
            case BLOCK_ID.DIAMOND_ORE:
            case BLOCK_ID.REDSTONE_ORE:
            case BLOCK_ID.EMERALD_ORE:
            case BLOCK_ID.LAPIS_ORE:
            case BLOCK_ID.RUBY_ORE:
            case BLOCK_ID.NETHERRACK:
            case BLOCK_ID.NETHER_QUARTZ_ORE:
                return 'stone';
            case BLOCK_ID.DIRT:
            case BLOCK_ID.CLAY:
            case BLOCK_ID.GRAVEL:
                return 'dirt';
            case BLOCK_ID.WOOD:
            case BLOCK_ID.LOG:
            case BLOCK_ID.PLANKS:
            case BLOCK_ID.CHEST:
            case BLOCK_ID.CRAFTING_TABLE:
            case BLOCK_ID.BOOKSHELF:
                return 'wood';
            case BLOCK_ID.LEAVES:
            case BLOCK_ID.CHERRY_LEAVES:
            case BLOCK_ID.RED_LEAVES:
            case BLOCK_ID.CACTUS:
            case BLOCK_ID.BAMBOO:
            case BLOCK_ID.MUSHROOM_CAP:
                return 'foliage';
            case BLOCK_ID.SNOW:
                return 'snow';
            case BLOCK_ID.GLASS:
                return 'glass';
            default:
                return 'other';
        }
    }

    /**
     * Minecraft Block Breaking visual effect:
     * Explodes 26-32 mini-cube debris particles outward with authentic Minecraft physics,
     * tumbling rotations, upward pop, and ground settling.
     */
    spawnBlockBreak(bx: number, by: number, bz: number, blockId: number) {
        if (blockId === BLOCK_ID.AIR || blockId === BLOCK_ID.WATER || blockId === BLOCK_ID.LAVA) return;

        const colors = this.getBlockColors(blockId);
        const isGlass = blockId === BLOCK_ID.GLASS;
        const particleCount = isGlass ? 24 : 30;

        for (let i = 0; i < particleCount; i++) {
            const color = colors[Math.floor(Math.random() * colors.length)];
            const mat = this.getMaterial(color, isGlass, isGlass ? 0.65 : 1.0);
            const m = new THREE.Mesh(this.cubeGeoBreak, mat);

            // Spawn within the 3D volume of the block [bx, bx + 1], etc.
            const px = bx + 0.15 + Math.random() * 0.7;
            const py = by + 0.15 + Math.random() * 0.7;
            const pz = bz + 0.15 + Math.random() * 0.7;
            m.position.set(px, py, pz);

            // Random initial rotation
            m.rotation.set(
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2
            );

            // Outward burst from block center + upward arc
            const relX = px - (bx + 0.5);
            const relZ = pz - (bz + 0.5);
            const burstSpeed = 2.8 + Math.random() * 2.2;
            const upSpeed = 1.8 + Math.random() * 3.2;

            const scale = 0.7 + Math.random() * 0.6;
            m.scale.set(scale, scale, scale);

            m.userData = {
                vel: new THREE.Vector3(
                    relX * burstSpeed + (Math.random() - 0.5) * 1.5,
                    upSpeed,
                    relZ * burstSpeed + (Math.random() - 0.5) * 1.5
                ),
                rotVel: new THREE.Vector3(
                    (Math.random() - 0.5) * 12,
                    (Math.random() - 0.5) * 12,
                    (Math.random() - 0.5) * 12
                ),
                gravity: 12.0,
                drag: 0.96,
                floorY: by,
                baseScale: scale,
                shrinkOnDeath: true,
                isPhysics: true,
                life: 0.55 + Math.random() * 0.35,
                maxLife: 0.90
            };

            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    /**
     * Block Mining Chip visual effect:
     * Small chip particles flaking off when player strikes a block
     */
    spawnBlockHit(bx: number, by: number, bz: number, blockId: number, normal?: THREE.Vector3) {
        if (blockId === BLOCK_ID.AIR || blockId === BLOCK_ID.WATER || blockId === BLOCK_ID.LAVA) return;
        const colors = this.getBlockColors(blockId);
        const count = 4 + Math.floor(Math.random() * 3);

        const nx = normal ? normal.x : (Math.random() - 0.5);
        const ny = normal ? normal.y : 0.6;
        const nz = normal ? normal.z : (Math.random() - 0.5);

        for (let i = 0; i < count; i++) {
            const color = colors[Math.floor(Math.random() * colors.length)];
            const mat = this.getMaterial(color, false, 1.0);
            const m = new THREE.Mesh(this.cubeGeoHit, mat);

            const px = bx + 0.5 + nx * 0.48 + (Math.random() - 0.5) * 0.4;
            const py = by + 0.5 + ny * 0.48 + (Math.random() - 0.5) * 0.4;
            const pz = bz + 0.5 + nz * 0.48 + (Math.random() - 0.5) * 0.4;
            m.position.set(px, py, pz);

            const scale = 0.8 + Math.random() * 0.5;
            m.scale.set(scale, scale, scale);

            m.userData = {
                vel: new THREE.Vector3(
                    nx * 1.5 + (Math.random() - 0.5) * 2.2,
                    Math.max(0.8, ny * 1.8 + Math.random() * 2.0),
                    nz * 1.5 + (Math.random() - 0.5) * 2.2
                ),
                rotVel: new THREE.Vector3(
                    (Math.random() - 0.5) * 16,
                    (Math.random() - 0.5) * 16,
                    (Math.random() - 0.5) * 16
                ),
                gravity: 14.0,
                drag: 0.94,
                floorY: by,
                baseScale: scale,
                shrinkOnDeath: true,
                isPhysics: true,
                life: 0.35 + Math.random() * 0.25,
                maxLife: 0.60
            };

            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    /**
     * Tool Breaking Particle Burst:
     * High-speed scattering fragment particles when a tool breaks at zero durability.
     */
    spawnToolBreak(x: number, y: number, z: number, color = 0xcccccc) {
        for (let i = 0; i < 24; i++) {
            const mat = this.getMaterial(color, false, 1.0);
            const m = new THREE.Mesh(this.cubeGeoBreak, mat);
            const px = x + (Math.random() - 0.5) * 0.4;
            const py = y + (Math.random() - 0.5) * 0.4;
            const pz = z + (Math.random() - 0.5) * 0.4;
            m.position.set(px, py, pz);
            const scale = 0.7 + Math.random() * 0.6;
            m.scale.set(scale, scale, scale);
            m.userData = {
                vel: new THREE.Vector3(
                    (Math.random() - 0.5) * 4.0,
                    1.5 + Math.random() * 3.5,
                    (Math.random() - 0.5) * 4.0
                ),
                rotVel: new THREE.Vector3(
                    (Math.random() - 0.5) * 20,
                    (Math.random() - 0.5) * 20,
                    (Math.random() - 0.5) * 20
                ),
                gravity: 12.0,
                drag: 0.95,
                shrinkOnDeath: true,
                isPhysics: true,
                life: 0.6 + Math.random() * 0.4,
                maxLife: 1.0
            };
            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    /**
     * Landing from High Jumps visual effect:
     * Spawns an expanding radial shockwave puff of dust particles at the player's feet.
     * The particle density, radius, and spread scale with the fall distance,
     * and match the texture/color of the material landed upon (sand, grass, stone, etc.).
     */
    spawnLandingDust(x: number, y: number, z: number, blockId: number, fallDistance: number) {
        if (blockId === BLOCK_ID.AIR || blockId === BLOCK_ID.WATER || blockId === BLOCK_ID.LAVA) return;

        const matType = this.getMaterialType(blockId);
        const colors = this.getBlockColors(blockId);

        // Particle count and intensity scale with jump/fall height
        let count = 14;
        let radiusSpeed = 2.0;
        let verticalBillow = 0.8;

        if (fallDistance > 4.5) {
            // High jump landing (massive dust explosion)
            count = 42;
            radiusSpeed = 4.2 + Math.min(fallDistance, 14) * 0.32;
            verticalBillow = 1.8;
        } else if (fallDistance > 2.0) {
            // Medium jump landing
            count = 24;
            radiusSpeed = 3.0 + fallDistance * 0.3;
            verticalBillow = 1.2;
        }

        for (let i = 0; i < count; i++) {
            const color = colors[Math.floor(Math.random() * colors.length)];
            const mat = this.getMaterial(color, true, 0.82);
            const m = new THREE.Mesh(this.cubeGeoDust, mat);

            // Spread horizontally in a full circular ring
            const theta = (i / count) * Math.PI * 2 + (Math.random() - 0.5) * 0.35;
            const dist = 0.15 + Math.random() * 0.25;
            m.position.set(
                x + Math.cos(theta) * dist,
                y + 0.05 + Math.random() * 0.08,
                z + Math.sin(theta) * dist
            );

            const speed = radiusSpeed * (0.7 + Math.random() * 0.6);
            const vy = (0.4 + Math.random() * verticalBillow) * (matType === 'sand' ? 0.75 : 1.0);
            const scale = (0.7 + Math.random() * 0.6) * (fallDistance > 3 ? 1.3 : 1.0);
            m.scale.set(scale, scale, scale);

            m.userData = {
                vel: new THREE.Vector3(
                    Math.cos(theta) * speed,
                    vy,
                    Math.sin(theta) * speed
                ),
                rotVel: new THREE.Vector3(
                    (Math.random() - 0.5) * 6,
                    (Math.random() - 0.5) * 6,
                    (Math.random() - 0.5) * 6
                ),
                gravity: matType === 'sand' ? 2.5 : 4.0,
                drag: 0.87, // High air resistance creates expanding billowing cloud
                floorY: y,
                baseScale: scale,
                scaleRate: 1.5, // Puffs outward as it fades
                fade: true,
                isPhysics: true,
                life: 0.45 + Math.random() * 0.30,
                maxLife: 0.75
            };

            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    /**
     * Walking / Sprinting visual effects on different materials:
     * - Sand: Soft, powdery tan dust billowing gently behind heels
     * - Grass: Crisp green grass blades and earthy soil crumb spray
     * - Stone: Snappy rock chips and grey impact dust bouncing backward
     * - Wood: Sawdust specks
     * - Snow: Fluffy white snow plumes
     */
    spawnFootstep(
        x: number,
        y: number,
        z: number,
        blockId: number,
        isSprinting: boolean,
        moveDir: THREE.Vector3
    ) {
        if (blockId === BLOCK_ID.AIR || blockId === BLOCK_ID.WATER || blockId === BLOCK_ID.LAVA) return;

        const matType = this.getMaterialType(blockId);
        const colors = this.getBlockColors(blockId);

        let count = isSprinting ? 7 : 4;
        let kickForce = isSprinting ? 2.6 : 1.5;
        let liftForce = isSprinting ? 1.6 : 1.0;

        if (matType === 'sand') {
            count = isSprinting ? 9 : 5;
            kickForce = isSprinting ? 1.8 : 1.1;
            liftForce = isSprinting ? 1.3 : 0.8;
        } else if (matType === 'stone') {
            count = isSprinting ? 6 : 3;
            kickForce = isSprinting ? 2.8 : 1.7;
            liftForce = isSprinting ? 1.8 : 1.1;
        }

        for (let i = 0; i < count; i++) {
            let color: number;
            if (matType === 'grass') {
                // 75% grass green, 25% dirt crumb
                color = (Math.random() < 0.75)
                    ? (colors[Math.floor(Math.random() * 3)])
                    : (colors[3] || 0x866043);
            } else {
                color = colors[Math.floor(Math.random() * colors.length)];
            }

            const isDusty = matType === 'sand' || matType === 'snow';
            const mat = this.getMaterial(color, isDusty, isDusty ? 0.85 : 1.0);
            const geo = isDusty ? this.cubeGeoDust : this.cubeGeoStep;
            const m = new THREE.Mesh(geo, mat);

            // Position at heels, offset slightly left/right
            const sideOffset = (Math.random() - 0.5) * 0.35;
            const backOffset = 0.15 + Math.random() * 0.2;
            m.position.set(
                x - moveDir.x * backOffset - moveDir.z * sideOffset,
                y + 0.04 + Math.random() * 0.06,
                z - moveDir.z * backOffset + moveDir.x * sideOffset
            );

            // Backward kick velocity with slight lateral scatter
            const scatterX = (Math.random() - 0.5) * 0.9;
            const scatterZ = (Math.random() - 0.5) * 0.9;
            const vx = -moveDir.x * kickForce + scatterX;
            const vz = -moveDir.z * kickForce + scatterZ;
            const vy = liftForce * (0.5 + Math.random() * 0.7);

            const scale = (isDusty ? 0.7 : 0.8) * (isSprinting ? 1.25 : 0.9);
            m.scale.set(scale, scale, scale);

            m.userData = {
                vel: new THREE.Vector3(vx, vy, vz),
                rotVel: new THREE.Vector3(
                    (Math.random() - 0.5) * 14,
                    (Math.random() - 0.5) * 14,
                    (Math.random() - 0.5) * 14
                ),
                gravity: matType === 'sand' ? 3.5 : (matType === 'stone' ? 14.0 : 9.0),
                drag: matType === 'sand' ? 0.88 : 0.94,
                floorY: y,
                baseScale: scale,
                shrinkOnDeath: !isDusty,
                fade: isDusty,
                scaleRate: isDusty ? 1.3 : 0,
                isPhysics: true,
                life: 0.30 + Math.random() * (isDusty ? 0.25 : 0.18),
                maxLife: 0.55
            };

            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    /**
     * Water wading/running splash effect
     */
    spawnWaterSplash(x: number, y: number, z: number, isSprinting: boolean) {
        const count = isSprinting ? 8 : 4;
        const colors = [0x9be8ff, 0xd2f8ff, 0xffffff, 0x6ac2f0];

        for (let i = 0; i < count; i++) {
            const color = colors[i % colors.length];
            const mat = this.getMaterial(color, true, 0.75);
            const m = new THREE.Mesh(this.dropletGeo, mat);

            const angle = Math.random() * Math.PI * 2;
            const speed = (isSprinting ? 2.5 : 1.4) * (0.6 + Math.random() * 0.6);

            m.position.set(
                x + (Math.random() - 0.5) * 0.4,
                y + 0.05,
                z + (Math.random() - 0.5) * 0.4
            );

            m.userData = {
                vel: new THREE.Vector3(
                    Math.cos(angle) * speed,
                    1.2 + Math.random() * (isSprinting ? 1.8 : 1.0),
                    Math.sin(angle) * speed
                ),
                gravity: 12.0,
                drag: 0.92,
                floorY: y,
                baseScale: 1.0,
                shrinkOnDeath: true,
                isPhysics: true,
                life: 0.35 + Math.random() * 0.2,
                maxLife: 0.55
            };

            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    spawnFlame(x: number, y: number, z: number) {
        const geo = new THREE.SphereGeometry(0.08 + Math.random() * 0.05, 4, 4);
        const colors = [0xff5500, 0xff8800, 0xffcc00, 0xff3300];
        const mat = new THREE.MeshBasicMaterial({
            color: colors[Math.floor(Math.random() * colors.length)],
            transparent: true,
            opacity: 0.9,
            depthWrite: false
        });
        const m = new THREE.Mesh(geo, mat);
        m.position.set(
            x + (Math.random() - 0.5) * 0.4,
            y + Math.random() * 0.5,
            z + (Math.random() - 0.5) * 0.4
        );
        m.userData = {
            vel: new THREE.Vector3((Math.random() - 0.5) * 0.06, 0.12 + Math.random() * 0.15, (Math.random() - 0.5) * 0.06),
            life: 0.45,
            maxLife: 0.45
        };
        this.scene.add(m);
        this.particles.push(m);
        this.trimParticlePool();
    }

    spawnSmoke(x: number, y: number, z: number) {
        const geo = new THREE.SphereGeometry(0.1 + Math.random() * 0.08, 4, 4);
        const mat = new THREE.MeshBasicMaterial({
            color: 0x333333,
            transparent: true,
            opacity: 0.6,
            depthWrite: false
        });
        const m = new THREE.Mesh(geo, mat);
        m.position.set(
            x + (Math.random() - 0.5) * 0.3,
            y + 0.3 + Math.random() * 0.4,
            z + (Math.random() - 0.5) * 0.3
        );
        m.userData = {
            vel: new THREE.Vector3((Math.random() - 0.5) * 0.04, 0.08 + Math.random() * 0.08, (Math.random() - 0.5) * 0.04),
            scaleRate: 2.5,
            life: 0.7,
            maxLife: 0.7
        };
        this.scene.add(m);
        this.particles.push(m);
        this.trimParticlePool();
    }

    spawnDebris(x: number, y: number, z: number, color: number) {
        const geo = new THREE.SphereGeometry(0.08, 4, 4);
        const mat = new THREE.MeshBasicMaterial({ color });
        for (let i = 0; i < 6; i++) {
            const m = new THREE.Mesh(geo, mat);
            m.position.set(x, y, z);
            m.userData = {
                vel: new THREE.Vector3((Math.random() - 0.5) * 0.25, 0.1 + Math.random() * 0.25, (Math.random() - 0.5) * 0.25),
                rotVel: new THREE.Vector3((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8),
                life: 0.6,
                maxLife: 0.6
            };
            this.scene.add(m);
            this.particles.push(m);
        }
        this.trimParticlePool();
    }

    spawnWindTrail(x: number, y: number, z: number) {
        const geo = new THREE.SphereGeometry(0.06, 4, 4);
        const mat = new THREE.MeshBasicMaterial({
            color: Math.random() > 0.4 ? 0xbbf3ff : 0xe8fbff,
            transparent: true,
            opacity: 0.75,
            depthWrite: false
        });
        const m = new THREE.Mesh(geo, mat);
        m.position.set(
            x + (Math.random() - 0.5) * 0.15,
            y + (Math.random() - 0.5) * 0.15,
            z + (Math.random() - 0.5) * 0.15
        );
        m.userData = {
            vel: new THREE.Vector3((Math.random() - 0.5) * 0.05, (Math.random() - 0.5) * 0.05, (Math.random() - 0.5) * 0.05),
            life: 0.35,
            maxLife: 0.35
        };
        this.scene.add(m);
        this.particles.push(m);
        this.trimParticlePool();
    }

    spawnWindBurst(x: number, y: number, z: number) {
        const pCount = 20;
        const sphereGeo = new THREE.SphereGeometry(0.1, 4, 4);
        const colors = [0xd2f8ff, 0x9deaff, 0xffffff, 0xb8f4ff];
        for (let i = 0; i < pCount; i++) {
            const mat = new THREE.MeshBasicMaterial({
                color: colors[i % colors.length],
                transparent: true,
                opacity: 0.9,
                depthWrite: false
            });
            const p = new THREE.Mesh(sphereGeo, mat);
            p.position.set(x, y, z);
            const theta = Math.random() * Math.PI * 2;
            const phi = (Math.random() - 0.3) * Math.PI;
            const speed = 0.25 + Math.random() * 0.35;
            p.userData = {
                vel: new THREE.Vector3(
                    Math.cos(theta) * Math.cos(phi) * speed,
                    Math.sin(phi) * speed * 0.8 + 0.15,
                    Math.sin(theta) * Math.cos(phi) * speed
                ),
                life: 0.55,
                maxLife: 0.55
            };
            this.scene.add(p);
            this.particles.push(p);
        }

        const ringGeo = new THREE.TorusGeometry(0.3, 0.06, 4, 16);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0xc4f6ff,
            transparent: true,
            opacity: 0.8,
            depthWrite: false
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.position.set(x, y + 0.1, z);
        ring.rotation.x = Math.PI / 2;
        ring.userData = {
            vel: new THREE.Vector3(0, 0.05, 0),
            scaleRate: 7.0,
            life: 0.4,
            maxLife: 0.4
        };
        this.scene.add(ring);
        this.particles.push(ring);
        this.trimParticlePool();
    }

    private trimParticlePool() {
        while (this.particles.length > this.maxParticles) {
            const oldest = this.particles.shift();
            if (oldest) {
                this.scene.remove(oldest);
            }
        }
    }

    update(dt: number) {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            const data = p.userData;
            data.life -= dt;

            if (data.isPhysics) {
                // Realistic physics simulation
                if (data.gravity) {
                    data.vel.y -= data.gravity * dt;
                }
                if (data.drag) {
                    const dragFactor = Math.pow(data.drag, dt * 60);
                    data.vel.x *= dragFactor;
                    data.vel.z *= dragFactor;
                }

                p.position.x += data.vel.x * dt;
                p.position.y += data.vel.y * dt;
                p.position.z += data.vel.z * dt;

                // Floor bounce / settle
                if (data.floorY !== undefined && p.position.y <= data.floorY) {
                    p.position.y = data.floorY;
                    data.vel.y = -data.vel.y * 0.22;
                    data.vel.x *= 0.65;
                    data.vel.z *= 0.65;
                }

                // Rotational tumbling
                if (data.rotVel) {
                    p.rotation.x += data.rotVel.x * dt;
                    p.rotation.y += data.rotVel.y * dt;
                    p.rotation.z += data.rotVel.z * dt;
                }

                // Shrink / Scale
                const lifeRatio = Math.max(0, data.life / data.maxLife);
                if (data.shrinkOnDeath) {
                    const s = (data.baseScale || 1.0) * Math.min(1.0, lifeRatio * 1.4);
                    p.scale.set(s, s, s);
                } else if (data.scaleRate) {
                    const s = (data.baseScale || 1.0) * (1 + (1 - lifeRatio) * data.scaleRate);
                    p.scale.set(s, s, s);
                }

                // Opacity fade
                if (data.fade && (p.material as THREE.Material).transparent) {
                    (p.material as any).opacity = Math.max(0, lifeRatio * 0.85);
                }
            } else {
                // Legacy per-frame velocity handling for flame/wind
                if (data.vel) {
                    p.position.add(data.vel);
                }
                if (data.rotVel) {
                    p.rotation.x += data.rotVel.x * dt;
                    p.rotation.y += data.rotVel.y * dt;
                    p.rotation.z += data.rotVel.z * dt;
                }
                if (data.scaleRate && data.maxLife) {
                    const s = 1 + (1 - (data.life / data.maxLife)) * data.scaleRate;
                    p.scale.set(s, s, s);
                }
                if ((p.material as THREE.Material).transparent && data.maxLife) {
                    (p.material as any).opacity = Math.max(0, data.life / data.maxLife);
                }
            }

            if (data.life <= 0) {
                this.scene.remove(p);
                this.particles.splice(i, 1);
            }
        }
    }
}

export class WeatherKernel {
    scene: THREE.Scene;
    intensity = 0;
    time = 0;

    constructor(scene: THREE.Scene) {
        this.scene = scene;
    }
    setWeather(type: 'clear' | 'rain' | 'thunder' | string) {
        if (type === 'rain') {
            this.startRain();
        } else if (type === 'thunder') {
            this.intensity = 1.5;
        } else {
            this.stopRain();
        }
    }
    startRain() { this.intensity = 1.0; }
    stopRain() { this.intensity = 0.0; }
    update(dt: number) { this.time += dt; }
}

export class DayNightCycleKernel {
    scene: THREE.Scene;
    renderer: THREE.WebGLRenderer;
    length = 240; // 4 minutes full 24-hr day/night cycle
    time = 60; // starts in morning (approx 6:00 AM)
    celestialGroup: THREE.Group;
    sunMesh: THREE.Mesh;
    sunCoronaMesh: THREE.Mesh;
    moonMesh: THREE.Mesh;
    moonCoronaMesh: THREE.Mesh;
    stars: THREE.Points;
    starMaterial: THREE.PointsMaterial;
    skyDomeMesh: THREE.Mesh;
    skyCanvas: HTMLCanvasElement;
    skyCtx: CanvasRenderingContext2D;
    skyTexture: THREE.CanvasTexture;
    currentHorizonColor: THREE.Color = new THREE.Color(0x78a7ff);
    currentZenithColor: THREE.Color = new THREE.Color(0x1a5bb8);
    lastSkyUpdate = 0;

    constructor(scene: THREE.Scene, renderer: THREE.WebGLRenderer) {
        this.scene = scene;
        this.renderer = renderer;

        // 1. Photorealistic 3D Atmospheric Sky Dome (seamless 360 gradient)
        this.skyCanvas = document.createElement('canvas');
        this.skyCanvas.width = 16;
        this.skyCanvas.height = 256;
        this.skyCtx = this.skyCanvas.getContext('2d')!;
        this.skyTexture = new THREE.CanvasTexture(this.skyCanvas);
        this.skyTexture.generateMipmaps = false;
        this.skyTexture.magFilter = THREE.LinearFilter;
        this.skyTexture.minFilter = THREE.LinearFilter;
        this.skyTexture.wrapS = THREE.ClampToEdgeWrapping;
        this.skyTexture.wrapT = THREE.ClampToEdgeWrapping;

        const skyGeo = new THREE.SphereGeometry(420, 32, 24);
        const skyMat = new THREE.MeshBasicMaterial({
            map: this.skyTexture,
            side: THREE.BackSide,
            depthWrite: false,
            fog: false
        });
        this.skyDomeMesh = new THREE.Mesh(skyGeo, skyMat);
        this.skyDomeMesh.renderOrder = -999;
        this.scene.add(this.skyDomeMesh);

        // 2. Celestial group holding Sun, Moon, and Stars
        this.celestialGroup = new THREE.Group();
        this.scene.add(this.celestialGroup);

        // Authentic Minecraft Square Sun: Flat crisp billboard
        const sunTex = this.createMinecraftSunTexture();
        const sunGeo = new THREE.PlaneGeometry(38, 38);
        const sunMat = new THREE.MeshBasicMaterial({
            map: sunTex,
            transparent: true,
            fog: false,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.sunMesh = new THREE.Mesh(sunGeo, sunMat);
        this.sunMesh.position.set(0, 0, -220);
        this.sunMesh.lookAt(0, 0, 0);
        this.celestialGroup.add(this.sunMesh);

        // Empty dummy group for corona compatibility
        this.sunCoronaMesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial({ visible: false }));

        // Authentic Minecraft Square Moon: Flat crisp billboard opposite sun
        const moonTex = this.createMinecraftMoonTexture();
        const moonGeo = new THREE.PlaneGeometry(34, 34);
        const moonMat = new THREE.MeshBasicMaterial({
            map: moonTex,
            transparent: true,
            fog: false,
            depthWrite: false,
            side: THREE.DoubleSide
        });
        this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
        this.moonMesh.position.set(0, 0, 220);
        this.moonMesh.lookAt(0, 0, 0);
        this.celestialGroup.add(this.moonMesh);

        // Empty dummy group for moon corona compatibility
        this.moonCoronaMesh = new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshBasicMaterial({ visible: false }));

        // Authentic Minecraft Starfield: Crisp square pixel stars
        const starGeo = new THREE.BufferGeometry();
        const starPositions: number[] = [];
        const starColors: number[] = [];
        const starPalette = [
            [1.0, 1.0, 1.0],       // Diamond white
            [0.92, 0.96, 1.0],     // Sirius blue-white
            [1.0, 0.95, 0.85],     // Warm white
            [0.85, 0.92, 1.0]      // Distant pale blue
        ];

        for (let i = 0; i < 900; i++) {
            const u = Math.random();
            const v = Math.random();
            const theta = u * 2.0 * Math.PI;
            const phi = Math.acos(2.0 * v - 1.0);
            const r = 260 + Math.random() * 30;
            const x = r * Math.sin(phi) * Math.cos(theta);
            const y = r * Math.sin(phi) * Math.sin(theta);
            const z = r * Math.cos(phi);
            starPositions.push(x, y, z);

            const col = starPalette[Math.floor(Math.random() * starPalette.length)];
            const brightness = 0.75 + Math.random() * 0.25;
            starColors.push(col[0] * brightness, col[1] * brightness, col[2] * brightness);
        }
        starGeo.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
        starGeo.setAttribute('color', new THREE.Float32BufferAttribute(starColors, 3));

        this.starMaterial = new THREE.PointsMaterial({
            size: 2.5,
            vertexColors: true,
            fog: false,
            transparent: true,
            opacity: 0,
            depthWrite: false
        });
        this.stars = new THREE.Points(starGeo, this.starMaterial);
        this.celestialGroup.add(this.stars);

        this.updateSkyGradient(0.5);
    }

    createMinecraftSunTexture(): THREE.CanvasTexture {
        const canvas = document.createElement('canvas');
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext('2d')!;
        ctx.clearRect(0, 0, 32, 32);

        // Outer golden yellow rim (2 px)
        ctx.fillStyle = '#ffaa00';
        ctx.fillRect(1, 1, 30, 30);

        // Warm yellow limb (3 px)
        ctx.fillStyle = '#fff478';
        ctx.fillRect(3, 3, 26, 26);

        // Brilliant pure white core (20x20 px)
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(6, 6, 20, 20);

        const tex = new THREE.CanvasTexture(canvas);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.generateMipmaps = false;
        return tex;
    }

    createMinecraftMoonTexture(): THREE.CanvasTexture {
        const canvas = document.createElement('canvas');
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext('2d')!;
        ctx.clearRect(0, 0, 32, 32);

        // Outer pale silver border (2 px)
        ctx.fillStyle = '#9aaecf';
        ctx.fillRect(1, 1, 30, 30);

        // Moon base white body
        ctx.fillStyle = '#f4f7fc';
        ctx.fillRect(3, 3, 26, 26);

        // Authentic pixelated square crater clusters
        ctx.fillStyle = '#7a8ba8';
        // Crater cluster 1 (top-left)
        ctx.fillRect(6, 6, 6, 5);
        ctx.fillRect(8, 11, 4, 3);
        // Crater cluster 2 (top-right)
        ctx.fillRect(18, 7, 7, 6);
        ctx.fillRect(16, 9, 3, 4);
        // Crater cluster 3 (bottom-left)
        ctx.fillRect(7, 18, 8, 7);
        ctx.fillRect(5, 20, 3, 4);
        // Crater cluster 4 (bottom-right)
        ctx.fillRect(19, 19, 6, 6);

        // Deep crater shadow pixels
        ctx.fillStyle = '#5c6d8a';
        ctx.fillRect(8, 7, 3, 3);
        ctx.fillRect(20, 8, 4, 3);
        ctx.fillRect(9, 20, 4, 3);
        ctx.fillRect(20, 20, 3, 3);

        const tex = new THREE.CanvasTexture(canvas);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.generateMipmaps = false;
        return tex;
    }

    updateSkyGradient(sunY: number) {
        // Vertical gradient: index 0 (top = Zenith) -> 128 (middle = Horizon) -> 256 (bottom = Nadir/Ground)
        const grad = this.skyCtx.createLinearGradient(0, 0, 0, 256);

        if (sunY > 0.25) {
            // Bright Authentic Minecraft Daytime
            grad.addColorStop(0.0, '#78a7ff');   // Vanilla sky blue
            grad.addColorStop(0.42, '#8cb5ff');  // Lower sky
            grad.addColorStop(0.50, '#b8d2ff');  // Horizon fog tint
            grad.addColorStop(0.58, '#8baed8');  // Ground transition
            grad.addColorStop(1.0, '#4868a0');   // Ground nadir
            this.currentZenithColor.setHex(0x78a7ff);
            this.currentHorizonColor.setHex(0xb8d2ff);
        } else if (sunY > -0.15) {
            // Vanilla Sunrise / Sunset: Golden Amber / Orange Horizon & Twilight Zenith
            const t = (sunY + 0.15) / 0.40;
            if (t > 0.5) {
                // Golden hour
                grad.addColorStop(0.0, '#445588');  // Twilight blue zenith
                grad.addColorStop(0.40, '#775878'); // Violet transition
                grad.addColorStop(0.50, '#ffaa55'); // Golden orange Minecraft horizon
                grad.addColorStop(0.56, '#ea5e32'); // Warm horizon band
                grad.addColorStop(1.0, '#301c18');  // Ground dusk
                this.currentZenithColor.setHex(0x445588);
                this.currentHorizonColor.setHex(0xffaa55);
            } else {
                // Deep twilight dusk
                grad.addColorStop(0.0, '#181838');  // Deep indigo zenith
                grad.addColorStop(0.38, '#3c2448'); // Dusk arch
                grad.addColorStop(0.50, '#d85820'); // Fiery horizon glow
                grad.addColorStop(0.58, '#882810'); // Burnt rim
                grad.addColorStop(1.0, '#120c10');  // Night ground
                this.currentZenithColor.setHex(0x181838);
                this.currentHorizonColor.setHex(0xd85820);
            }
        } else {
            // Authentic Minecraft Night Sky
            grad.addColorStop(0.0, '#0a0e1a');   // Dark navy space
            grad.addColorStop(0.40, '#0d1322');  // High nocturnal atmosphere
            grad.addColorStop(0.50, '#121a30');  // Horizon blue-black haze
            grad.addColorStop(0.56, '#0c1222');  // Lower haze
            grad.addColorStop(1.0, '#050810');   // Pitch ground
            this.currentZenithColor.setHex(0x0a0e1a);
            this.currentHorizonColor.setHex(0x121a30);
        }

        this.skyCtx.fillStyle = grad;
        this.skyCtx.fillRect(0, 0, 16, 256);
        this.skyTexture.needsUpdate = true;
    }

    get timeOfDay(): number {
        const normalized = (((this.time % this.length) + this.length) % this.length) / this.length;
        return Math.round(normalized * 24000);
    }

    setTime(ticks: number) {
        const t = ((ticks % 24000) + 24000) % 24000;
        this.time = (t / 24000) * this.length;
    }

    addTime(ticks: number) {
        const currentTicks = this.timeOfDay;
        this.setTime(currentTicks + ticks);
    }

    update(
        dt: number,
        sunLight: THREE.DirectionalLight,
        scene: THREE.Scene,
        playerPos: THREE.Vector3,
        ambientLight?: THREE.AmbientLight,
        moonLight?: THREE.DirectionalLight,
        hemisphereLight?: THREE.HemisphereLight,
        cloudGen?: CloudGenerator
    ): number {
        this.time += dt;
        const t = (((this.time % this.length) + this.length) % this.length) / this.length;

        // Angle 0: sunrise (East), PI/2: noon (zenith), PI: sunset (West), 3*PI/2: midnight
        const angle = t * Math.PI * 2;
        const sunY = Math.sin(angle);
        const sunX = Math.cos(angle);
        const daylight = MathKernel.clamp(sunY * 0.78 + 0.22, 0.08, 1.0);

        // Keep skybox dome and celestial bodies centered on player (infinite visual distance)
        this.skyDomeMesh.position.copy(playerPos);
        this.celestialGroup.position.copy(playerPos);

        // Rotate celestial sphere around Z axis (East to West solar arc)
        this.celestialGroup.rotation.x = angle - Math.PI / 2;

        // Update 3D Skybox gradient (throttled slightly for peak performance)
        this.lastSkyUpdate += dt;
        if (this.lastSkyUpdate >= 0.08) {
            this.lastSkyUpdate = 0;
            this.updateSkyGradient(sunY);
        }

        // 1. Dynamic Sun Directional Light
        if (sunY > -0.06) {
            sunLight.visible = true;
            sunLight.position.set(playerPos.x + sunX * 180, playerPos.y + Math.max(12, sunY * 180), playerPos.z + 40);
            sunLight.intensity = Math.max(0.1, sunY * 1.32);

            // Sunset/Sunrise golden-orange warmth
            const sunsetFactor = Math.max(0, 1 - Math.abs(sunY) * 3.5);
            if (sunsetFactor > 0) {
                sunLight.color.setRGB(
                    1.0,
                    0.65 + (1 - sunsetFactor) * 0.32,
                    0.35 + (1 - sunsetFactor) * 0.58
                );
            } else {
                sunLight.color.setRGB(1.0, 0.98, 0.94);
            }
        } else {
            sunLight.visible = false;
            sunLight.intensity = 0;
        }

        // 2. Dynamic Moon Directional Light (cool silver-blue nocturnal illumination)
        if (moonLight) {
            if (sunY < 0.06) {
                moonLight.visible = true;
                moonLight.position.set(playerPos.x - sunX * 180, playerPos.y + Math.max(12, -sunY * 180), playerPos.z - 40);
                moonLight.intensity = Math.max(0.06, -sunY * 0.32);
                moonLight.color.setRGB(0.68, 0.80, 1.0);
            } else {
                moonLight.visible = false;
                moonLight.intensity = 0;
            }
        }

        // 3. Ambient Lighting modulation: bright daylight -> dark midnight
        if (ambientLight) {
            const ambientIntensity = THREE.MathUtils.lerp(0.16, 0.65, daylight);
            ambientLight.intensity = ambientIntensity;
            if (daylight < 0.35) {
                // Nocturnal indigo ambient
                ambientLight.color.setRGB(0.55, 0.65, 0.95);
            } else if (sunY < 0.25) {
                // Warm twilight ambient
                ambientLight.color.setRGB(1.0, 0.82, 0.68);
            } else {
                // Natural daylight ambient
                ambientLight.color.setRGB(1.0, 1.0, 1.0);
            }
        }

        // 4. Hemisphere Light modulation (sky / ground bounce)
        if (hemisphereLight) {
            if (daylight > 0.45) {
                hemisphereLight.intensity = THREE.MathUtils.lerp(0.20, 0.38, daylight);
                hemisphereLight.color.setHex(0x78abff);
                hemisphereLight.groundColor.setHex(0x385522);
            } else if (daylight > 0.25) {
                hemisphereLight.intensity = 0.22;
                hemisphereLight.color.setHex(0xff7830);
                hemisphereLight.groundColor.setHex(0x301810);
            } else {
                hemisphereLight.intensity = 0.12;
                hemisphereLight.color.setHex(0x101a2e);
                hemisphereLight.groundColor.setHex(0x06080e);
            }
        }

        // 5. Cloud reaction to sun/moon lighting
        if (cloudGen) {
            if (daylight > 0.5) {
                cloudGen.setCloudColor(new THREE.Color(0xffffff));
            } else if (daylight > 0.25) {
                // Sunset coral cloud illumination
                cloudGen.setCloudColor(new THREE.Color(0xffaa82));
            } else {
                // Dark moonlit silver clouds
                cloudGen.setCloudColor(new THREE.Color(0x324262));
            }
        }

        // 6. Stars visibility (twinkle in night and dusk)
        const starVisibility = MathKernel.clamp((0.36 - daylight) * 3.2, 0, 1.0);
        this.starMaterial.opacity = starVisibility;

        // 7. Synchronize scene background & fog to horizon color for seamless distant clipping
        scene.background = this.currentHorizonColor;
        if (scene.fog) {
            scene.fog.color.copy(this.currentHorizonColor);
        }

        return daylight;
    }
}

export class TimeKernel {
    tickCount = 0;
    update() { this.tickCount++; }
}

export class AudioProcessor {
    ctx: AudioContext | null = null;
    masterVolume = 1;
    cachedNoise: AudioBuffer | null = null;

    touch() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
            if (AudioCtx) this.ctx = new AudioCtx();
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume().catch(() => {});
        }
    }

    private getNoiseBuffer(): AudioBuffer | null {
        if (!this.ctx) return null;
        if (this.cachedNoise) return this.cachedNoise;
        const len = Math.floor(this.ctx.sampleRate * 1.5);
        const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
        const data = buf.getChannelData(0);
        for (let i = 0; i < len; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        this.cachedNoise = buf;
        return buf;
    }

    playNoiseBurst(
        filterType: BiquadFilterType,
        freq: number,
        q: number,
        duration: number,
        gainVol: number,
        delay = 0
    ) {
        this.touch();
        if (!this.ctx) return;
        const buf = this.getNoiseBuffer();
        if (!buf) return;
        const t = this.ctx.currentTime + delay;
        const src = this.ctx.createBufferSource();
        src.buffer = buf;

        const filter = this.ctx.createBiquadFilter();
        filter.type = filterType;
        filter.frequency.setValueAtTime(Math.max(20, freq), t);
        filter.Q.setValueAtTime(q, t);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(gainVol * this.masterVolume, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);

        src.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        const offset = Math.random() * 0.5;
        src.start(t, offset);
        src.stop(t + duration + 0.02);
    }

    playTone(
        freqStart: number,
        freqEnd: number,
        dur = 0.1,
        type: OscillatorType = 'sine',
        vol = 0.08,
        delay = 0
    ) {
        this.touch();
        if (!this.ctx) return;
        const t = this.ctx.currentTime + delay;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(Math.max(20, freqStart), t);
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t + dur);

        gain.gain.setValueAtTime(vol * this.masterVolume, t);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t);
        osc.stop(t + dur + 0.02);
    }

    private getMaterial(blockId: number): 'stone' | 'dirt' | 'wood' | 'grass' | 'sand' | 'gravel' | 'glass' | 'foliage' | 'netherrack' {
        switch (blockId) {
            case BLOCK_ID.STONE:
            case BLOCK_ID.COBBLESTONE:
            case BLOCK_ID.MOSSY_COBBLESTONE:
            case BLOCK_ID.BEDROCK:
            case BLOCK_ID.BRICKS:
            case BLOCK_ID.COAL_ORE:
            case BLOCK_ID.IRON_ORE:
            case BLOCK_ID.GOLD_ORE:
            case BLOCK_ID.DIAMOND_ORE:
            case BLOCK_ID.REDSTONE_ORE:
            case BLOCK_ID.EMERALD_ORE:
            case BLOCK_ID.LAPIS_ORE:
            case BLOCK_ID.RUBY_ORE:
            case BLOCK_ID.OBSIDIAN:
                return 'stone';

            case BLOCK_ID.PLANKS:
            case BLOCK_ID.WOOD:
            case BLOCK_ID.LOG:
            case BLOCK_ID.CHEST:
                return 'wood';

            case BLOCK_ID.DIRT:
            case BLOCK_ID.CLAY:
            case BLOCK_ID.SOUL_SAND:
                return 'dirt';

            case BLOCK_ID.GRASS:
                return 'grass';

            case BLOCK_ID.SAND:
                return 'sand';

            case BLOCK_ID.GRAVEL:
                return 'gravel';

            case BLOCK_ID.GLASS:
                return 'glass';

            case BLOCK_ID.LEAVES:
            case BLOCK_ID.CHERRY_LEAVES:
            case BLOCK_ID.RED_LEAVES:
            case BLOCK_ID.TALL_GRASS:
            case BLOCK_ID.FLOWER_RED:
            case BLOCK_ID.FLOWER_YELLOW:
            case BLOCK_ID.CACTUS:
            case BLOCK_ID.BAMBOO:
            case BLOCK_ID.MUSHROOM_CAP:
                return 'foliage';

            case BLOCK_ID.NETHERRACK:
            case BLOCK_ID.NETHER_QUARTZ_ORE:
                return 'netherrack';

            default:
                return 'stone';
        }
    }

    playUiClick() {
        this.playTone(950, 480, 0.035, 'triangle', 0.12);
    }

    playSwing() {
        this.playNoiseBurst('bandpass', 650, 1.8, 0.08, 0.09);
        this.playTone(280, 140, 0.06, 'sine', 0.05);
    }

    playAttackHit() {
        this.playNoiseBurst('bandpass', 850, 1.6, 0.065, 0.14);
        this.playTone(180, 70, 0.09, 'triangle', 0.18);
    }

    playMineTick(blockId: number, prog = 0) {
        this.touch();
        if (!this.ctx) return;
        const mat = this.getMaterial(blockId);
        const pVar = (0.9 + Math.random() * 0.2) + prog * 0.12;

        if (mat === 'stone') {
            this.playNoiseBurst('bandpass', 1350 * pVar, 2.5, 0.03, 0.11);
            this.playTone(260 * pVar, 110, 0.035, 'triangle', 0.09);
        } else if (mat === 'wood') {
            this.playNoiseBurst('bandpass', 850 * pVar, 2.0, 0.032, 0.12);
            this.playTone(220 * pVar, 90, 0.04, 'triangle', 0.11);
        } else {
            this.playNoiseBurst('lowpass', 550 * pVar, 1.2, 0.035, 0.11);
            this.playTone(150 * pVar, 60, 0.035, 'sine', 0.10);
        }
    }

    playBlockBreak(blockId: number) {
        this.touch();
        if (!this.ctx) return;
        const mat = this.getMaterial(blockId);
        const pVar = 0.88 + Math.random() * 0.24;

        switch (mat) {
            case 'stone': {
                // Multi-grain rock crunch + punch
                for (let i = 0; i < 4; i++) {
                    const f = (1000 + Math.random() * 350) * pVar;
                    this.playNoiseBurst('bandpass', f, 1.8, 0.055, 0.14, i * 0.022);
                }
                this.playTone(140 * pVar, 40, 0.12, 'triangle', 0.16);
                break;
            }
            case 'wood': {
                // Snappy wooden snap & hollow thump
                for (let i = 0; i < 3; i++) {
                    const f = (680 + Math.random() * 220) * pVar;
                    this.playNoiseBurst('bandpass', f, 2.2, 0.065, 0.16, i * 0.025);
                }
                this.playTone(220 * pVar, 65, 0.11, 'triangle', 0.18);
                break;
            }
            case 'dirt':
            case 'grass': {
                // Earthy digging crunch
                for (let i = 0; i < 3; i++) {
                    const f = (420 + Math.random() * 180) * pVar;
                    this.playNoiseBurst('lowpass', f, 1.0, 0.06, 0.16, i * 0.02);
                }
                this.playTone(110 * pVar, 35, 0.10, 'sine', 0.18);
                break;
            }
            case 'sand':
            case 'gravel': {
                // Soft granular sand crunch
                for (let i = 0; i < 4; i++) {
                    const f = (780 + Math.random() * 260) * pVar;
                    this.playNoiseBurst('bandpass', f, 1.4, 0.065, 0.13, i * 0.018);
                }
                this.playTone(120 * pVar, 45, 0.08, 'sine', 0.11);
                break;
            }
            case 'glass': {
                // High crystalline glass shatter
                for (let i = 0; i < 4; i++) {
                    const f = (2600 + Math.random() * 1200) * pVar;
                    this.playNoiseBurst('highpass', f, 2.0, 0.09, 0.12, i * 0.015);
                }
                this.playTone(3200 * pVar, 1800, 0.08, 'sine', 0.10);
                this.playTone(4600 * pVar, 2400, 0.06, 'sine', 0.08, 0.02);
                break;
            }
            case 'foliage': {
                // Light leafy rustle / snap
                for (let i = 0; i < 3; i++) {
                    const f = (1500 + Math.random() * 500) * pVar;
                    this.playNoiseBurst('bandpass', f, 1.5, 0.045, 0.12, i * 0.016);
                }
                this.playTone(260 * pVar, 110, 0.05, 'triangle', 0.10);
                break;
            }
            case 'netherrack': {
                for (let i = 0; i < 4; i++) {
                    const f = (560 + Math.random() * 280) * pVar;
                    this.playNoiseBurst('bandpass', f, 1.2, 0.07, 0.15, i * 0.02);
                }
                this.playTone(120 * pVar, 40, 0.11, 'sine', 0.16);
                break;
            }
            default: {
                this.playNoiseBurst('bandpass', 900 * pVar, 1.5, 0.07, 0.13);
                this.playTone(130 * pVar, 50, 0.1, 'triangle', 0.12);
                break;
            }
        }
    }

    playToolBreak() {
        this.touch();
        if (!this.ctx) return;
        // Authentic Minecraft tool shatter: high-frequency metallic/wooden snap + snappy noise burst
        for (let i = 0; i < 3; i++) {
            const f = 1200 + Math.random() * 400;
            this.playNoiseBurst('bandpass', f, 2.2, 0.08, 0.22, i * 0.02);
        }
        this.playTone(360, 80, 0.16, 'triangle', 0.28);
        this.playTone(560, 140, 0.11, 'sawtooth', 0.22, 0.015);
    }

    playPlace(blockId: number) {
        this.touch();
        if (!this.ctx) return;
        const mat = this.getMaterial(blockId);
        const pVar = 0.92 + Math.random() * 0.16;

        switch (mat) {
            case 'stone': {
                this.playNoiseBurst('highpass', 1250 * pVar, 1.6, 0.035, 0.15);
                this.playTone(190 * pVar, 75, 0.06, 'triangle', 0.18);
                break;
            }
            case 'wood': {
                this.playNoiseBurst('bandpass', 720 * pVar, 2.0, 0.045, 0.14);
                this.playTone(250 * pVar, 110, 0.07, 'triangle', 0.20);
                break;
            }
            case 'dirt':
            case 'grass': {
                this.playNoiseBurst('lowpass', 520 * pVar, 1.0, 0.05, 0.15);
                this.playTone(140 * pVar, 55, 0.07, 'sine', 0.18);
                break;
            }
            case 'sand':
            case 'gravel': {
                this.playNoiseBurst('bandpass', 850 * pVar, 1.4, 0.055, 0.13);
                this.playTone(120 * pVar, 50, 0.06, 'sine', 0.13);
                break;
            }
            case 'glass': {
                this.playNoiseBurst('highpass', 2400 * pVar, 2.2, 0.04, 0.11);
                this.playTone(2200 * pVar, 1600, 0.05, 'sine', 0.09);
                break;
            }
            case 'foliage': {
                this.playNoiseBurst('bandpass', 1500 * pVar, 1.5, 0.04, 0.12);
                this.playTone(220 * pVar, 90, 0.05, 'triangle', 0.10);
                break;
            }
            default: {
                this.playNoiseBurst('bandpass', 1000 * pVar, 1.5, 0.04, 0.14);
                this.playTone(170 * pVar, 70, 0.06, 'triangle', 0.16);
                break;
            }
        }
    }

    playStep(blockId: number, sprinting = false, crouching = false) {
        if (crouching) return;
        this.touch();
        if (!this.ctx) return;
        const mat = this.getMaterial(blockId);
        const vol = sprinting ? 0.15 : 0.10;
        const pVar = 0.9 + Math.random() * 0.2;

        if (mat === 'grass' || mat === 'foliage') {
            this.playNoiseBurst('bandpass', 1200 * pVar, 1.4, 0.04, vol);
            this.playTone(110 * pVar, 40, 0.04, 'sine', vol * 0.8);
        } else if (mat === 'sand' || mat === 'gravel') {
            this.playNoiseBurst('bandpass', 800 * pVar, 1.2, 0.045, vol);
            this.playTone(95 * pVar, 35, 0.04, 'sine', vol * 0.8);
        } else if (mat === 'wood') {
            this.playNoiseBurst('bandpass', 620 * pVar, 2.0, 0.035, vol);
            this.playTone(180 * pVar, 80, 0.04, 'triangle', vol * 1.1);
        } else {
            this.playNoiseBurst('highpass', 1150 * pVar, 1.8, 0.035, vol);
            this.playTone(145 * pVar, 60, 0.04, 'triangle', vol);
        }
    }

    playJump() {
        this.playTone(260, 440, 0.07, 'triangle', 0.11);
    }

    playLand(drop = 0, softened = false) {
        const vol = softened ? 0.08 : 0.16;
        this.playNoiseBurst('lowpass', 600, 1.2, 0.09, vol);
        this.playTone(160, 50, 0.09, 'triangle', vol);
    }

    playDamage(amount = 1) {
        this.touch();
        if (!this.ctx) return;
        this.playNoiseBurst('lowpass', 700, 1.2, 0.06, 0.16);
        this.playTone(175, 75, 0.14, 'triangle', 0.22);
    }

    playDeath() {
        this.playTone(260, 40, 0.40, 'triangle', 0.25);
        this.playNoiseBurst('lowpass', 450, 1.0, 0.35, 0.20);
    }

    playRespawn() {
        this.playTone(220, 640, 0.22, 'sine', 0.15);
    }

    playEat() {
        this.touch();
        if (!this.ctx) return;
        for (let i = 0; i < 3; i++) {
            const f = 1100 + Math.random() * 400;
            this.playNoiseBurst('bandpass', f, 2.0, 0.035, 0.13, i * 0.032);
        }
        this.playTone(220, 110, 0.06, 'triangle', 0.11);
    }

    playCraft() {
        this.playTone(450, 800, 0.09, 'sine', 0.14);
    }

    playPickup() {
        this.playTone(650, 1300, 0.05, 'sine', 0.14);
    }

    playPop() {
        this.playTone(550, 1100, 0.045, 'sine', 0.13);
    }

    playThrow() {
        this.playTone(360, 180, 0.06, 'triangle', 0.10);
    }

    playWindChargeLaunch() {
        this.playNoiseBurst('bandpass', 1200, 1.5, 0.18, 0.18);
        this.playTone(520, 860, 0.16, 'sine', 0.16);
    }

    playWindBurst() {
        this.playTone(320, 75, 0.24, 'triangle', 0.25);
        this.playNoiseBurst('bandpass', 800, 1.0, 0.22, 0.22);
        setTimeout(() => this.playTone(680, 240, 0.18, 'sine', 0.14), 25);
    }

    playChestOpen() {
        this.playTone(180, 310, 0.14, 'triangle', 0.14);
    }

    playMobHurt(kind: string, type: string) {
        this.touch();
        if (!this.ctx) return;
        this.playNoiseBurst('bandpass', 800, 1.5, 0.06, 0.13);
        this.playTone(165, 60, 0.08, 'triangle', 0.16);

        if (type === 'zombie') {
            this.playTone(110, 70, 0.24, 'sawtooth', 0.16, 0.02);
        } else if (type === 'skeleton') {
            this.playTone(720, 500, 0.04, 'square', 0.09, 0.02);
            this.playTone(850, 600, 0.04, 'square', 0.09, 0.06);
        } else if (type === 'cow') {
            this.playTone(135, 95, 0.32, 'triangle', 0.16, 0.02);
        } else if (type === 'pig') {
            this.playTone(340, 210, 0.14, 'sawtooth', 0.15, 0.02);
        } else if (type === 'sheep') {
            this.playTone(240, 180, 0.25, 'sawtooth', 0.13, 0.02);
        } else if (type === 'chicken') {
            this.playTone(460, 320, 0.08, 'sine', 0.13, 0.02);
        } else if (type === 'villager') {
            this.playVillagerHmm();
        }
    }

    playMobDeath(kind: string, type: string) {
        this.touch();
        if (!this.ctx) return;
        this.playTone(140, 40, 0.26, 'triangle', 0.20);
        this.playNoiseBurst('lowpass', 500, 1.0, 0.20, 0.14);
        if (type === 'zombie') {
            this.playTone(95, 45, 0.38, 'sawtooth', 0.18, 0.03);
        } else if (type === 'skeleton') {
            this.playTone(600, 300, 0.08, 'square', 0.11, 0.02);
            this.playTone(800, 400, 0.08, 'square', 0.11, 0.08);
            this.playTone(500, 250, 0.08, 'square', 0.11, 0.14);
        }
    }

    playVillagerHmm() {
        this.touch();
        if (!this.ctx) return;
        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        osc.type = 'sawtooth';

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(420, now);
        filter.frequency.exponentialRampToValueAtTime(360, now + 0.28);
        filter.Q.setValueAtTime(3.8, now);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.14 * this.masterVolume, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.32);

        osc.frequency.setValueAtTime(160, now);
        osc.frequency.linearRampToValueAtTime(132, now + 0.18);
        osc.frequency.linearRampToValueAtTime(144, now + 0.30);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 0.34);
    }

    playVillagerTrade() {
        this.touch();
        if (!this.ctx) return;
        this.playTone(587.33, 587.33, 0.09, 'sine', 0.14, 0);
        this.playTone(880.00, 880.00, 0.16, 'sine', 0.16, 0.09);
    }

    playCreeperHiss() {
        this.touch();
        if (!this.ctx) return;
        const buf = this.getNoiseBuffer();
        if (!buf) return;
        const now = this.ctx.currentTime;
        const src = this.ctx.createBufferSource();
        src.buffer = buf;
        src.loop = true;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(2600, now);
        filter.frequency.linearRampToValueAtTime(3400, now + 1.4);
        filter.Q.setValueAtTime(2.5, now);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.02 * this.masterVolume, now);
        gain.gain.exponentialRampToValueAtTime(0.20 * this.masterVolume, now + 1.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.5);

        src.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        src.start(now);
        src.stop(now + 1.52);
    }

    playCreeperExplode() {
        this.touch();
        if (!this.ctx) return;
        this.playTone(160, 25, 0.45, 'triangle', 0.38);
        this.playNoiseBurst('lowpass', 1200, 0.8, 0.65, 0.34);
        this.playNoiseBurst('bandpass', 450, 1.2, 0.75, 0.30, 0.04);
    }

    playSkeletonShoot() {
        this.touch();
        if (!this.ctx) return;
        this.playTone(480, 180, 0.08, 'sawtooth', 0.12);
        this.playNoiseBurst('bandpass', 1800, 2.0, 0.06, 0.09);
    }

    playEndermanTeleport() {
        this.touch();
        if (!this.ctx) return;
        this.playTone(160, 480, 0.18, 'sawtooth', 0.14);
        this.playTone(380, 120, 0.22, 'sine', 0.14, 0.05);
    }

    playChatMessage() {
        this.playTone(600, 720, 0.045, 'sine', 0.08);
    }

    setMasterVolume(vol: number) {
        this.masterVolume = MathKernel.clamp(vol / 100, 0, 1);
    }

    setEnvironment(env: any) {}
    update(dt: number) {}
}

export class SaveStateSystem {
    static serialize(world: any) { return '{}'; }
    static deserialize(json: string, world: any) {}
}

export class MinecraftLogicKernel {
    world: VoxelWorld;
    constructor(world: VoxelWorld) { this.world = world; }
    update(dt: number, pos: THREE.Vector3, dim: string) {}
}

export class VoxelCommandEngine {
    app: any;
    constructor(app: any) { this.app = app; }
    execute(cmd: string) {
        if (cmd === 'gamemode creative') {
            this.app.survival.setGameMode('Creative');
            this.app.inventory.setCreativeMode(true);
            this.app.pushChatLine('System', 'Game mode set to Creative', 'system');
        } else if (cmd === 'gamemode survival') {
            this.app.survival.setGameMode('Survival');
            this.app.inventory.setCreativeMode(false);
            this.app.pushChatLine('System', 'Game mode set to Survival', 'system');
        } else {
            this.app.pushChatLine('System', `Executed command /${cmd}`, 'system');
        }
    }
}
