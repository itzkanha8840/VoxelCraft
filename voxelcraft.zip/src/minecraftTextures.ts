import * as THREE from 'three';
import { BLOCK_ID } from './constants';

/* ==============================================================
   AUTHENTIC VANILLA MINECRAFT TEXTURE ENGINE
   Pixel-accurate color palettes and authentic 16x16 pixel-art
   textures for every block in the game.
   - Handcrafted 16x16 pixel matrices with ZERO repeating stripe loops
   - Crisp NearestFilter magnification for iconic Minecraft texels
   - NearestMipmapLinearFilter for crystal-clear distant rendering
   ============================================================== */

export type TextureMap = string[];

// Draw a 16x16 pixel map using a color palette
export function drawPixelMap(
    ctx: CanvasRenderingContext2D,
    palette: Record<string, string>,
    map: TextureMap,
    width = 16,
    height = 16
) {
    for (let y = 0; y < height; y++) {
        const row = map[y];
        if (!row) continue;
        for (let x = 0; x < width; x++) {
            const ch = row[x];
            if (!ch || ch === '.' || ch === ' ') continue;
            const color = palette[ch];
            if (color) {
                ctx.fillStyle = color;
                ctx.fillRect(x, y, 1, 1);
            }
        }
    }
}

/* --------------------------------------------------------------
   1. STONE (Classic neutral gray rock with authentic natural grain)
   -------------------------------------------------------------- */
export const STONE_PALETTE: Record<string, string> = {
    '0': '#525252', // Darkest crevice
    '1': '#5e5e5e', // Dark stone facet
    '2': '#696969', // Shadowed rock
    '3': '#747474', // Mid-dark stone
    '4': '#7f7f7f', // Base stone body
    '5': '#8b8b8b', // Light stone facet
    '6': '#969696', // Pale mineral fleck
    '7': '#a2a2a2', // Quartz highlight
};

export const STONE_MAP: TextureMap = [
    "4445344445344454",
    "4324543244543245",
    "5434454345434344",
    "3544345434454534",
    "4453444534445443",
    "4345432445434544",
    "5444543444543454",
    "3543454435434445",
    "4454344544453454",
    "4345432454345434",
    "5444543445444544",
    "3454354434543453",
    "4445344544453444",
    "5344543453445434",
    "4543454445434545",
    "3454344534543444"
];

const STONE_NATURAL_FLECKS: Array<[number, number, string]> = [
    [2, 1, '1'], [7, 3, '6'], [11, 0, '2'], [14, 2, '7'],
    [0, 5, '0'], [5, 6, '6'], [9, 8, '1'], [13, 7, '7'],
    [3, 10, '7'], [8, 11, '0'], [12, 12, '6'], [15, 13, '1'],
    [1, 14, '6'], [6, 13, '2'], [10, 15, '7'], [14, 14, '0']
];

export function renderVanillaStone(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, STONE_PALETTE, STONE_MAP);
    for (const [x, y, col] of STONE_NATURAL_FLECKS) {
        ctx.fillStyle = STONE_PALETTE[col];
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   2. COBBLESTONE (Iconic vanilla Minecraft irregular stone blocks & dark mortar)
   -------------------------------------------------------------- */
export const COBBLESTONE_PALETTE: Record<string, string> = {
    '0': '#343434', // Deepest mortar crevice
    '1': '#434343', // Dark mortar seam
    '2': '#525252', // Mortar edge shadow
    '3': '#606060', // Shadowed stone facet
    '4': '#6e6e6e', // Mid-dark stone
    '5': '#7c7c7c', // Base stone body
    '6': '#8b8b8b', // Light stone facet
    '7': '#9b9b9b', // Stone highlight
    '8': '#aaaaaa', // Bright stone reflection
};

export const COBBLESTONE_MAP: TextureMap = [
    "5676510156765410",
    "6787541167875311",
    "5776431057654210",
    "4554320145432101",
    "1101111110111111",
    "0156765410145675",
    "1678765311567874",
    "1577654210577653",
    "0456543101456542",
    "1110111111101111",
    "5676541015676541",
    "6787531167876530",
    "5776421057765421",
    "4554310145543211",
    "1011111111011110",
    "0145654210156764"
];

/* --------------------------------------------------------------
   3. MOSSY COBBLESTONE (Cobblestone with vibrant creeping moss)
   -------------------------------------------------------------- */
export const MOSS_PALETTE: Record<string, string> = {
    'm0': '#294310', // Deep moss shadow
    'm1': '#3b6118', // Dark moss
    'm2': '#4e7f21', // Rich green moss body
    'm3': '#659c2d', // Vibrant moss leaf
    'm4': '#7dbb3a', // Bright moss tip
};

export function renderMossyCobblestone(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, COBBLESTONE_PALETTE, COBBLESTONE_MAP);
    const mossPatches: Array<[number, number, string]> = [
        [1, 1, 'm2'], [2, 1, 'm3'], [3, 1, 'm4'], [4, 1, 'm3'], [2, 0, 'm2'], [3, 0, 'm3'],
        [2, 2, 'm4'], [3, 2, 'm3'], [4, 2, 'm2'], [1, 2, 'm1'], [3, 3, 'm0'],
        [7, 4, 'm1'], [8, 4, 'm2'], [9, 4, 'm3'], [8, 5, 'm4'], [9, 5, 'm3'], [10, 5, 'm2'],
        [7, 5, 'm2'], [8, 6, 'm1'], [9, 6, 'm0'],
        [12, 1, 'm2'], [13, 1, 'm3'], [14, 1, 'm4'], [13, 0, 'm3'], [14, 0, 'm2'],
        [0, 8, 'm1'], [1, 8, 'm2'], [2, 8, 'm3'], [1, 9, 'm4'], [2, 9, 'm3'], [3, 9, 'm2'],
        [6, 11, 'm2'], [7, 11, 'm3'], [8, 11, 'm4'], [9, 11, 'm3'], [7, 12, 'm4'], [8, 12, 'm3'],
        [12, 13, 'm2'], [13, 13, 'm3'], [14, 13, 'm4'], [13, 14, 'm3'], [14, 14, 'm2']
    ];
    for (const [x, y, col] of mossPatches) {
        ctx.fillStyle = MOSS_PALETTE[col];
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   4. DIRT (Warm rich crumbly loam with natural pebbles - NO loops)
   -------------------------------------------------------------- */
export const DIRT_PALETTE: Record<string, string> = {
    '0': '#4a331f', // Deep dark pebble
    '1': '#553b24', // Dark loam crevice
    '2': '#61442a', // Shadowed soil
    '3': '#6e4d30', // Mid-dark dirt
    '4': '#7b5736', // Base vanilla dirt body
    '5': '#88613d', // Warm soil facet
    '6': '#966c44', // Light dirt grain
    '7': '#a3764b', // Pale loam speckle
};

export const DIRT_MAP: TextureMap = [
    "4354432454345443",
    "3542145435424534",
    "4454354344543454",
    "5345442564354435",
    "4534534453445344",
    "3452454345244543",
    "4345435434543454",
    "5424544245454245",
    "4543453454344534",
    "3454245435424543",
    "4345434543543454",
    "5434543454435435",
    "4542454435424544",
    "3454345244543453",
    "4345443543454345",
    "5434534454345424"
];

const DIRT_PEBBLE_INCLUSIONS: Array<[number, number, string]> = [
    [1, 1, '1'], [2, 1, '0'], [2, 2, '1'], [7, 3, '7'], [8, 3, '6'],
    [13, 0, '1'], [14, 1, '0'], [11, 4, '2'], [4, 5, '7'], [5, 5, '6'],
    [0, 8, '1'], [1, 9, '0'], [8, 8, '1'], [9, 9, '0'], [14, 7, '7'],
    [3, 12, '7'], [6, 14, '1'], [7, 14, '0'], [12, 11, '1'], [13, 12, '0'],
    [10, 14, '7'], [15, 15, '1']
];

export function renderVanillaDirt(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, DIRT_PALETTE, DIRT_MAP);
    for (const [x, y, col] of DIRT_PEBBLE_INCLUSIONS) {
        ctx.fillStyle = DIRT_PALETTE[col];
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   5. GRASS TOP (Lush Plains green lawn with authentic blade texture)
   -------------------------------------------------------------- */
export const GRASS_TOP_PALETTE: Record<string, string> = {
    '0': '#44731f', // Deep root shadow
    '1': '#508525', // Dark blade
    '2': '#5d972c', // Shadowed grass
    '3': '#6aa933', // Mid green blade
    '4': '#77bc3a', // Base vibrant plains grass
    '5': '#85cd42', // Bright green blade
    '6': '#92dd4a', // Sunny blade tip
    '7': '#a0ec53', // Sunlit grass highlight
};

export const GRASS_TOP_MAP: TextureMap = [
    "4543543445435443",
    "5432454324543544",
    "4354345434543454",
    "3543245432454354",
    "4544543454345434",
    "5324543245432454",
    "4454345434543445",
    "3543245432454354",
    "4543454345434543",
    "5324543245432454",
    "4354345434543454",
    "3543245432454354",
    "4544543454345434",
    "5324543245432454",
    "4454345434543445",
    "3543245432454354"
];

const GRASS_BLADE_OVERLAYS: Array<[number, number, string]> = [
    [2, 2, '6'], [3, 2, '7'], [8, 1, '1'], [9, 1, '0'],
    [13, 3, '6'], [14, 3, '7'], [5, 6, '1'], [6, 6, '0'],
    [11, 7, '6'], [12, 7, '7'], [1, 9, '1'], [2, 9, '0'],
    [7, 10, '6'], [8, 10, '7'], [14, 11, '1'], [15, 11, '0'],
    [4, 13, '6'], [5, 13, '7'], [10, 14, '1'], [11, 14, '0']
];

export function renderGrassTop(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, GRASS_TOP_PALETTE, GRASS_TOP_MAP);
    for (const [x, y, col] of GRASS_BLADE_OVERLAYS) {
        ctx.fillStyle = GRASS_TOP_PALETTE[col];
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   6. GRASS SIDE (Iconic dripping overhang with root shadows over dirt)
   -------------------------------------------------------------- */
export function renderGrassSide(ctx: CanvasRenderingContext2D) {
    // 1. Draw base dirt first
    renderVanillaDirt(ctx);

    // 2. Hanging grass overhang depths per column [0..15]
    const depths = [3, 3, 4, 5, 3, 2, 4, 4, 3, 2, 4, 5, 3, 2, 3, 4];

    const grassColTop = '#92dd4a';
    const grassColMid = '#77bc3a';
    const grassColTip = '#5d972c';
    const grassColShd = '#3a2517';

    for (let x = 0; x < 16; x++) {
        const d = depths[x];
        for (let y = 0; y < d; y++) {
            let col = grassColMid;
            if (y === 0) col = grassColTop;
            else if (y === d - 1) col = grassColTip;
            ctx.fillStyle = col;
            ctx.fillRect(x, y, 1, 1);
        }
        // Shadow pixel right beneath the grass drip
        if (d < 16) {
            ctx.fillStyle = grassColShd;
            ctx.fillRect(x, d, 1, 1);
        }
    }
}

/* --------------------------------------------------------------
   7. OAK PLANKS (4 horizontal boards with grain & nail heads)
   -------------------------------------------------------------- */
export const PLANKS_PALETTE: Record<string, string> = {
    '0': '#483116', // Nail head & deep groove seam
    '1': '#5b3e1d', // Board joint shadow
    '2': '#724f26', // Dark wood seam
    '3': '#8a6233', // Dark grain
    '4': '#9c713c', // Base oak body
    '5': '#ab7e45', // Warm oak tone
    '6': '#ba8c4f', // Light wood grain
    '7': '#c89a59', // Board top highlight
};

export const PLANKS_MAP: TextureMap = [
    // Board 1 (y: 0-3): Seam at x=11, nail at (10, 1)
    "7777777777717777",
    "6554565554015655",
    "5443454443114544",
    "2222222222222222",
    // Board 2 (y: 4-7): Seam at x=4, nail at (5, 5)
    "7777177777777777",
    "5543105655545655",
    "4432114544434544",
    "2222222222222222",
    // Board 3 (y: 8-11): Seam at x=13, nail at (12, 9)
    "7777777777777177",
    "6554565554550156",
    "5443454443441145",
    "2222222222222222",
    // Board 4 (y: 12-15): Seam at x=6, nail at (7, 13)
    "7777771777777777",
    "5554541056555456",
    "4443431145444345",
    "2222222222222222"
];

/* --------------------------------------------------------------
   8. OAK LOG (Bark side with natural vertical furrows & growth rings top)
   -------------------------------------------------------------- */
export const LOG_SIDE_PALETTE: Record<string, string> = {
    '0': '#382312', // Deep bark crevice
    '1': '#462d18', // Dark bark groove
    '2': '#56381e', // Shadowed bark
    '3': '#654324', // Mid bark
    '4': '#724c2a', // Base oak bark
    '5': '#805630', // Light bark ridge
    '6': '#8e6037', // Bark ridge highlight
};

export const LOG_SIDE_MAP: TextureMap = [
    "3454101456541014",
    "4565212565431025",
    "3454101454320134",
    "2343012345431245",
    "4554101456541024",
    "5665212565431135",
    "4554101454320134",
    "3443012345431245",
    "3454101456541014",
    "4565212565431025",
    "3454101454320134",
    "2343012345431245",
    "4554101456541024",
    "5665212565431135",
    "4554101454320134",
    "3443012345431245"
];

export const LOG_TOP_PALETTE: Record<string, string> = {
    'b0': '#382312', // Outer bark shadow
    'b1': '#56381e', // Outer bark body
    'b2': '#724c2a', // Outer bark highlight
    'r0': '#725026', // Heartwood / dark ring
    'r1': '#896232', // Mid growth ring
    'r2': '#9e733d', // Base wood cross-section
    'r3': '#b08347', // Pale sapwood ring
    'r4': '#c09252', // Light wood highlight
};

export const LOG_TOP_MAP: TextureMap = [
    "b1b2b1b0b1b2b1b0b1b2b1b0b1b2b1b0",
    "b2r3r3r3r3r3r3r3r3r3r3r3r3r3r3b1",
    "b1r3r1r1r1r1r1r1r1r1r1r1r1r1r3b2",
    "b0r3r1r2r2r2r2r2r2r2r2r2r2r1r3b1",
    "b1r3r1r2r0r0r0r0r0r0r0r2r2r1r3b0",
    "b2r3r1r2r0r2r2r2r2r2r0r2r2r1r3b1",
    "b1r3r1r2r0r2r0r0r0r2r0r2r2r1r3b2",
    "b0r3r1r2r0r2r0r4r0r2r0r2r2r1r3b1",
    "b1r3r1r2r0r2r0r0r0r2r0r2r2r1r3b0",
    "b2r3r1r2r0r2r2r2r2r2r0r2r2r1r3b1",
    "b1r3r1r2r0r0r0r0r0r0r0r2r2r1r3b2",
    "b0r3r1r2r2r2r2r2r2r2r2r2r2r1r3b1",
    "b1r3r1r1r1r1r1r1r1r1r1r1r1r1r3b0",
    "b2r3r3r3r3r3r3r3r3r3r3r3r3r3r3b1",
    "b1b2b1b0b1b2b1b0b1b2b1b0b1b2b1b2",
    "b0b1b0b1b0b1b0b1b0b1b0b1b0b1b0b1"
];

export function renderLogTop(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, LOG_TOP_PALETTE, LOG_TOP_MAP);
}

/* --------------------------------------------------------------
   9. OAK LEAVES (Botanical foliage with natural translucent cutouts)
   -------------------------------------------------------------- */
export const LEAVES_PALETTE: Record<string, string> = {
    '0': '#1b3f11', // Deep interior leaf shadow
    '1': '#265417', // Dark shaded leaf
    '2': '#346d20', // Mid leaf body
    '3': '#43872a', // Vibrant green foliage
    '4': '#53a135', // Sunlit leaf blade
    '5': '#65bc42', // Leaf tip highlight
};

export const LEAVES_MAP: TextureMap = [
    "342.1342.342.134",
    "4531245314531245",
    "2310.231.2310.23",
    ".1.01.1.01.1.01.",
    "1342.342.1342.34",
    "2453145312453145",
    ".231.2310.231.23",
    "0.1.01.1.01.1.01",
    "342.1342.342.134",
    "4531245314531245",
    "2310.231.2310.23",
    ".1.01.1.01.1.01.",
    "1342.342.1342.34",
    "2453145312453145",
    ".231.2310.231.23",
    "0.1.01.1.01.1.01"
];

/* --------------------------------------------------------------
   10. CHERRY & RED LEAVES
   -------------------------------------------------------------- */
export const CHERRY_PALETTE: Record<string, string> = {
    '0': '#7a2244',
    '1': '#9f325d',
    '2': '#c74c7c',
    '3': '#e66b9a',
    '4': '#f48cb5',
    '5': '#ffb0cf',
};

export function renderCherryLeaves(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, CHERRY_PALETTE, LEAVES_MAP);
}

export const RED_LEAVES_PALETTE: Record<string, string> = {
    '0': '#4e1414',
    '1': '#6f1e1e',
    '2': '#942b2b',
    '3': '#bd3b3b',
    '4': '#dc5252',
    '5': '#f07474',
};

export function renderRedLeaves(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, RED_LEAVES_PALETTE, LEAVES_MAP);
}

/* --------------------------------------------------------------
   11. SAND (Warm golden desert quartz granules - NO striped repeats)
   -------------------------------------------------------------- */
export const SAND_PALETTE: Record<string, string> = {
    '0': '#bbaa74', // Shadow grain
    '1': '#c9b982', // Mid-dark sand
    '2': '#d5c690', // Base desert sand body
    '3': '#ded09d', // Warm sand facet
    '4': '#e8dbaa', // Pale quartz granule
    '5': '#f2e5b7', // Sunny highlight grain
};

export const SAND_MAP: TextureMap = [
    "2324323212342321",
    "3432431234213432",
    "2312323423123212",
    "1234212343212101",
    "2321343212342321",
    "3412432134213432",
    "2343234223123212",
    "1210123432121012",
    "2321234212342321",
    "3432342134213432",
    "2312234223123212",
    "1234123432121012",
    "2321343212342321",
    "3421432134213432",
    "2343234223123212",
    "1210123432121012"
];

export function renderVanillaSand(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, SAND_PALETTE, SAND_MAP);
}

/* --------------------------------------------------------------
   12. GRAVEL (Packed riverbed pebbles: slate, flint, granite)
   -------------------------------------------------------------- */
export const GRAVEL_PALETTE: Record<string, string> = {
    '0': '#484442', // Deep crevice
    '1': '#575250', // Slate pebble shadow
    '2': '#66615e', // Dark stone pebble
    '3': '#75706c', // Mid gravel body
    '4': '#847e7a', // Light pebble facet
    '5': '#938d88', // Pale pebble highlight
    '6': '#a29c96', // Quartz pebble grain
};

export const GRAVEL_MAP: TextureMap = [
    "3454210134542101",
    "4565321245653212",
    "3454210134542101",
    "2343101223431012",
    "1232012312320123",
    "0121123401211234",
    "1232234512322345",
    "2343345623433456",
    "3454210134542101",
    "4565321245653212",
    "3454210134542101",
    "2343101223431012",
    "1232012312320123",
    "0121123401211234",
    "1232234512322345",
    "2343345623433456"
];

/* --------------------------------------------------------------
   13. GLASS (Crystal clear pane, perimeter border, diagonal glints)
   -------------------------------------------------------------- */
export function renderGlass(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, 16, 16);

    // Subtle glass tint
    ctx.fillStyle = 'rgba(215, 240, 255, 0.12)';
    ctx.fillRect(0, 0, 16, 16);

    // Clean beveled border
    ctx.fillStyle = 'rgba(230, 248, 255, 0.75)';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
    ctx.fillRect(15, 0, 1, 16);

    // Diagonal specular glare glints (classic Minecraft glass reflection)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    const glints: Array<[number, number]> = [
        [2, 2], [3, 3], [4, 4],
        [11, 2], [12, 3], [13, 4],
        [2, 11], [3, 12], [4, 13],
        [11, 11], [12, 12], [13, 13]
    ];
    for (const [x, y] of glints) {
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   14. BEDROCK (Chaotic high-contrast impervious volcanic rock)
   -------------------------------------------------------------- */
export const BEDROCK_PALETTE: Record<string, string> = {
    '0': '#101010',
    '1': '#1d1d1d',
    '2': '#2b2b2b',
    '3': '#3b3b3b',
    '4': '#4e4e4e',
    '5': '#666666',
};

export const BEDROCK_MAP: TextureMap = [
    "1012321045210123",
    "0124532123435101",
    "1235443234543210",
    "2343210123432104",
    "1232105212321012",
    "0121012301210523",
    "1242123412321234",
    "2343234523432345",
    "1012321012324012",
    "0123432123432101",
    "1234543234543210",
    "2343210123432101",
    "1232101212321012",
    "0121012301210123",
    "1232123412321234",
    "2343234523432345"
];

/* --------------------------------------------------------------
   15. ORES (Coal, Iron, Gold, Diamond, Redstone, Emerald, Lapis, Ruby)
   -------------------------------------------------------------- */
export interface OreColorDef {
    deep: string;
    dark: string;
    mid: string;
    bright: string;
    glint: string;
}

export const ORE_PALETTES: Record<number, OreColorDef> = {
    [BLOCK_ID.COAL_ORE]: {
        deep: '#141414', dark: '#222222', mid: '#333333', bright: '#454545', glint: '#585858'
    },
    [BLOCK_ID.IRON_ORE]: {
        deep: '#8f6850', dark: '#ad8165', mid: '#c79b7d', bright: '#dfb496', glint: '#f5ceb3'
    },
    [BLOCK_ID.GOLD_ORE]: {
        deep: '#aa7e18', dark: '#cca025', mid: '#ecc236', bright: '#ffe14f', glint: '#fff480'
    },
    [BLOCK_ID.DIAMOND_ORE]: {
        deep: '#18928c', dark: '#23b5ad', mid: '#37d9d0', bright: '#5df6ed', glint: '#b0fffa'
    },
    [BLOCK_ID.REDSTONE_ORE]: {
        deep: '#7f0a0a', dark: '#a51212', mid: '#cf1f1f', bright: '#f53b3b', glint: '#ff7575'
    },
    [BLOCK_ID.EMERALD_ORE]: {
        deep: '#0f752e', dark: '#15963c', mid: '#20bd4e', bright: '#3ee370', glint: '#8affac'
    },
    [BLOCK_ID.LAPIS_ORE]: {
        deep: '#14316d', dark: '#1c4494', mid: '#285ec4', bright: '#3e7cf0', glint: '#e8c440'
    },
    [BLOCK_ID.RUBY_ORE]: {
        deep: '#780e32', dark: '#a11847', mid: '#cb2660', bright: '#f13e7d', glint: '#ffa3c5'
    },
};

const ORE_CLUSTER_LOCATIONS: Array<{ x: number; y: number; shape: Array<[number, number, 'deep' | 'dark' | 'mid' | 'bright' | 'glint']> }> = [
    {
        x: 3, y: 3,
        shape: [
            [0, 0, 'bright'], [1, 0, 'glint'], [0, 1, 'mid'], [1, 1, 'deep']
        ]
    },
    {
        x: 10, y: 2,
        shape: [
            [0, 0, 'dark'], [1, 0, 'mid'], [2, 0, 'bright'],
            [0, 1, 'deep'], [1, 1, 'glint'], [2, 1, 'mid']
        ]
    },
    {
        x: 6, y: 7,
        shape: [
            [0, 0, 'mid'], [1, 0, 'bright'], [2, 0, 'glint'],
            [0, 1, 'deep'], [1, 1, 'mid'], [2, 1, 'dark'],
            [1, 2, 'deep']
        ]
    },
    {
        x: 2, y: 11,
        shape: [
            [0, 0, 'dark'], [1, 0, 'mid'], [2, 0, 'bright'],
            [1, 1, 'glint'], [2, 1, 'deep']
        ]
    },
    {
        x: 11, y: 10,
        shape: [
            [0, 0, 'bright'], [1, 0, 'glint'],
            [0, 1, 'mid'], [1, 1, 'deep']
        ]
    },
    {
        x: 7, y: 13,
        shape: [
            [0, 0, 'dark'], [1, 0, 'mid'], [2, 0, 'bright'],
            [0, 1, 'deep'], [1, 1, 'glint']
        ]
    }
];

export function renderOre(ctx: CanvasRenderingContext2D, oreBlockId: number) {
    // 1. Draw base stone matrix
    renderVanillaStone(ctx);

    const colors = ORE_PALETTES[oreBlockId] || ORE_PALETTES[BLOCK_ID.COAL_ORE];

    // 2. Draw authentic gem inclusions
    for (const cluster of ORE_CLUSTER_LOCATIONS) {
        for (const [dx, dy, tone] of cluster.shape) {
            const px = cluster.x + dx;
            const py = cluster.y + dy;
            if (px >= 0 && px < 16 && py >= 0 && py < 16) {
                ctx.fillStyle = colors[tone];
                ctx.fillRect(px, py, 1, 1);
            }
        }
    }
}

/* --------------------------------------------------------------
   16. BRICKS (Kiln-fired clay running-bond bricks with mortar joints)
   -------------------------------------------------------------- */
export const BRICKS_PALETTE: Record<string, string> = {
    'm0': '#b5aba1', // Mortar shadow
    'm1': '#d1c8be', // Lime mortar joint
    'm2': '#ece5dc', // Mortar highlight
    'b0': '#692a1e', // Dark brick shadow
    'b1': '#7e3526', // Shadowed brick
    'b2': '#954130', // Mid brick body
    'b3': '#ab4e3b', // Base terracotta brick
    'b4': '#bf5e4a', // Bright brick facet
    'b5': '#d16e5a', // Brick highlight
};

export const BRICKS_MAP: TextureMap = [
    "b3b4b3b2b3b4b3b1m1b3b4b3b2b3b4b3",
    "b2b3b4b3b2b3b4b0m1b2b3b4b3b2b3b4",
    "b1b2b3b4b3b2b3b0m1b1b2b3b4b3b2b3",
    "m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1",
    "b3b1m1b3b4b3b2b3b4b3b1m1b3b4b3b2",
    "b4b0m1b2b3b4b3b2b3b4b0m1b2b3b4b3",
    "b3b0m1b1b2b3b4b3b2b3b0m1b1b2b3b4",
    "m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1",
    "b3b4b3b2b3b4b3b1m1b3b4b3b2b3b4b3",
    "b2b3b4b3b2b3b4b0m1b2b3b4b3b2b3b4",
    "b1b2b3b4b3b2b3b0m1b1b2b3b4b3b2b3",
    "m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1",
    "b3b1m1b3b4b3b2b3b4b3b1m1b3b4b3b2",
    "b4b0m1b2b3b4b3b2b3b4b0m1b2b3b4b3",
    "b3b0m1b1b2b3b4b3b2b3b0m1b1b2b3b4",
    "m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1m1"
];

/* --------------------------------------------------------------
   17. NETHERRACK (Dark porous volcanic crimson rock)
   -------------------------------------------------------------- */
export const NETHERRACK_PALETTE: Record<string, string> = {
    '0': '#421111',
    '1': '#581717',
    '2': '#6e1e1e',
    '3': '#832626',
    '4': '#9a2f2f',
    '5': '#b03b3b',
};

export const NETHERRACK_MAP: TextureMap = [
    "2343210134542101",
    "3454321245653212",
    "2343210134542101",
    "1232101223431012",
    "2343210112320123",
    "3454321201211234",
    "2343210112322345",
    "1232101223433456",
    "2343210134542101",
    "3454321245653212",
    "2343210134542101",
    "1232101223431012",
    "2343210112320123",
    "3454321201211234",
    "2343210112322345",
    "1232101223433456"
];

/* --------------------------------------------------------------
   18. SOUL SAND (Murky dark earth with subtle haunting faces)
   -------------------------------------------------------------- */
export const SOUL_SAND_PALETTE: Record<string, string> = {
    '0': '#352922',
    '1': '#43342c',
    '2': '#514036',
    '3': '#604c41',
    '4': '#6e584c',
};

export const SOUL_SAND_MAP: TextureMap = [
    "2321232134321234",
    "3432343223212321",
    "2321232112101210",
    "1210121023212321",
    "2321232134323432",
    "3432343223212321",
    "2321232112101210",
    "1210121023212321",
    "2321232134321234",
    "3432343223212321",
    "2321232112101210",
    "1210121023212321",
    "2321232134323432",
    "3432343223212321",
    "2321232112101210",
    "1210121023212321"
];

/* --------------------------------------------------------------
   19. GLOWSTONE (Radiant crystalline golden-amber rock)
   -------------------------------------------------------------- */
export const GLOWSTONE_PALETTE: Record<string, string> = {
    '0': '#8f651b',
    '1': '#b68328',
    '2': '#dda239',
    '3': '#f5bf4c',
    '4': '#fedc6d',
    '5': '#fff29e',
};

export const GLOWSTONE_MAP: TextureMap = [
    "3454210134542101",
    "4554321245543212",
    "3454210134542101",
    "2343101223431012",
    "1232012312320123",
    "0121123401211234",
    "1232234512322345",
    "2343345523433455",
    "3454210134542101",
    "4554321245543212",
    "3454210134542101",
    "2343101223431012",
    "1232012312320123",
    "0121123401211234",
    "1232234512322345",
    "2343345523433455"
];

/* --------------------------------------------------------------
   20. NETHER QUARTZ ORE (Pure white quartz in netherrack)
   -------------------------------------------------------------- */
export function renderNetherQuartzOre(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, NETHERRACK_PALETTE, NETHERRACK_MAP);
    const quartzGems: Array<[number, number, string]> = [
        [3, 3, '#eae5e0'], [4, 3, '#ffffff'], [3, 4, '#c8c2bc'], [4, 4, '#9c958f'],
        [10, 2, '#eae5e0'], [11, 2, '#ffffff'], [11, 3, '#c8c2bc'],
        [6, 7, '#eae5e0'], [7, 7, '#ffffff'], [8, 7, '#c8c2bc'], [7, 8, '#ffffff'], [8, 8, '#9c958f'],
        [2, 11, '#eae5e0'], [3, 11, '#ffffff'], [3, 12, '#c8c2bc'],
        [11, 10, '#eae5e0'], [12, 10, '#ffffff'], [12, 11, '#c8c2bc']
    ];
    for (const [x, y, col] of quartzGems) {
        ctx.fillStyle = col;
        ctx.fillRect(x, y, 1, 1);
    }
}

/* --------------------------------------------------------------
   21. OBSIDIAN (Vitreous dark purple-black volcanic glass)
   -------------------------------------------------------------- */
export const OBSIDIAN_PALETTE: Record<string, string> = {
    '0': '#0f0a17',
    '1': '#191124',
    '2': '#241a33',
    '3': '#322544',
    '4': '#413157',
    '5': '#523f6c',
};

export const OBSIDIAN_MAP: TextureMap = [
    "1012321012321012",
    "0123432123432101",
    "1234543234543210",
    "2343210123432101",
    "1232101212321012",
    "0121012301210123",
    "1232123412321234",
    "2343234523432345",
    "1012321012321012",
    "0123432123432101",
    "1234543234543210",
    "2343210123432101",
    "1232101212321012",
    "0121012301210123",
    "1232123412321234",
    "2343234523432345"
];

/* --------------------------------------------------------------
   22. CACTUS (Vertical ribbed green columns with white spine needles)
   -------------------------------------------------------------- */
export function renderCactusSide(ctx: CanvasRenderingContext2D) {
    const ribs = [
        '#376822', '#49862f', '#5ba73b', '#49862f',
        '#376822', '#49862f', '#5ba73b', '#49862f',
        '#376822', '#49862f', '#5ba73b', '#49862f',
        '#376822', '#49862f', '#5ba73b', '#49862f'
    ];
    for (let x = 0; x < 16; x++) {
        ctx.fillStyle = ribs[x];
        ctx.fillRect(x, 0, 1, 16);
    }
    // White spine needles
    ctx.fillStyle = '#ffffff';
    const spines: Array<[number, number]> = [
        [2, 3], [6, 7], [10, 2], [14, 8],
        [2, 11], [6, 15], [10, 10], [14, 14]
    ];
    for (const [x, y] of spines) {
        ctx.fillRect(x, y, 1, 1);
        ctx.fillStyle = '#1c3611';
        ctx.fillRect(x, y + 1, 1, 1);
        ctx.fillStyle = '#ffffff';
    }
}

export function renderCactusTop(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = '#49862f';
    ctx.fillRect(0, 0, 16, 16);
    ctx.fillStyle = '#376822';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
    ctx.fillRect(15, 0, 1, 16);
    ctx.fillStyle = '#5ba73b';
    ctx.fillRect(4, 4, 8, 8);
    ctx.fillStyle = '#2d531b';
    ctx.fillRect(7, 7, 2, 2);
}

/* --------------------------------------------------------------
   23. CHEST (Warm wooden box, dark iron corner brackets, silver lock)
   -------------------------------------------------------------- */
export function renderChestFront(ctx: CanvasRenderingContext2D) {
    // Oak plank base
    drawPixelMap(ctx, PLANKS_PALETTE, PLANKS_MAP);
    // Dark iron trim around edges
    ctx.fillStyle = '#262626';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
    ctx.fillRect(15, 0, 1, 16);
    // Lid horizontal seam
    ctx.fillStyle = '#1e1e1e';
    ctx.fillRect(0, 5, 16, 1);
    // Silver latch in center
    ctx.fillStyle = '#dcdcdc';
    ctx.fillRect(7, 4, 2, 4);
    ctx.fillStyle = '#7a7a7a';
    ctx.fillRect(7, 6, 2, 2);
}

export function renderChestSide(ctx: CanvasRenderingContext2D) {
    drawPixelMap(ctx, PLANKS_PALETTE, PLANKS_MAP);
    // Dark iron border
    ctx.fillStyle = '#262626';
    ctx.fillRect(0, 0, 16, 1);
    ctx.fillRect(0, 15, 16, 1);
    ctx.fillRect(0, 0, 1, 16);
    ctx.fillRect(15, 0, 1, 16);
    // Lid seam
    ctx.fillStyle = '#1e1e1e';
    ctx.fillRect(0, 5, 16, 1);
}

/* --------------------------------------------------------------
   24. CLAY & SNOW
   -------------------------------------------------------------- */
export const CLAY_PALETTE: Record<string, string> = {
    '0': '#7f8595',
    '1': '#8d94a4',
    '2': '#9da4b4',
    '3': '#adb4c4',
    '4': '#bcc4d4',
};

export const CLAY_MAP: TextureMap = [
    "2321232123212321",
    "3432343234323432",
    "2321232123212321",
    "1210121012101210",
    "2321232123212321",
    "3432343234323432",
    "2321232123212321",
    "1210121012101210",
    "2321232123212321",
    "3432343234323432",
    "2321232123212321",
    "1210121012101210",
    "2321232123212321",
    "3432343234323432",
    "2321232123212321",
    "1210121012101210"
];

export const SNOW_PALETTE: Record<string, string> = {
    '0': '#d5e4eb',
    '1': '#e2f0f7',
    '2': '#edf6fb',
    '3': '#f7fbfe',
    '4': '#ffffff',
};

export const SNOW_MAP: TextureMap = [
    "3432343234323432",
    "4443444344434443",
    "3432343234323432",
    "2321232123212321",
    "3432343234323432",
    "4443444344434443",
    "3432343234323432",
    "2321232123212321",
    "3432343234323432",
    "4443444344434443",
    "3432343234323432",
    "2321232123212321",
    "3432343234323432",
    "4443444344434443",
    "3432343234323432",
    "2321232123212321"
];

/* --------------------------------------------------------------
   25. BOTANICAL PLANTS (Tall Grass, Poppy, Dandelion, Bamboo, Mushroom)
   -------------------------------------------------------------- */
export function renderTallGrass(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, 16, 16);
    const blades: Array<[number, number, string]> = [
        [7, 15, '#3b6e1e'], [8, 15, '#488526'], [7, 14, '#488526'], [8, 14, '#5ca732'],
        [7, 13, '#5ca732'], [8, 13, '#6fc13e'], [6, 12, '#488526'], [7, 12, '#6fc13e'],
        [8, 12, '#6fc13e'], [9, 12, '#488526'], [5, 11, '#488526'], [6, 11, '#5ca732'],
        [7, 11, '#6fc13e'], [8, 11, '#6fc13e'], [9, 11, '#5ca732'], [10, 11, '#488526'],
        [4, 10, '#5ca732'], [5, 10, '#6fc13e'], [7, 10, '#6fc13e'], [8, 10, '#6fc13e'],
        [10, 10, '#6fc13e'], [11, 10, '#5ca732'], [3, 9, '#6fc13e'], [4, 9, '#7dd446'],
        [7, 9, '#6fc13e'], [8, 9, '#7dd446'], [11, 9, '#7dd446'], [12, 9, '#6fc13e'],
        [3, 8, '#7dd446'], [7, 8, '#7dd446'], [8, 8, '#8de650'], [12, 8, '#7dd446'],
        [7, 7, '#8de650'], [8, 7, '#8de650'], [7, 6, '#8de650']
    ];
    for (const [x, y, col] of blades) {
        ctx.fillStyle = col;
        ctx.fillRect(x, y, 1, 1);
    }
}

export function renderPoppy(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, 16, 16);
    // Green stem
    ctx.fillStyle = '#488526';
    ctx.fillRect(7, 8, 2, 8);
    // Vibrant red flower petals
    ctx.fillStyle = '#cc1818';
    ctx.fillRect(5, 4, 6, 5);
    ctx.fillStyle = '#eb2f2f';
    ctx.fillRect(6, 3, 4, 5);
    ctx.fillStyle = '#ff5454';
    ctx.fillRect(6, 4, 2, 2);
    // Dark poppy center
    ctx.fillStyle = '#220808';
    ctx.fillRect(7, 5, 2, 2);
}

export function renderDandelion(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, 16, 16);
    // Green stem
    ctx.fillStyle = '#488526';
    ctx.fillRect(7, 8, 2, 8);
    // Yellow flower blossom
    ctx.fillStyle = '#e6b800';
    ctx.fillRect(5, 5, 6, 4);
    ctx.fillStyle = '#ffd633';
    ctx.fillRect(6, 4, 4, 5);
    ctx.fillStyle = '#fff066';
    ctx.fillRect(7, 5, 2, 2);
}

export function renderBambooSide(ctx: CanvasRenderingContext2D) {
    ctx.clearRect(0, 0, 16, 16);
    // Bamboo culm (stalk) in center
    ctx.fillStyle = '#487c2b';
    ctx.fillRect(6, 0, 4, 16);
    ctx.fillStyle = '#5fa438';
    ctx.fillRect(7, 0, 2, 16);
    // Ringed node joint
    ctx.fillStyle = '#2e521b';
    ctx.fillRect(5, 7, 6, 2);
    ctx.fillStyle = '#78c647';
    ctx.fillRect(6, 7, 4, 1);
}

export function renderMushroomCap(ctx: CanvasRenderingContext2D) {
    ctx.fillStyle = '#b52323';
    ctx.fillRect(0, 0, 16, 16);
    // White polka-dot spots
    ctx.fillStyle = '#e8dede';
    const spots: Array<[number, number]> = [
        [3, 3], [4, 3], [3, 4], [4, 4],
        [11, 4], [12, 4], [11, 5], [12, 5],
        [7, 9], [8, 9], [7, 10], [8, 10],
        [2, 11], [3, 11], [12, 12], [13, 12]
    ];
    for (const [x, y] of spots) {
        ctx.fillRect(x, y, 1, 1);
    }
}

/* ==============================================================
   BLOCK CANVAS GENERATOR
   Creates crisp 16x16 canvas with authentic vanilla textures.
   ============================================================== */
export function createMinecraftBlockCanvas(
    blockId: number,
    variant: 'default' | 'top' | 'side' | 'bottom' | 'front' = 'default'
): HTMLCanvasElement {
    const canvas = document.createElement('canvas');
    canvas.width = 16;
    canvas.height = 16;
    const ctx = canvas.getContext('2d')!;

    switch (blockId) {
        case BLOCK_ID.GRASS:
            if (variant === 'top') {
                renderGrassTop(ctx);
            } else if (variant === 'side') {
                renderGrassSide(ctx);
            } else {
                renderVanillaDirt(ctx);
            }
            break;

        case BLOCK_ID.DIRT:
            renderVanillaDirt(ctx);
            break;

        case BLOCK_ID.STONE:
            renderVanillaStone(ctx);
            break;

        case BLOCK_ID.COBBLESTONE:
            drawPixelMap(ctx, COBBLESTONE_PALETTE, COBBLESTONE_MAP);
            break;

        case BLOCK_ID.MOSSY_COBBLESTONE:
            renderMossyCobblestone(ctx);
            break;

        case BLOCK_ID.PLANKS:
        case BLOCK_ID.WOOD:
            drawPixelMap(ctx, PLANKS_PALETTE, PLANKS_MAP);
            break;

        case BLOCK_ID.LOG:
            if (variant === 'top' || variant === 'bottom') {
                renderLogTop(ctx);
            } else {
                drawPixelMap(ctx, LOG_SIDE_PALETTE, LOG_SIDE_MAP);
            }
            break;

        case BLOCK_ID.LEAVES:
            drawPixelMap(ctx, LEAVES_PALETTE, LEAVES_MAP);
            break;

        case BLOCK_ID.CHERRY_LEAVES:
            renderCherryLeaves(ctx);
            break;

        case BLOCK_ID.RED_LEAVES:
            renderRedLeaves(ctx);
            break;

        case BLOCK_ID.SAND:
            renderVanillaSand(ctx);
            break;

        case BLOCK_ID.GRAVEL:
            drawPixelMap(ctx, GRAVEL_PALETTE, GRAVEL_MAP);
            break;

        case BLOCK_ID.GLASS:
            renderGlass(ctx);
            break;

        case BLOCK_ID.BEDROCK:
            drawPixelMap(ctx, BEDROCK_PALETTE, BEDROCK_MAP);
            break;

        case BLOCK_ID.COAL_ORE:
        case BLOCK_ID.IRON_ORE:
        case BLOCK_ID.GOLD_ORE:
        case BLOCK_ID.DIAMOND_ORE:
        case BLOCK_ID.REDSTONE_ORE:
        case BLOCK_ID.EMERALD_ORE:
        case BLOCK_ID.LAPIS_ORE:
        case BLOCK_ID.RUBY_ORE:
            renderOre(ctx, blockId);
            break;

        case BLOCK_ID.BRICKS:
            drawPixelMap(ctx, BRICKS_PALETTE, BRICKS_MAP);
            break;

        case BLOCK_ID.NETHERRACK:
            drawPixelMap(ctx, NETHERRACK_PALETTE, NETHERRACK_MAP);
            break;

        case BLOCK_ID.SOUL_SAND:
            drawPixelMap(ctx, SOUL_SAND_PALETTE, SOUL_SAND_MAP);
            break;

        case BLOCK_ID.GLOWSTONE:
            drawPixelMap(ctx, GLOWSTONE_PALETTE, GLOWSTONE_MAP);
            break;

        case BLOCK_ID.NETHER_QUARTZ_ORE:
            renderNetherQuartzOre(ctx);
            break;

        case BLOCK_ID.OBSIDIAN:
            drawPixelMap(ctx, OBSIDIAN_PALETTE, OBSIDIAN_MAP);
            break;

        case BLOCK_ID.CACTUS:
            if (variant === 'top' || variant === 'bottom') {
                renderCactusTop(ctx);
            } else {
                renderCactusSide(ctx);
            }
            break;

        case BLOCK_ID.CHEST:
            if (variant === 'front') {
                renderChestFront(ctx);
            } else {
                renderChestSide(ctx);
            }
            break;

        case BLOCK_ID.CLAY:
            drawPixelMap(ctx, CLAY_PALETTE, CLAY_MAP);
            break;

        case BLOCK_ID.SNOW:
            drawPixelMap(ctx, SNOW_PALETTE, SNOW_MAP);
            break;

        case BLOCK_ID.TALL_GRASS:
            renderTallGrass(ctx);
            break;

        case BLOCK_ID.FLOWER_RED:
            renderPoppy(ctx);
            break;

        case BLOCK_ID.FLOWER_YELLOW:
            renderDandelion(ctx);
            break;

        case BLOCK_ID.BAMBOO:
            if (variant === 'top' || variant === 'bottom') {
                renderCactusTop(ctx);
            } else {
                renderBambooSide(ctx);
            }
            break;

        case BLOCK_ID.MUSHROOM_CAP:
            renderMushroomCap(ctx);
            break;

        default:
            renderVanillaStone(ctx);
            break;
    }

    return canvas;
}

/* ==============================================================
   TEXTURE INSTANTIATION WITH CRISP NEAREST FILTERING & MIPMAPPING
   - magFilter: NearestFilter (sharp, crisp, iconic Minecraft texels up close)
   - minFilter: NearestMipmapLinearFilter (smooth mipmapped transitions at distance,
     zero moiré flickering or crawling pixel noise across the horizon!)
   ============================================================== */
export function createMinecraftTexture(
    blockId: number,
    variant: 'default' | 'top' | 'side' | 'bottom' | 'front' = 'default'
): THREE.CanvasTexture {
    const canvas = createMinecraftBlockCanvas(blockId, variant);
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = true;
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestMipmapLinearFilter;
    tex.needsUpdate = true;
    return tex;
}
