import * as THREE from 'three';
import { BLOCK_ID, BLOCK_DEFS } from './constants';
import { VoxelWorld } from './world';
import { PlayerController } from './player';
import { FriendlyMobManager, HostileMobManager } from './mobs';
import { ParticleKernel, AudioProcessor } from './environment';

export interface WindChargeInstance {
    mesh: THREE.Group;
    rings: THREE.Mesh[];
    velocity: THREE.Vector3;
    life: number;
    thrownByPlayer: boolean;
}

export class WindChargeManager {
    scene: THREE.Scene;
    projectiles: WindChargeInstance[] = [];

    // Shared cached geometries & materials for zero-garbage 60fps performance
    private coreGeom: THREE.SphereGeometry;
    private auraGeom: THREE.SphereGeometry;
    private ringGeom: THREE.TorusGeometry;
    private coreMat: THREE.MeshBasicMaterial;
    private auraMat: THREE.MeshBasicMaterial;
    private ringMat: THREE.MeshBasicMaterial;

    constructor(scene: THREE.Scene) {
        this.scene = scene;
        this.coreGeom = new THREE.SphereGeometry(0.16, 8, 8);
        this.auraGeom = new THREE.SphereGeometry(0.28, 8, 8);
        this.ringGeom = new THREE.TorusGeometry(0.36, 0.035, 6, 14);

        this.coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
        this.auraMat = new THREE.MeshBasicMaterial({
            color: 0x9be8ff,
            transparent: true,
            opacity: 0.65,
            depthWrite: false
        });
        this.ringMat = new THREE.MeshBasicMaterial({
            color: 0xc8f4ff,
            transparent: true,
            opacity: 0.85,
            depthWrite: false
        });
    }

    /**
     * Spawns and launches a wind charge projectile
     */
    launch(origin: THREE.Vector3, direction: THREE.Vector3, speed = 25, thrownByPlayer = true): WindChargeInstance {
        const group = new THREE.Group();

        // Glowing center core
        const core = new THREE.Mesh(this.coreGeom, this.coreMat);
        group.add(core);

        // Soft breezy aura
        const aura = new THREE.Mesh(this.auraGeom, this.auraMat);
        group.add(aura);

        // Orbiting wind rings
        const rings: THREE.Mesh[] = [];
        const r1 = new THREE.Mesh(this.ringGeom, this.ringMat);
        r1.rotation.x = Math.PI / 4;
        group.add(r1);
        rings.push(r1);

        const r2 = new THREE.Mesh(this.ringGeom, this.ringMat);
        r2.rotation.y = Math.PI / 3;
        r2.rotation.z = Math.PI / 5;
        group.add(r2);
        rings.push(r2);

        // Position slightly forward from eyes so it doesn't clip immediately
        group.position.copy(origin).addScaledVector(direction, 0.5);

        this.scene.add(group);

        const velocity = direction.clone().normalize().multiplyScalar(speed);
        const inst: WindChargeInstance = {
            mesh: group,
            rings,
            velocity,
            life: 3.0,
            thrownByPlayer
        };

        this.projectiles.push(inst);
        return inst;
    }

    /**
     * Frame-by-frame update loop for all flying wind charges
     */
    update(
        dt: number,
        world: VoxelWorld,
        player: PlayerController,
        friendlyMobs: FriendlyMobManager | null,
        hostileMobs: HostileMobManager | null,
        particles: ParticleKernel | null,
        audio: AudioProcessor | null
    ) {
        // Clamp dt to avoid physics tunnelling on lag spikes
        const stepDt = Math.min(dt, 0.05);

        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const p = this.projectiles[i];
            p.life -= stepDt;

            // Animate swirling breeze rings
            p.rings[0].rotation.x += stepDt * 10;
            p.rings[0].rotation.z += stepDt * 8;
            p.rings[1].rotation.y += stepDt * 12;
            p.rings[1].rotation.x += stepDt * 6;

            // Slight arc gravity
            p.velocity.y -= 3.5 * stepDt;

            // Step movement
            const oldPos = p.mesh.position.clone();
            const step = p.velocity.clone().multiplyScalar(stepDt);
            const newPos = oldPos.clone().add(step);

            // Emit subtle wind trail
            if (particles && Math.random() < 0.6) {
                particles.spawnWindTrail(oldPos.x, oldPos.y, oldPos.z);
            }

            // Check collision along step
            let hit = false;
            let hitPoint = newPos.clone();

            // 1. Block collision
            const checkSteps = 4;
            for (let s = 1; s <= checkSteps; s++) {
                const subPos = oldPos.clone().lerp(newPos, s / checkSteps);
                const bx = Math.floor(subPos.x);
                const by = Math.floor(subPos.y);
                const bz = Math.floor(subPos.z);
                const bId = world.getVoxel(bx, by, bz);

                if (bId !== BLOCK_ID.AIR && bId !== BLOCK_ID.WATER && bId !== BLOCK_ID.LAVA) {
                    const def = BLOCK_DEFS[bId];
                    if (def && def.solid) {
                        hit = true;
                        hitPoint.copy(subPos);
                        break;
                    }
                }
            }

            // 2. Mob collision (if not hit block)
            if (!hit) {
                const checkMobList: any[] = [];
                if (friendlyMobs) {
                    for (const m of friendlyMobs.entities.values()) {
                        if (m.group) checkMobList.push(m);
                    }
                }
                if (hostileMobs) {
                    for (const m of hostileMobs.entities.values()) {
                        if (m.group) checkMobList.push(m);
                    }
                }

                for (const mob of checkMobList) {
                    const d = mob.group.position.distanceTo(newPos);
                    if (d < 1.1) {
                        hit = true;
                        hitPoint.copy(mob.group.position);
                        break;
                    }
                }
            }

            // 3. Player direct hit (if thrown downwards or self-detonation after initial flight)
            if (!hit && p.life < 2.9) {
                const pEye = player.camera.position;
                if (pEye.distanceTo(newPos) < 0.9) {
                    hit = true;
                    hitPoint.copy(newPos);
                }
            }

            if (hit || p.life <= 0) {
                // Detonate wind burst!
                this.detonate(hitPoint, player, friendlyMobs, hostileMobs, particles, audio, world);
                this.scene.remove(p.mesh);
                this.projectiles.splice(i, 1);
            } else {
                p.mesh.position.copy(newPos);
            }
        }
    }

    /**
     * Executes the Wind Burst detonation:
     * - Particles & audio
     * - Wind Charge Jump launch for player
     * - Strong radial knockback & damage to mobs
     */
    detonate(
        pos: THREE.Vector3,
        player: PlayerController,
        friendlyMobs: FriendlyMobManager | null,
        hostileMobs: HostileMobManager | null,
        particles: ParticleKernel | null,
        audio: AudioProcessor | null,
        world: VoxelWorld
    ) {
        // Visuals & Sound
        if (particles) {
            particles.spawnWindBurst(pos.x, pos.y, pos.z);
        }
        if (audio) {
            audio.playWindBurst();
        }

        const BLAST_RADIUS = 4.8;

        // 1. Player Knockback & Wind Jump boost (Minecraft 1.21 authentic mechanic)
        const playerPos = player.camera.position.clone();
        // Feet position for distance check
        const playerFeet = playerPos.clone();
        playerFeet.y -= 1.62;

        const distToPlayer = playerFeet.distanceTo(pos);
        if (distToPlayer < BLAST_RADIUS) {
            const relY = playerFeet.y - pos.y;
            const diffX = playerFeet.x - pos.x;
            const diffZ = playerFeet.z - pos.z;
            const horizDist = Math.hypot(diffX, diffZ);

            // Authentic Wind Charge Jump:
            // If the blast detonates near the ground beneath the player, launch the player high into the air
            // and cancel accumulated fall damage (fallStartY reset to current position)!
            if (relY >= -1.2 && distToPlayer <= 4.2) {
                const launchPower = 0.44; // High upward velocity launching player ~8-10 blocks!
                player.velocity.y = Math.max(player.velocity.y, launchPower);
                player.fallStartY = player.camera.position.y; // Reset fall distance (Negates fall damage!)
                player.onGround = false;

                // Outward horizontal blast nudge
                if (horizDist > 0.08) {
                    const horizScale = (1 - distToPlayer / BLAST_RADIUS) * 0.16;
                    player.velocity.x += (diffX / horizDist) * horizScale;
                    player.velocity.z += (diffZ / horizDist) * horizScale;
                }
            } else {
                // Blast from side/above: push player away
                const pushStr = (1 - distToPlayer / BLAST_RADIUS) * 0.25;
                if (horizDist > 0.05) {
                    player.velocity.x += (diffX / horizDist) * pushStr;
                    player.velocity.z += (diffZ / horizDist) * pushStr;
                }
                player.velocity.y = Math.max(player.velocity.y, 0.18);
            }
        }

        // 2. Mobs Knockback and Damage with authentic Minecraft physics impulses
        const applyMobBlast = (mobList: any[], manager: any) => {
            const deadMobIds: string[] = [];
            for (const mob of mobList) {
                if (!mob.group) continue;
                const mPos = mob.group.position;
                const d = mPos.distanceTo(pos);
                if (d < BLAST_RADIUS) {
                    const force = Math.max(0.25, 1 - d / BLAST_RADIUS);
                    const dx = mPos.x - pos.x;
                    const dz = mPos.z - pos.z;
                    const len = Math.hypot(dx, dz) || 1;

                    // Physical velocity knockback upward and outward
                    if (mob.vel) {
                        mob.vel.x += (dx / len) * force * 15.0;
                        mob.vel.z += (dz / len) * force * 15.0;
                        mob.vel.y = Math.max(mob.vel.y, 6.5 * force);
                    }
                    mob.onGround = false;
                    mob.hurtTilt = 1.0;
                    mob.flashTimer = 0.28;

                    // Apply blast damage
                    const dmg = Math.round(3 + force * 4);
                    mob.health -= dmg;

                    if (mob.health <= 0) {
                        deadMobIds.push(mob.id);
                    }
                }
            }

            for (const deadId of deadMobIds) {
                const ent = manager.entities.get(deadId);
                if (ent) {
                    if (particles) particles.spawnDebris(ent.group.position.x, ent.group.position.y + 0.5, ent.group.position.z, 0xaaaaaa);
                    this.scene.remove(ent.group);
                    manager.entities.delete(deadId);
                }
            }
        };

        if (friendlyMobs) {
            applyMobBlast(Array.from(friendlyMobs.entities.values()), friendlyMobs);
        }
        if (hostileMobs) {
            applyMobBlast(Array.from(hostileMobs.entities.values()), hostileMobs);
        }

        // 3. Clear non-solid decorative plants at impact center
        const bx = Math.floor(pos.x);
        const by = Math.floor(pos.y);
        const bz = Math.floor(pos.z);
        for (let ox = -1; ox <= 1; ox++) {
            for (let oy = -1; oy <= 1; oy++) {
                for (let oz = -1; oz <= 1; oz++) {
                    const b = world.getVoxel(bx + ox, by + oy, bz + oz);
                    if (b === BLOCK_ID.TALL_GRASS || b === BLOCK_ID.FLOWER_RED || b === BLOCK_ID.FLOWER_YELLOW) {
                        world.setVoxel(bx + ox, by + oy, bz + oz, BLOCK_ID.AIR);
                    }
                }
            }
        }
    }
}
