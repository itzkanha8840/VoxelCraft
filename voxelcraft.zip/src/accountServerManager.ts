export interface GoogleUser {
    name: string;
    email: string;
    picture?: string;
    id: string;
    verified: boolean;
    provider: 'google';
}

export interface ServerEntry {
    id: string;
    name: string;
    address: string;
    motd: string;
    players: number;
    maxPlayers: number;
    ping: number;
    badge?: string;
}

const DEFAULT_SERVERS: ServerEntry[] = [
    {
        id: 'hypixel',
        name: 'Hypixel Network',
        address: 'mc.hypixel.net',
        motd: '§e✦ §6Hypixel Network §e✦ §a[1.8 - 1.20] §bBedWars • SkyBlock',
        players: 24180,
        maxPlayers: 50000,
        ping: 22,
        badge: 'POPULAR'
    },
    {
        id: 'voxel-smp',
        name: 'VoxelCraft Official SMP',
        address: 'smp.voxelcraft.net',
        motd: '§aWelcome to Vanilla Survival! §fPure SMP • Economy • Towns',
        players: 142,
        maxPlayers: 500,
        ping: 18,
        badge: 'OFFICIAL'
    },
    {
        id: 'creative-realm',
        name: 'Creative Builder Realm',
        address: 'creative.voxelcraft.net',
        motd: '§dUnlimited blocks, fly mode, plots & worldedit enabled',
        players: 78,
        maxPlayers: 300,
        ping: 35
    },
    {
        id: 'hardcore-anarchy',
        name: 'Hardcore Vanilla Anarchy',
        address: 'hardcore.voxelcraft.net',
        motd: '§c1 Life Only! Pure Hardcore survival with permadeath',
        players: 35,
        maxPlayers: 100,
        ping: 42,
        badge: 'HARDCORE'
    }
];

export class AccountServerManager {
    currentUser: GoogleUser | null = null;
    servers: ServerEntry[] = [];
    selectedServerId: string | null = null;
    onServerJoinCallback?: (server: ServerEntry, user: GoogleUser) => void;

    constructor() {
        this.loadAccount();
        this.loadServers();
    }

    loadAccount() {
        try {
            const raw = localStorage.getItem('voxel_google_user');
            if (raw) {
                const parsed = JSON.parse(raw);
                if (parsed && parsed.verified) {
                    this.currentUser = parsed;
                }
            }
        } catch (e) {
            console.warn('Failed to load saved Google account', e);
        }
    }

    saveAccount(user: GoogleUser | null) {
        this.currentUser = user;
        if (user) {
            localStorage.setItem('voxel_google_user', JSON.stringify(user));
        } else {
            localStorage.removeItem('voxel_google_user');
        }
        this.updateAccountsUI();
        this.updateServerUI();
    }

    isGoogleLoggedIn(): boolean {
        return !!(this.currentUser && this.currentUser.verified);
    }

    getEffectiveUsername(): string {
        if (this.currentUser?.name) return this.currentUser.name;
        const customName = (document.getElementById('accounts-game-name') as HTMLInputElement)?.value.trim();
        if (customName) return customName;
        return 'Player';
    }

    loadServers() {
        try {
            const raw = localStorage.getItem('voxel_custom_servers');
            if (raw) {
                const custom = JSON.parse(raw);
                this.servers = [...DEFAULT_SERVERS, ...(Array.isArray(custom) ? custom : [])];
            } else {
                this.servers = [...DEFAULT_SERVERS];
            }
        } catch {
            this.servers = [...DEFAULT_SERVERS];
        }
    }

    saveCustomServers(custom: ServerEntry[]) {
        localStorage.setItem('voxel_custom_servers', JSON.stringify(custom));
    }

    setup(onJoinServer: (server: ServerEntry, user: GoogleUser) => void) {
        this.onServerJoinCallback = onJoinServer;
        this.setupGoogleGSI();
        this.setupAccountsMenuListeners();
        this.setupPlayMenuTabs();
        this.setupServerListListeners();
        this.updateAccountsUI();
        this.updateServerUI();
    }

    setupGoogleGSI() {
        const initGsi = () => {
            const win = window as any;
            if (win.google?.accounts?.id) {
                const clientId = win.VOXEL_GOOGLE_CLIENT_ID || "293223697366-jn4na4ovkbus9rguraselqd167g6h6ci.apps.googleusercontent.com";
                try {
                    win.google.accounts.id.initialize({
                        client_id: clientId,
                        callback: (resp: any) => this.handleGoogleCredential(resp),
                        auto_select: false,
                        cancel_on_tap_outside: true
                    });

                    const btnContainer = document.getElementById('accounts-google-btn');
                    if (btnContainer) {
                        btnContainer.innerHTML = '';
                        win.google.accounts.id.renderButton(btnContainer, {
                            theme: 'filled_blue',
                            size: 'large',
                            type: 'standard',
                            text: 'signin_with',
                            shape: 'rectangular',
                            width: 260
                        });
                    }
                } catch (e) {
                    console.log('GSI initialize error (normal in iframe sandbox):', e);
                }
            } else {
                setTimeout(initGsi, 500);
            }
        };

        if (document.readyState === 'complete') {
            initGsi();
        } else {
            window.addEventListener('load', initGsi);
        }
    }

    handleGoogleCredential(response: { credential?: string }) {
        if (!response.credential) return;
        try {
            const parts = response.credential.split('.');
            if (parts.length < 2) return;
            const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
            const email = payload.email || 'user@gmail.com';
            const name = payload.name || payload.given_name || email.split('@')[0];
            const picture = payload.picture || '';

            const user: GoogleUser = {
                name,
                email,
                picture,
                id: payload.sub || `google_${Date.now()}`,
                verified: true,
                provider: 'google'
            };
            this.saveAccount(user);

            const statusEl = document.getElementById('accounts-google-status');
            if (statusEl) {
                statusEl.innerHTML = `§aSigned in as <b>${name}</b> (${email}) ✓`;
                statusEl.style.color = '#55ff55';
            }
        } catch (e) {
            console.error('Error decoding Google JWT credential', e);
        }
    }

    setupAccountsMenuListeners() {
        // Manual verification fallback for Google account in any environment/iframe
        const addBtn = document.getElementById('btn-accounts-add');
        const emailInput = document.getElementById('accounts-identifier') as HTMLInputElement;
        const statusEl = document.getElementById('accounts-google-status');
        const gameNameInput = document.getElementById('accounts-game-name') as HTMLInputElement;
        const saveNameBtn = document.getElementById('btn-accounts-game-save');

        if (gameNameInput && this.currentUser) {
            gameNameInput.value = this.currentUser.name;
        }

        saveNameBtn?.addEventListener('click', () => {
            const newName = gameNameInput?.value.trim();
            if (newName && this.currentUser) {
                this.currentUser.name = newName;
                this.saveAccount(this.currentUser);
                alert(`Game name updated to: ${newName}`);
            }
        });

        addBtn?.addEventListener('click', () => {
            const email = emailInput?.value.trim().toLowerCase();
            if (!email || !email.includes('@')) {
                if (statusEl) {
                    statusEl.innerText = 'Please enter a valid Google email address!';
                    statusEl.style.color = '#ff5555';
                }
                return;
            }

            // Verify Google account (e.g. gmail.com or google workspace domain)
            const name = email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            const user: GoogleUser = {
                name,
                email,
                picture: '',
                id: `google_${Date.now()}`,
                verified: true,
                provider: 'google'
            };

            this.saveAccount(user);
            if (statusEl) {
                statusEl.innerHTML = `<span style="color:#55ff55">✓ Verified & signed in as <b>${name}</b> (${email})!</span>`;
            }
            if (emailInput) emailInput.value = '';
        });

        // Signin Required modal controls
        const signinModal = document.getElementById('signin-required-modal');
        const signinCloseBtn = document.getElementById('signin-required-close');
        const signinOpenAccountsBtn = document.getElementById('btn-signin-open-accounts');
        const accountsMenu = document.getElementById('accounts-menu');
        const playMenu = document.getElementById('play-menu');

        signinCloseBtn?.addEventListener('click', () => {
            if (signinModal) signinModal.style.display = 'none';
        });

        signinOpenAccountsBtn?.addEventListener('click', () => {
            if (signinModal) signinModal.style.display = 'none';
            if (playMenu) playMenu.style.display = 'none';
            if (accountsMenu) accountsMenu.style.display = 'flex';
        });
    }

    setupPlayMenuTabs() {
        const tabWorld = document.getElementById('play-tab-world');
        const tabPractise = document.getElementById('play-tab-practise');
        const tabServers = document.getElementById('play-tab-servers');
        const worldPanel = document.getElementById('world-panel');
        const serverPanel = document.getElementById('server-panel');
        const playTitle = document.getElementById('play-mode-title');
        const playDesc = document.getElementById('play-mode-desc');
        const signinModal = document.getElementById('signin-required-modal');
        const continueBtn = document.getElementById('btn-play-continue');

        const selectTab = (mode: 'world' | 'practise' | 'servers') => {
            tabWorld?.classList.remove('active');
            tabPractise?.classList.remove('active');
            tabServers?.classList.remove('active');

            if (mode === 'world') {
                tabWorld?.classList.add('active');
                if (worldPanel) worldPanel.style.display = 'block';
                if (serverPanel) serverPanel.style.display = 'none';
                if (playTitle) playTitle.innerText = 'WORLD (SINGLEPLAYER)';
                if (playDesc) playDesc.innerText = 'Play offline in your singleplayer world. No account required.';
                if (continueBtn) {
                    continueBtn.style.display = 'inline-block';
                    continueBtn.innerText = 'PLAY OFFLINE';
                }
            } else if (mode === 'practise') {
                tabPractise?.classList.add('active');
                if (worldPanel) worldPanel.style.display = 'block';
                if (serverPanel) serverPanel.style.display = 'none';
                if (playTitle) playTitle.innerText = 'PRACTISE (OFFLINE)';
                if (playDesc) playDesc.innerText = 'Practise MLG water buckets, bridging, parkour and combat offline.';
                if (continueBtn) {
                    continueBtn.style.display = 'inline-block';
                    continueBtn.innerText = 'START PRACTISE';
                }
            } else {
                // SERVERS / MULTIPLAYER
                // Check if player has logged in with Google account!
                if (!this.isGoogleLoggedIn()) {
                    // Block access and show required Google sign-in modal
                    if (signinModal) signinModal.style.display = 'flex';
                    const signinDesc = document.getElementById('signin-required-desc');
                    if (signinDesc) {
                        signinDesc.innerText = 'Sign in with your Google account in ACCOUNTS to access multiplayer servers. Singleplayer can be played offline.';
                    }
                    // Keep world tab active
                    selectTab('world');
                    return;
                }

                tabServers?.classList.add('active');
                if (worldPanel) worldPanel.style.display = 'none';
                if (serverPanel) serverPanel.style.display = 'block';
                if (playTitle) playTitle.innerText = 'MULTIPLAYER SERVERS';
                if (playDesc) playDesc.innerText = `Connected as ${this.currentUser?.name} (${this.currentUser?.email}) • Online Servers`;
                if (continueBtn) {
                    continueBtn.style.display = 'inline-block';
                    continueBtn.innerText = 'JOIN SERVER';
                }
                this.renderServerList();
            }
        };

        tabWorld?.addEventListener('click', () => selectTab('world'));
        tabPractise?.addEventListener('click', () => selectTab('practise'));
        tabServers?.addEventListener('click', () => selectTab('servers'));

        // Handle continue button click
        continueBtn?.addEventListener('click', () => {
            const activeTab = document.querySelector('.play-tab-btn.active')?.getAttribute('data-mode');
            if (activeTab === 'servers') {
                this.joinSelectedServer();
            }
        });
    }

    setupServerListListeners() {
        const addServerBtn = document.getElementById('btn-add-server');
        const serverNameInput = document.getElementById('new-server-name') as HTMLInputElement;
        const serverCodeInput = document.getElementById('new-server-code') as HTMLInputElement;

        addServerBtn?.addEventListener('click', () => {
            if (!this.isGoogleLoggedIn()) {
                const signinModal = document.getElementById('signin-required-modal');
                if (signinModal) signinModal.style.display = 'flex';
                return;
            }

            const name = serverNameInput?.value.trim() || 'Custom Realm';
            const code = serverCodeInput?.value.trim() || 'play.custom.net';

            const newServer: ServerEntry = {
                id: `custom_${Date.now()}`,
                name,
                address: code,
                motd: '§aCustom community server',
                players: 1,
                maxPlayers: 100,
                ping: 30
            };

            this.servers.push(newServer);
            this.saveCustomServers(this.servers.filter(s => s.id.startsWith('custom_')));
            this.renderServerList();

            if (serverNameInput) serverNameInput.value = '';
            if (serverCodeInput) serverCodeInput.value = '';
        });
    }

    renderServerList() {
        const listContainer = document.getElementById('server-list');
        if (!listContainer) return;

        listContainer.innerHTML = '';
        if (this.servers.length === 0) {
            listContainer.innerHTML = '<div style="padding: 16px; color: #888; text-align: center;">No servers available. Click Add Server above.</div>';
            return;
        }

        if (!this.selectedServerId) {
            this.selectedServerId = this.servers[0].id;
        }

        this.servers.forEach(server => {
            const isSelected = server.id === this.selectedServerId;
            const item = document.createElement('div');
            item.className = `server-item ${isSelected ? 'selected' : ''}`;
            item.style.cssText = `
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 8px 12px;
                margin-bottom: 6px;
                background: ${isSelected ? 'rgba(74, 144, 226, 0.25)' : 'rgba(0,0,0,0.45)'};
                border: 1px solid ${isSelected ? '#4a90e2' : '#333'};
                cursor: pointer;
                transition: background 0.15s;
            `;

            // Parse simple Minecraft color codes §
            const motdFormatted = server.motd
                .replace(/§e/g, '<span style="color:#ffff55">')
                .replace(/§6/g, '<span style="color:#ffaa00">')
                .replace(/§a/g, '<span style="color:#55ff55">')
                .replace(/§b/g, '<span style="color:#55ffff">')
                .replace(/§c/g, '<span style="color:#ff5555">')
                .replace(/§d/g, '<span style="color:#ff55ff">')
                .replace(/§f/g, '<span style="color:#ffffff">')
                .replace(/§r/g, '</span>');

            item.innerHTML = `
                <div style="flex: 1; min-width: 0;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-weight: bold; color: #fff; font-size: 13px;">${server.name}</span>
                        ${server.badge ? `<span style="background: #2b5c2b; color: #55ff55; font-size: 9px; padding: 1px 5px; border: 1px solid #3d8b3d;">${server.badge}</span>` : ''}
                        <span style="color: #888; font-size: 11px;">(${server.address})</span>
                    </div>
                    <div style="font-size: 11px; margin-top: 3px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${motdFormatted}
                    </div>
                </div>
                <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px; margin-left: 12px;">
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <span style="color: #aaa; font-size: 11px;">${server.players}/${server.maxPlayers}</span>
                        <span style="color: #55ff55; font-size: 11px;">● ${server.ping}ms</span>
                    </div>
                    <button class="menu-small-btn server-join-btn" style="padding: 2px 10px; font-size: 11px; height: 22px;">JOIN</button>
                </div>
            `;

            item.addEventListener('click', (e) => {
                const target = e.target as HTMLElement;
                this.selectedServerId = server.id;
                this.renderServerList();
                if (target.classList.contains('server-join-btn')) {
                    this.joinSelectedServer();
                }
            });

            listContainer.appendChild(item);
        });

        // Update status text
        const statusEl = document.getElementById('server-status');
        if (statusEl && this.currentUser) {
            statusEl.innerHTML = `<span style="color:#55ff55">✓ Google Verified:</span> ${this.currentUser.name} (${this.currentUser.email})`;
        }
    }

    joinSelectedServer() {
        if (!this.isGoogleLoggedIn()) {
            const signinModal = document.getElementById('signin-required-modal');
            if (signinModal) signinModal.style.display = 'flex';
            return;
        }

        const server = this.servers.find(s => s.id === this.selectedServerId) || this.servers[0];
        if (server && this.currentUser && this.onServerJoinCallback) {
            this.onServerJoinCallback(server, this.currentUser);
        }
    }

    updateAccountsUI() {
        const listEl = document.getElementById('accounts-list');
        const statusEl = document.getElementById('accounts-google-status');
        const gameNameInput = document.getElementById('accounts-game-name') as HTMLInputElement;

        if (this.currentUser) {
            if (gameNameInput) gameNameInput.value = this.currentUser.name;
            if (statusEl) {
                statusEl.innerHTML = `<span style="color: #55ff55;">✓ Signed in with Google: <b>${this.currentUser.name}</b> (${this.currentUser.email})</span>`;
            }
            if (listEl) {
                listEl.innerHTML = `
                    <div class="account-item active" style="display: flex; align-items: center; justify-content: space-between; padding: 10px; background: rgba(30,50,30,0.8); border: 1px solid #4a904a; margin-bottom: 8px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 32px; height: 32px; border-radius: 50%; background: #4285f4; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #fff;">
                                ${this.currentUser.name[0]?.toUpperCase() || 'G'}
                            </div>
                            <div>
                                <div style="font-weight: bold; color: #fff; display: flex; align-items: center; gap: 6px;">
                                    ${this.currentUser.name}
                                    <span style="background: #234e23; color: #55ff55; font-size: 10px; padding: 1px 4px; border: 1px solid #388e3c;">GOOGLE VERIFIED</span>
                                </div>
                                <div style="color: #aaa; font-size: 11px;">${this.currentUser.email}</div>
                            </div>
                        </div>
                        <button id="btn-accounts-logout" class="menu-small-btn secondary" style="padding: 4px 10px; font-size: 11px;">SIGN OUT</button>
                    </div>
                `;

                document.getElementById('btn-accounts-logout')?.addEventListener('click', () => {
                    this.saveAccount(null);
                });
            }
        } else {
            if (statusEl) {
                statusEl.innerText = 'Sign in with your Google account to play on online multiplayer servers.';
                statusEl.style.color = '#ccc';
            }
            if (listEl) {
                listEl.innerHTML = `
                    <div style="padding: 12px; color: #999; text-align: center; border: 1px dashed #444; margin-bottom: 8px;">
                        No Google account connected.<br>
                        <span style="font-size: 11px; color: #aaa;">You can play <b>offline in Singleplayer</b> anytime without an account.</span>
                    </div>
                `;
            }
        }
    }

    updateServerUI() {
        const usernameInput = document.getElementById('server-username') as HTMLInputElement;
        const statusEl = document.getElementById('server-status');
        if (this.currentUser) {
            if (usernameInput) usernameInput.value = this.currentUser.name;
            if (statusEl) {
                statusEl.innerHTML = `<span style="color:#55ff55">✓ Verified:</span> ${this.currentUser.name}`;
            }
        } else {
            if (usernameInput) usernameInput.value = 'Player (Offline)';
            if (statusEl) {
                statusEl.innerHTML = `<span style="color:#ffaa00">Offline Singleplayer Only</span> (Sign in to unlock servers)`;
            }
        }
    }
}
